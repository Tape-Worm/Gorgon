﻿
// 
// Gorgon
// Copyright (C) 2025 Michael Winsor
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE
// 
// Created: Monday, December 14, 2015 8:41:48 PM
// 

using System.Runtime.CompilerServices;
using Gorgon.Graphics.Imaging;
using Gorgon.Math;
using SharpDX.DXGI;
using SharpDX.Mathematics.Interop;
using D3D11 = SharpDX.Direct3D11;

namespace Gorgon.Graphics.Core.OLDE;

/// <summary>
/// Extension methods for SharpDX object conversion
/// </summary>
internal static class SharpDXExtensions
{
    extension(SwapChainDescription1 desc)
    {
        /// <summary>
        /// Function to convert a DXGI swap chain description to a <see cref="GorgonSwapChainInfo"/>.
        /// </summary>
        /// <param name="name">The name of the swap chain.</param>
        /// <returns>A new <see cref="GorgonSwapChainInfo"/>.</returns>
        public GorgonSwapChainInfo ToSwapChainInfo(string name) => new(desc.Width, desc.Height, (BufferFormat)desc.Format)
        {
            Name = name,
            StretchBackBuffer = desc.Scaling != Scaling.None
        };
    }

    extension(IGorgonSwapChainInfo swapChainInfo)
    {
        /// <summary>
        /// Function to convert a <see cref="IGorgonSwapChainInfo"/> to a DXGI swap chain description value.
        /// </summary>
        /// <returns>A DXGI swap chain description.</returns>
        public SwapChainDescription1 ToSwapChainDesc() => new()
        {
            BufferCount = 2,
            AlphaMode = AlphaMode.Unspecified,
            Flags = SwapChainFlags.AllowModeSwitch,
            Format = (Format)swapChainInfo.Format,
            Width = swapChainInfo.Width,
            Height = swapChainInfo.Height,
            Scaling = swapChainInfo.StretchBackBuffer ? Scaling.Stretch : Scaling.None,
            SampleDescription = ToSampleDesc(GorgonMultisampleInfo.NoMultiSampling),
            SwapEffect = SwapEffect.FlipSequential,
            Usage = Usage.RenderTargetOutput
        };
    }

    extension(GorgonBox box)
    {
        /// <summary>
        /// Function to convert a <see cref="GorgonBox"/> to a D3D11 resource region.
        /// </summary>
        /// <returns>The D3D11 resource region.</returns>
        public D3D11.ResourceRegion ToResourceRegion() => new(box.Left, box.Top, box.Front, box.Right, box.Bottom, box.Back);
    }

    extension(Rational rational)
    {
        /// <summary>
        /// Function to convert a DXGI rational number to a Gorgon rational number.
        /// </summary>
        /// <returns>A Gorgon rational number.</returns>
        public GorgonRationalNumber ToGorgonRational() => rational.Denominator == 0 ? GorgonRationalNumber.Empty : new GorgonRationalNumber(rational.Numerator, rational.Denominator);
    }

    extension(GorgonRationalNumber rational)
    {
        /// <summary>
        /// Function to convert a Gorgon rational number to a DXGI rational number.
        /// </summary>
        /// <returns>The DXGI ration number.</returns>
        public Rational ToDxGiRational() => new(rational.Numerator, rational.Denominator);
    }

    extension(in GorgonVideoMode mode)
    {
        /// <summary>
        /// Function to convert a GorgonVideoMode to a ModeDescription.
        /// </summary>
        /// <returns>The new mode description.</returns>
        public ModeDescription ToModeDesc() => new()
        {
            Format = (Format)mode.Format,
            Height = mode.Height,
            Scaling = (DisplayModeScaling)mode.Scaling,
            Width = mode.Width,
            ScanlineOrdering = (DisplayModeScanlineOrder)mode.ScanlineOrder,
            RefreshRate = mode.RefreshRate.ToDxGiRational()
        };

        /// <summary>
        /// Function to convert a GorgonVideoMode to a ModeDescription1.
        /// </summary>
        /// <returns>The new mode description.</returns>
        public ModeDescription1 ToModeDesc1() => new()
        {
            Format = (Format)mode.Format,
            Height = mode.Height,
            Scaling = (DisplayModeScaling)mode.Scaling,
            Width = mode.Width,
            ScanlineOrdering = (DisplayModeScanlineOrder)mode.ScanlineOrder,
            RefreshRate = mode.RefreshRate.ToDxGiRational(),
            Stereo = mode.SupportsStereo
        };
    }

    extension(ModeDescription1 mode)
    {
        /// <summary>
        /// Function to convert a DXGI ModeDescription1 to a <see cref="GorgonVideoMode"/>.
        /// </summary>
        /// <param name="gorgonMode">The converted video mode.</param>
        public void ToGorgonVideoMode(out GorgonVideoMode gorgonMode) => gorgonMode = new GorgonVideoMode(mode);

        /// <summary>
        /// Function to convert a ModeDescription1 to a ModeDescription.
        /// </summary>
        /// <returns>The new mode description.</returns>
        public ModeDescription ToModeDesc() => new()
        {
            Format = mode.Format,
            Height = mode.Height,
            Scaling = mode.Scaling,
            Width = mode.Width,
            ScanlineOrdering = mode.ScanlineOrdering,
            RefreshRate = mode.RefreshRate
        };
    }

    extension(ModeDescription mode)
    {
        /// <summary>
        /// Function to convert a DXGI ModeDescription to a <see cref="GorgonVideoMode"/>.
        /// </summary>
        /// <returns>The new mode description.</returns>
        public GorgonVideoMode ToGorgonVideoMode() => new(mode.ToModeDesc1());

        /// <summary>
        /// Function to convert a ModeDescription to a ModeDescription1.
        /// </summary>
        /// <returns>The new mode description.</returns>
        public ModeDescription1 ToModeDesc1() => new()
        {
            Format = mode.Format,
            Height = mode.Height,
            Scaling = mode.Scaling,
            Width = mode.Width,
            ScanlineOrdering = mode.ScanlineOrdering,
            RefreshRate = mode.RefreshRate,
            Stereo = false
        };
    }

    extension(RawRectangle rectangle)
    {
        /// <summary>
        /// Function to convert a SharpDX raw rectangle to a <see cref="GorgonRectangle"/>.
        /// </summary>
        /// <returns>The converted rectangle.</returns>
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public GorgonRectangle ToGorgonRectangle() => GorgonRectangle.FromLTRB(rectangle.Left, rectangle.Top, rectangle.Right, rectangle.Bottom);
    }

    extension(GorgonRectangle rectangle)
    {
        /// <summary>
        /// Function to convert a <see cref="GorgonRectangle"/> to a SharpDX raw rectangle.
        /// </summary>
        /// <returns>The converted rectangle.</returns>
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public RawRectangle ToSharpDXRawRectangle() => new(rectangle.Left, rectangle.Top, rectangle.Right, rectangle.Bottom);
    }

    extension(ref readonly GorgonVertexBufferBinding binding)
    {
        /// <summary>
        /// Function to convert a GorgonVertexBufferBinding to a D3D11 vertex buffer binding.
        /// </summary>
        /// <returns>The D3D11 vertex buffer binding.</returns>
        public D3D11.VertexBufferBinding ToVertexBufferBinding() => new(binding.VertexBuffer?.Native, binding.Stride, binding.Offset);
    }

    extension(GorgonMultisampleInfo samplingInfo)
    {
        /// <summary>
        /// Function to convert a <see cref="GorgonMultisampleInfo"/> to a DXGI multi sample description.
        /// </summary>
        /// <returns>The DXGI multi sample description.</returns>
        public SampleDescription ToSampleDesc() => new(samplingInfo.Count, samplingInfo.Quality);
    }
}
