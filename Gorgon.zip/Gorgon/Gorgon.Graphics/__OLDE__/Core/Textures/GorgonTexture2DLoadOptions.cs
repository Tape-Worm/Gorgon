﻿
// 
// Gorgon
// Copyright (C) 2025 Michael Winsor
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE
// 
// Created: April 12, 2018 12:40:39 AM
// 

using Gorgon.Graphics.Imaging;

namespace Gorgon.Graphics.Core.OLDE;

/// <summary>
/// Options to pass when loading a texture from a stream or the file system
/// </summary>
public class GorgonTexture2DLoadOptions
    : GorgonTextureLoadOptions
{
    /// <summary>
    /// Property to set or return whether the texture is a texture cube.
    /// </summary>
    /// <remarks>
    /// <para>
    /// This is for <see cref="GorgonTexture2D"/> only, and the texture must have an <see cref="IGorgonTexture2DInfo.ArrayCount"/> that is a multiple of 6.
    /// </para>
    /// <para>
    /// Set this value to <b>null</b> to let the source image <see cref="IGorgonImageInfo.ImageType"/> determine whether to use this texture as a texture cube.
    /// </para>
    /// </remarks>
    public bool? IsTextureCube
    {
        get;
        set;
    }

    /// <summary>
    /// Property to set or return the multisampling information to apply to the texture.
    /// </summary>
    public GorgonMultisampleInfo MultisampleInfo
    {
        get;
        set;
    } = GorgonMultisampleInfo.NoMultiSampling;
}
