using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace SystemInfo
{
    static class MainApplication
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
			Application.EnableVisualStyles();
			Application.DoEvents();
            Application.Run(new SystemInfoForm());
        }
    }
}
