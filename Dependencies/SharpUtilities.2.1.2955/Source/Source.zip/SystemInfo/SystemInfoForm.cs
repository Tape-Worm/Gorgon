using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Microsoft.Win32;
using SharpUtilities;
using SharpUtilities.Utility;

namespace SystemInfo
{
    /// <summary>
    /// Main interface for system information.
    /// </summary>
    public partial class SystemInfoForm : Form
    {
        #region Variables.
        private YourComputer _systemInfo;           // System information object.
        private int _currentCPU = 0;                // Current CPU.
        private bool _minimizeToTray = true;        // Flag to indicate that we wish to minimize to the tray.
        private bool _minimizeOnStart = true;       // Flag to indicate that we wish to minimize on startup.
        private bool _showBalloonOnStart = true;    // Flag to indicate that we wish to show the balloon tooltip on startup.
        #endregion

        #region Methods.
        /// <summary>
        /// Function to retrieve the settings for the program.
        /// </summary>
        private void GetSettings()
        {
            RegistryKey reg = Registry.CurrentUser;         // Current user registry.
            RegistryKey values = null;                      // Config values.

            // Get the values.
            try
            {
				values = reg.OpenSubKey("Software\\Tape_Worm\\SharpUtils2.x\\SystemInfo");

                if (values != null)
                {
                    _minimizeToTray = Convert.ToBoolean(values.GetValue("MinimizeToTray"));
                    _minimizeOnStart = Convert.ToBoolean(values.GetValue("MinimizeOnStart"));
                    _showBalloonOnStart = Convert.ToBoolean(values.GetValue("ShowBalloonOnStart"));
                }
            }
            catch(Exception e)
            {
				UI.ErrorBox(this, ErrorDialogIcons.Hardware, "Could not retrieve settings!",e.Message,"Sharp Utilities - Error");
            }
            finally
            {
                // Clean up.
                if (reg != null)
                    reg.Close();

                if (values != null)
                    values.Close();

                reg = null;
                values = null;
            }
        }

        /// <summary>
        /// Function to validate the CPU buttons.
        /// </summary>
        private void ValidateButtons()
        {
            nextCPU.Enabled = false;
            previousCPU.Enabled = false;

            // Enable only if we have more than 1 CPU.
            if (_systemInfo.CPU.Count > 1)
            {
                // Enable only if we've moved on to the next CPU.
                if (_currentCPU > 0)
                    previousCPU.Enabled = true;

                // Enable only if we haven't reached the CPU count.
                if (_currentCPU < _systemInfo.CPU.Count-1)
                    nextCPU.Enabled = true;
            }
        }

        /// <summary>
        /// Function to update CPU information.
        /// </summary>
        private void UpdateCPUInfo()
        {
            string unit;        // Unit used to measure speed.
            float speed;        // Speed.

            CPUIndex.Text = string.Format("{0}",_currentCPU+1);

			if ((_systemInfo.OSType == OSTypes.WindowsVista) || (_systemInfo.OSType == OSTypes.WindowsFuture))
			{
				labelLogicalCPUs.Text = _systemInfo.CPU[_currentCPU].LogicalCPUCount.ToString();
				labelCores.Text = _systemInfo.CPU[_currentCPU].CoreCount.ToString();
			}
			else
			{
				labelLogicalCPUs.Text = "N/A";
				labelCores.Text = "N/A";
			}

            speed = _systemInfo.CPU[_currentCPU].Speed;

            if (_systemInfo.CPU[_currentCPU].Speed < 1000.0f)
                unit = " MHz";
            else
            {
                speed = speed / 1000.0f;
                unit = " GHz";
            }

            speedMHz.Text = speed.ToString("0.00") + unit;
            vendorID.Text = _systemInfo.CPU[_currentCPU].Vendor;
            CPUType.Text = _systemInfo.CPU[_currentCPU].Name;
            familyCode.Text = _systemInfo.CPU[_currentCPU].Family.ToString();
            levelCode.Text = _systemInfo.CPU[_currentCPU].Level.ToString();
            steppingCode.Text = _systemInfo.CPU[_currentCPU].Stepping.ToString();
            revisionCode.Text = _systemInfo.CPU[_currentCPU].Revision.ToString();
        }

        /// <summary>
        /// Function to update memory stats.
        /// </summary>
        private void UpdateMemory()
        {
            float[] mem = new float[4];         // Memory values.
            string[] memUnit = new String[4];   // Memory units.
            int i;                              // Loop.

            for (i=0;i<4;i++)
                memUnit[i] = " KB";

            mem[0] = _systemInfo.TotalVirtual;
            mem[1] = _systemInfo.TotalPhysical;
            mem[2] = _systemInfo.FreePhysical;
            mem[3] = _systemInfo.FreeVirtual;

            // Update.
            for (i=0;i<4;i++)
            {
                if ((mem[i] >= 1000.0f) && (mem[i] < 1000000.0f))
                {
                    mem[i] /= 1024.0f;
                    memUnit[i] = " MB";
                }

                if (mem[i] >= 1000000.0f)
                {
                    mem[i] /= 1048576.0f;
                    memUnit[i] = " GB";
                }
            }         

            // Update memory values.
            totalPhysical.Text = mem[1].ToString("0.0") + memUnit[1];
            totalVirtual.Text = mem[0].ToString("0.0") + memUnit[0];
            freePhysical.Text = mem[2].ToString("0.0") + memUnit[2];
            freeVirtual.Text = mem[3].ToString("0.0") + memUnit[3];
        }

        /// <summary>
        /// Function to update operating system information.
        /// </summary>
        private void UpdateOSInfo()
        {
            string SPInfo;	// Service pack information.

            switch (_systemInfo.OSType)
            {
                case OSTypes.Windows95:
                    OSType.Text = "Windows 95 (Time to upgrade don't you think?)";
                    break;
                case OSTypes.Windows95OSR2:
                    OSType.Text = "Windows 95 OSR2 (UPGRADE ALREADY!!)";
                    break;
                case OSTypes.Windows98:
                    OSType.Text = "Windows 98";
                    break;
                case OSTypes.Windows98SE:
                    OSType.Text = "Windows 98 SE";
                    break;
                case OSTypes.WindowsNT4:
                    OSType.Text = "Windows NT 4.0";
                    break;
                case OSTypes.WindowsME:
                    OSType.Text = "Windows Millenium Edition (You sorry bastard.)";
                    break;
                case OSTypes.Windows2000:
                    OSType.Text = "Windows 2000";
                    break;
                case OSTypes.WindowsCE:
                    OSType.Text = "Windows CE";
                    break;
                case OSTypes.WindowsXP:
                    OSType.Text = "Windows XP";
                    break;
                case OSTypes.Windows2003:
                    OSType.Text = "Windows 2003";
                    break;
                case OSTypes.WindowsVista:
                    OSType.Text = "Windows Vista";
                    break;
                case OSTypes.WindowsFuture:
                    OSType.Text = "Future version of Windows";
                    break;
                default:
                    OSType.Text = "Unknown.";
                    break;
            }

            switch (_systemInfo.OSExtensions)
            {
                case OSExtensions.Home:
                    OSEdition.Text = "Home";
                    break;
                case OSExtensions.CommunicationServer:
                    OSEdition.Text = "Communication Server";
                    break;
                case OSExtensions.DataCenter:
                    OSEdition.Text = "Data Center";
                    break;
                case OSExtensions.Embedded:
                    OSEdition.Text = "Embedded";
                    break;
                case OSExtensions.Enterprise:
                    OSEdition.Text = "Enterprise";
                    break;
                case OSExtensions.Professional:
                    OSEdition.Text = "Professional";
                    break;
                case OSExtensions.Server:
                    OSEdition.Text = "Server";
                    break;
                case OSExtensions.SmallBusiness:
                    OSEdition.Text = "Small Business Server";
                    break;
                case OSExtensions.SmallBusinessRestricted:
                    OSEdition.Text = "Small Business Server (Restricted)";
                    break;
                case OSExtensions.Workstation:
                    OSEdition.Text = "Workstation.";
                    break;
				case OSExtensions.Business:
					OSEdition.Text = "Business.";
					break;
				case OSExtensions.BusinessN:
					OSEdition.Text = "Business N.";
					break;
				case OSExtensions.EnterpriseServer:
					OSEdition.Text = "Enterprise Server.";
					break;
				case OSExtensions.HomeBasic:
					OSEdition.Text = "Home Basic.";
					break;
				case OSExtensions.HomeBasicN:
					OSEdition.Text = "Home Basic N.";
					break;
				case OSExtensions.HomePremium:
					OSEdition.Text = "Home Premium.";
					break;
				case OSExtensions.Starter:
					OSEdition.Text = "Starter.";
					break;
				case OSExtensions.Ultimate:
					OSEdition.Text = "Ultimate.";
					break;
			}

            OSVersion.Text = _systemInfo.OSVersion;
            terminalServices.Checked = _systemInfo.HasTerminalServices;
            checkOneSession.Checked = _systemInfo.HasLimitedTerminalSessions;
            checkOneSession.Enabled = terminalServices.Checked;            

            SPInfo = "";
            if (_systemInfo.OSBuildNumber.Length > 0)
                SPInfo = " Build " + _systemInfo.OSBuildNumber;

            if (_systemInfo.OSServicePack.Length > 0)
            {
                if (SPInfo.Length > 0)
                    SPInfo += ", ";

                SPInfo += _systemInfo.OSServicePack;
            }

            OSVersion.Text += SPInfo;

            if (_systemInfo.IsPartOfDomain)
                domainCaption.Text = "Domain Name:";
            else
                domainCaption.Text = "Workgroup Name:";
            domain.Text = _systemInfo.DomainName;
            this.Text = "System Information - " + _systemInfo.ComputerName;
            loginName.Text = _systemInfo.UserName;
            windowsDirectory.Text = _systemInfo.OSWindowsDirectory;
            systemDirectory.Text = _systemInfo.OSSystemDirectory;
        }
        #endregion

        #region Constructor
        /// <summary>
        /// Constructor
        /// </summary>
        public SystemInfoForm()
        {
            InitializeComponent();
        }
        #endregion

        private void SystemInfoForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            // Destroy the sys info object.
            if (trayNotify != null)
                trayNotify.Visible = false;

            if (_systemInfo != null)
                _systemInfo.Dispose();
            _systemInfo = null;
        }

        private void memoryTimer_Tick(object sender, EventArgs e)
        {
            // Update memory.
            UpdateMemory();
        }

        private void tabSysInfo_Selected(object sender, TabControlEventArgs e)
        {
            switch (e.TabPageIndex)
            {
                case 0:
                    // Update system info data.
                    UpdateCPUInfo();
                    UpdateMemory();
                    UpdateOSInfo();
                    break;
                case 1:
                    environmentVars.Text = "";        
                    // Fill in environment variables.
                    foreach (EnvironmentVariable env in _systemInfo.EnvironmentVariables)
                    {
                        environmentVars.SelectionFont = new Font("Courier New", 8.0f);
                        environmentVars.SelectionColor = Color.Blue;
                        environmentVars.SelectedText = env.Name;
                        environmentVars.SelectionColor = Color.Black;
                        environmentVars.SelectedText = " = ";
                        environmentVars.SelectionColor = Color.Green;
                        environmentVars.SelectedText = env.Value + "\r\n";
                    }

                    break;
            }
        }

        private void nextCPU_Click(object sender, EventArgs e)
        {
            if (_currentCPU < _systemInfo.CPU.Count)
                _currentCPU++;
            UpdateCPUInfo();
            ValidateButtons();
        }

        private void previousCPU_Click(object sender, EventArgs e)
        {
            if (_currentCPU > 0)
                _currentCPU--;
            UpdateCPUInfo();
            ValidateButtons();
        }

        private void SystemInfoForm_SizeChanged(object sender, EventArgs e)
        {
            if (_minimizeToTray)
            {
                if (this.WindowState == FormWindowState.Minimized)
                {
                    trayNotify.Visible = true;
                    Hide();
                }
                else
                    trayNotify.Visible = false;
            }
        }

        private void trayNotify_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            if (!this.Visible)
            {
                Show();
                this.WindowState = FormWindowState.Normal;
            }
        }

        private void popupTrayIcon_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
            if (e.ClickedItem.Name == "menuExit")
                this.Close();
            if (e.ClickedItem.Name == "menuRestore")
            {
                Show();
                this.WindowState = FormWindowState.Normal;
            }
                
        }

        private void trayNotify_MouseClick(object sender, MouseEventArgs e)
        {
            if (this.Visible)
                this.menuRestore.Enabled = false;
            else
                this.menuRestore.Enabled = true;
        }

        private void trayNotify_MouseDown(object sender, MouseEventArgs e)
        {
            if ((!this.Visible) && (e.Button == MouseButtons.Middle))
            {
                trayNotify.BalloonTipTitle = "Physical memory.";
                trayNotify.BalloonTipText = "Free: " + freePhysical.Text + "\nTotal: " + totalPhysical.Text;
                trayNotify.ShowBalloonTip(20000);
            }
        }

        private void SystemInfoForm_Load(object sender, EventArgs e)
        {            
            try
            {
                GetSettings();
                if ((_minimizeToTray) && (_minimizeOnStart))
                {
                    WindowState = FormWindowState.Minimized;
                    Hide();
                }
                else
                {
                    WindowState = FormWindowState.Normal;
                    trayNotify.Visible = false;
                }

                _systemInfo = new YourComputer();
                ValidateButtons();
                memoryTimer.Enabled = true;
                labelCPUCount.Text = _systemInfo.CPU.Count.ToString();

                UpdateCPUInfo();
                UpdateMemory();
                UpdateOSInfo();

                trayNotify.Text = "System Information: " + _systemInfo.ComputerName;

                // Show the bubble for a few seconds.
                if ((_minimizeOnStart) && (_showBalloonOnStart) && (_minimizeToTray))
                {
                    trayNotify.BalloonTipTitle = "System Information";
                    trayNotify.BalloonTipText = "System information has started, double-click\non the icon to show more details.";
                    trayNotify.ShowBalloonTip(4000);
                }
            }
            catch (Exception ex)
            {
				UI.ErrorBox(this, ErrorDialogIcons.Hardware, "Could not retrieve system information!", ex.Message, "Sharp Utilities - Error");
                Application.Exit();
            }
        }

        private void exitMenu_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void configureMenu_Click(object sender, EventArgs e)
        {
            ConfigureForm config = new ConfigureForm();

            // Show the form.
            config.ShowDialog(this);
            
            config.Dispose();
            config = null;
            GetSettings();
        }
    }
}