using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Microsoft.Win32;
using SharpUtilities;
using SharpUtilities.Utility;

namespace SystemInfo
{
    /// <summary>
    /// Configuration interface.
    /// </summary>
    public partial class ConfigureForm : Form
    {
        #region Variables.
        private bool _minimizeToTray = true;        // Flag to indicate that we wish to minimize to the tray.
        private bool _minimizeOnStart = true;       // Flag to indicate that we wish to minimize on startup.
        private bool _showBalloonOnStart = true;    // Flag to indicate that we wish to show the balloon tooltip on startup.
        private bool _changed = false;              // Data changed?
        #endregion

        #region Methods.
        /// <summary>
        /// Function to update controls based on settings.
        /// </summary>
        private void ValidateSettings()
        {
            trayOptions.Enabled = _minimizeToTray;
            minimizeToTray.Checked = _minimizeToTray;
            minimizeOnStart.Checked = _minimizeOnStart;            
            showBalloonOnStart.Checked = _showBalloonOnStart;
            showBalloonOnStart.Enabled = _minimizeOnStart;
        }

        /// <summary>
        /// Function to retrieve the settings for the program.
        /// </summary>
        private void GetSettings()
        {
            RegistryKey reg = Registry.CurrentUser;         // Current user registry.
            RegistryKey values = null;                      // Config values.

            // Get the values.
            try
            {
                values = reg.OpenSubKey("Software\\Tape_Worm\\SharpUtils2.x\\SystemInfo");

                if (values != null)
                {
                    _minimizeToTray = Convert.ToBoolean(values.GetValue("MinimizeToTray"));
                    _minimizeOnStart = Convert.ToBoolean(values.GetValue("MinimizeOnStart"));
                    _showBalloonOnStart = Convert.ToBoolean(values.GetValue("ShowBalloonOnStart"));
                }                
            }
            catch(Exception e)
            {
				UI.ErrorBox(this, "Could not retrieve settings!\n" + e.Message);
            }
            finally
            {
                // Clean up.
                if (reg != null)
                    reg.Close();

                if (values != null)
                    values.Close();

                reg = null;
                values = null;
            }
        }

        /// <summary>
        /// Function to save the configuration.
        /// </summary>
        private void SaveConfig()
        {
            RegistryKey reg = Registry.CurrentUser;         // Current user registry.
            RegistryKey values = null;                      // Config values.

            // Get the values.
            try
            {
                values = reg.CreateSubKey("Software\\Tape_Worm\\SharpUtils2.x\\SystemInfo");             

                if (values != null)
                {
                    values.SetValue("MinimizeToTray", _minimizeToTray,RegistryValueKind.DWord);
                    values.SetValue("MinimizeOnStart",_minimizeOnStart,RegistryValueKind.DWord);
                    values.SetValue("ShowBalloonOnStart",_showBalloonOnStart,RegistryValueKind.DWord);
                }

                _changed = false;
            }
            catch(Exception e)
            {
				UI.ErrorBox(this, "Could not save settings!\n" + e.Message);
            }
            finally
            {
                // Clean up.
                if (reg != null)
                    reg.Close();

                if (values != null)
                    values.Close();

                reg = null;
                values = null;
            }           
        }
        #endregion

        #region Constructor/Destructor.
        /// <summary>
        /// Constructor.
        /// </summary>
        public ConfigureForm()
        {
            InitializeComponent();
            GetSettings();            
        }
        #endregion

        private void ConfigureForm_Load(object sender, EventArgs e)
        {
            ValidateSettings();
            _changed = false;
        }

        private void minimizeToTray_CheckedChanged(object sender, EventArgs e)
        {
            _changed = true;
            _minimizeToTray = minimizeToTray.Checked;
            ValidateSettings();
        }

        private void minimizeOnStart_CheckedChanged(object sender, EventArgs e)
        {
            _changed = true;
            _minimizeOnStart = minimizeOnStart.Checked;
            ValidateSettings();
        }

        private void showBalloonOnStart_CheckedChanged(object sender, EventArgs e)
        {
            _changed = true;
            _showBalloonOnStart = showBalloonOnStart.Checked;
            ValidateSettings();
        }

        private void ConfigureForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (_changed)
            {
				if (UI.ConfirmBox(this, "You have made changes.  Do you wish to save those changes?") == ConfirmationResult.Yes)
					SaveConfig();
            }
        }

        private void Save_Click(object sender, EventArgs e)
        {
            SaveConfig();
            Close();
        }

        private void Cancel_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}