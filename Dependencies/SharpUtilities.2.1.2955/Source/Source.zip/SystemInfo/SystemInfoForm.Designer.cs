namespace SystemInfo
{
    partial class SystemInfoForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
			this.components = new System.ComponentModel.Container();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SystemInfoForm));
			this.tabSysInfo = new System.Windows.Forms.TabControl();
			this.pageSystemInfo = new System.Windows.Forms.TabPage();
			this.groupBox3 = new System.Windows.Forms.GroupBox();
			this.checkOneSession = new System.Windows.Forms.CheckBox();
			this.domain = new System.Windows.Forms.Label();
			this.domainCaption = new System.Windows.Forms.Label();
			this.OSEdition = new System.Windows.Forms.Label();
			this.label17 = new System.Windows.Forms.Label();
			this.terminalServices = new System.Windows.Forms.CheckBox();
			this.loginName = new System.Windows.Forms.Label();
			this.label13 = new System.Windows.Forms.Label();
			this.systemDirectory = new System.Windows.Forms.Label();
			this.label15 = new System.Windows.Forms.Label();
			this.windowsDirectory = new System.Windows.Forms.Label();
			this.label19 = new System.Windows.Forms.Label();
			this.OSVersion = new System.Windows.Forms.Label();
			this.label25 = new System.Windows.Forms.Label();
			this.OSType = new System.Windows.Forms.Label();
			this.label28 = new System.Windows.Forms.Label();
			this.groupBox2 = new System.Windows.Forms.GroupBox();
			this.levelCode = new System.Windows.Forms.Label();
			this.label20 = new System.Windows.Forms.Label();
			this.revisionCode = new System.Windows.Forms.Label();
			this.label30 = new System.Windows.Forms.Label();
			this.speedMHz = new System.Windows.Forms.Label();
			this.label32 = new System.Windows.Forms.Label();
			this.steppingCode = new System.Windows.Forms.Label();
			this.familyCode = new System.Windows.Forms.Label();
			this.label35 = new System.Windows.Forms.Label();
			this.label36 = new System.Windows.Forms.Label();
			this.CPUType = new System.Windows.Forms.Label();
			this.label38 = new System.Windows.Forms.Label();
			this.vendorID = new System.Windows.Forms.Label();
			this.label40 = new System.Windows.Forms.Label();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.totalPhysical = new System.Windows.Forms.Label();
			this.freeVirtual = new System.Windows.Forms.Label();
			this.freePhysical = new System.Windows.Forms.Label();
			this.totalVirtual = new System.Windows.Forms.Label();
			this.label45 = new System.Windows.Forms.Label();
			this.label46 = new System.Windows.Forms.Label();
			this.label47 = new System.Windows.Forms.Label();
			this.label48 = new System.Windows.Forms.Label();
			this.CPUIndex = new System.Windows.Forms.Label();
			this.label49 = new System.Windows.Forms.Label();
			this.nextCPU = new System.Windows.Forms.Button();
			this.previousCPU = new System.Windows.Forms.Button();
			this.pageVariables = new System.Windows.Forms.TabPage();
			this.environmentVars = new System.Windows.Forms.RichTextBox();
			this.icons = new System.Windows.Forms.ImageList(this.components);
			this.lblOSYou = new System.Windows.Forms.Label();
			this.label26 = new System.Windows.Forms.Label();
			this.lblOSSysDir = new System.Windows.Forms.Label();
			this.label24 = new System.Windows.Forms.Label();
			this.lblOSWinDir = new System.Windows.Forms.Label();
			this.label22 = new System.Windows.Forms.Label();
			this.lblOSTS = new System.Windows.Forms.Label();
			this.label18 = new System.Windows.Forms.Label();
			this.lblOSVer = new System.Windows.Forms.Label();
			this.label16 = new System.Windows.Forms.Label();
			this.lblOSType = new System.Windows.Forms.Label();
			this.label8 = new System.Windows.Forms.Label();
			this.lblRevision = new System.Windows.Forms.Label();
			this.label6 = new System.Windows.Forms.Label();
			this.lblSpeed = new System.Windows.Forms.Label();
			this.label12 = new System.Windows.Forms.Label();
			this.lblSteppingID = new System.Windows.Forms.Label();
			this.lblFamilyID = new System.Windows.Forms.Label();
			this.label7 = new System.Windows.Forms.Label();
			this.label5 = new System.Windows.Forms.Label();
			this.lblCPUType = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.lblCPUVendor = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.lblFreeVirtual = new System.Windows.Forms.Label();
			this.lblFreePhysical = new System.Windows.Forms.Label();
			this.lblTotalVirtual = new System.Windows.Forms.Label();
			this.lblTotalPhysical = new System.Windows.Forms.Label();
			this.label9 = new System.Windows.Forms.Label();
			this.label10 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.buttonTips = new System.Windows.Forms.ToolTip(this.components);
			this.memoryTimer = new System.Windows.Forms.Timer(this.components);
			this.trayNotify = new System.Windows.Forms.NotifyIcon(this.components);
			this.popupTrayIcon = new System.Windows.Forms.ContextMenuStrip(this.components);
			this.menuRestore = new System.Windows.Forms.ToolStripMenuItem();
			this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
			this.menuExit = new System.Windows.Forms.ToolStripMenuItem();
			this.mainMenu = new System.Windows.Forms.MenuStrip();
			this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.configureMenu = new System.Windows.Forms.ToolStripMenuItem();
			this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
			this.exitMenu = new System.Windows.Forms.ToolStripMenuItem();
			this.labelLogicalCPUs = new System.Windows.Forms.Label();
			this.label23 = new System.Windows.Forms.Label();
			this.label14 = new System.Windows.Forms.Label();
			this.labelCPUCount = new System.Windows.Forms.Label();
			this.label50 = new System.Windows.Forms.Label();
			this.labelCores = new System.Windows.Forms.Label();
			this.tabSysInfo.SuspendLayout();
			this.pageSystemInfo.SuspendLayout();
			this.groupBox3.SuspendLayout();
			this.groupBox2.SuspendLayout();
			this.groupBox1.SuspendLayout();
			this.pageVariables.SuspendLayout();
			this.popupTrayIcon.SuspendLayout();
			this.mainMenu.SuspendLayout();
			this.SuspendLayout();
			// 
			// tabSysInfo
			// 
			this.tabSysInfo.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
						| System.Windows.Forms.AnchorStyles.Left)
						| System.Windows.Forms.AnchorStyles.Right)));
			this.tabSysInfo.Controls.Add(this.pageSystemInfo);
			this.tabSysInfo.Controls.Add(this.pageVariables);
			this.tabSysInfo.HotTrack = true;
			this.tabSysInfo.ImageList = this.icons;
			this.tabSysInfo.Location = new System.Drawing.Point(0, 27);
			this.tabSysInfo.Name = "tabSysInfo";
			this.tabSysInfo.SelectedIndex = 0;
			this.tabSysInfo.ShowToolTips = true;
			this.tabSysInfo.Size = new System.Drawing.Size(550, 549);
			this.tabSysInfo.TabIndex = 0;
			this.tabSysInfo.Selected += new System.Windows.Forms.TabControlEventHandler(this.tabSysInfo_Selected);
			// 
			// pageSystemInfo
			// 
			this.pageSystemInfo.Controls.Add(this.labelLogicalCPUs);
			this.pageSystemInfo.Controls.Add(this.label23);
			this.pageSystemInfo.Controls.Add(this.label14);
			this.pageSystemInfo.Controls.Add(this.labelCPUCount);
			this.pageSystemInfo.Controls.Add(this.label50);
			this.pageSystemInfo.Controls.Add(this.labelCores);
			this.pageSystemInfo.Controls.Add(this.groupBox3);
			this.pageSystemInfo.Controls.Add(this.groupBox2);
			this.pageSystemInfo.Controls.Add(this.groupBox1);
			this.pageSystemInfo.Controls.Add(this.CPUIndex);
			this.pageSystemInfo.Controls.Add(this.label49);
			this.pageSystemInfo.Controls.Add(this.nextCPU);
			this.pageSystemInfo.Controls.Add(this.previousCPU);
			this.pageSystemInfo.ImageIndex = 1;
			this.pageSystemInfo.Location = new System.Drawing.Point(4, 23);
			this.pageSystemInfo.Name = "pageSystemInfo";
			this.pageSystemInfo.Padding = new System.Windows.Forms.Padding(3);
			this.pageSystemInfo.Size = new System.Drawing.Size(542, 522);
			this.pageSystemInfo.TabIndex = 0;
			this.pageSystemInfo.Text = "System Info";
			this.buttonTips.SetToolTip(this.pageSystemInfo, "This tab shows information about this computer.");
			this.pageSystemInfo.UseVisualStyleBackColor = true;
			// 
			// groupBox3
			// 
			this.groupBox3.Controls.Add(this.checkOneSession);
			this.groupBox3.Controls.Add(this.domain);
			this.groupBox3.Controls.Add(this.domainCaption);
			this.groupBox3.Controls.Add(this.OSEdition);
			this.groupBox3.Controls.Add(this.label17);
			this.groupBox3.Controls.Add(this.terminalServices);
			this.groupBox3.Controls.Add(this.loginName);
			this.groupBox3.Controls.Add(this.label13);
			this.groupBox3.Controls.Add(this.systemDirectory);
			this.groupBox3.Controls.Add(this.label15);
			this.groupBox3.Controls.Add(this.windowsDirectory);
			this.groupBox3.Controls.Add(this.label19);
			this.groupBox3.Controls.Add(this.OSVersion);
			this.groupBox3.Controls.Add(this.label25);
			this.groupBox3.Controls.Add(this.OSType);
			this.groupBox3.Controls.Add(this.label28);
			this.groupBox3.Location = new System.Drawing.Point(7, 289);
			this.groupBox3.Name = "groupBox3";
			this.groupBox3.Size = new System.Drawing.Size(525, 228);
			this.groupBox3.TabIndex = 24;
			this.groupBox3.TabStop = false;
			this.groupBox3.Text = "Operating System.";
			// 
			// checkOneSession
			// 
			this.checkOneSession.AutoCheck = false;
			this.checkOneSession.AutoSize = true;
			this.checkOneSession.BackColor = System.Drawing.SystemColors.Control;
			this.checkOneSession.Enabled = false;
			this.checkOneSession.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.checkOneSession.ForeColor = System.Drawing.Color.Black;
			this.checkOneSession.Location = new System.Drawing.Point(192, 104);
			this.checkOneSession.Name = "checkOneSession";
			this.checkOneSession.Size = new System.Drawing.Size(109, 17);
			this.checkOneSession.TabIndex = 35;
			this.checkOneSession.Text = "Only one session?";
			this.checkOneSession.UseVisualStyleBackColor = false;
			// 
			// domain
			// 
			this.domain.BackColor = System.Drawing.Color.White;
			this.domain.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.domain.Location = new System.Drawing.Point(122, 127);
			this.domain.Name = "domain";
			this.domain.Size = new System.Drawing.Size(397, 20);
			this.domain.TabIndex = 34;
			this.domain.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// domainCaption
			// 
			this.domainCaption.AutoSize = true;
			this.domainCaption.Location = new System.Drawing.Point(6, 131);
			this.domainCaption.Name = "domainCaption";
			this.domainCaption.Size = new System.Drawing.Size(104, 13);
			this.domainCaption.TabIndex = 33;
			this.domainCaption.Text = "Domain/Workgroup:";
			// 
			// OSEdition
			// 
			this.OSEdition.BackColor = System.Drawing.Color.White;
			this.OSEdition.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.OSEdition.Location = new System.Drawing.Point(68, 49);
			this.OSEdition.Name = "OSEdition";
			this.OSEdition.Size = new System.Drawing.Size(451, 20);
			this.OSEdition.TabIndex = 32;
			this.OSEdition.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// label17
			// 
			this.label17.Location = new System.Drawing.Point(6, 50);
			this.label17.Name = "label17";
			this.label17.Size = new System.Drawing.Size(52, 20);
			this.label17.TabIndex = 31;
			this.label17.Text = "Edition:";
			this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// terminalServices
			// 
			this.terminalServices.AutoCheck = false;
			this.terminalServices.AutoSize = true;
			this.terminalServices.BackColor = System.Drawing.SystemColors.Control;
			this.terminalServices.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.terminalServices.ForeColor = System.Drawing.Color.Black;
			this.terminalServices.Location = new System.Drawing.Point(68, 104);
			this.terminalServices.Name = "terminalServices";
			this.terminalServices.Size = new System.Drawing.Size(113, 17);
			this.terminalServices.TabIndex = 29;
			this.terminalServices.Text = "Terminal Services?";
			this.terminalServices.UseVisualStyleBackColor = false;
			// 
			// loginName
			// 
			this.loginName.BackColor = System.Drawing.Color.White;
			this.loginName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.loginName.Location = new System.Drawing.Point(122, 151);
			this.loginName.Name = "loginName";
			this.loginName.Size = new System.Drawing.Size(397, 20);
			this.loginName.TabIndex = 26;
			this.loginName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// label13
			// 
			this.label13.Location = new System.Drawing.Point(6, 151);
			this.label13.Name = "label13";
			this.label13.Size = new System.Drawing.Size(108, 20);
			this.label13.TabIndex = 25;
			this.label13.Text = "You are:";
			this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// systemDirectory
			// 
			this.systemDirectory.BackColor = System.Drawing.Color.White;
			this.systemDirectory.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.systemDirectory.Location = new System.Drawing.Point(122, 199);
			this.systemDirectory.Name = "systemDirectory";
			this.systemDirectory.Size = new System.Drawing.Size(397, 20);
			this.systemDirectory.TabIndex = 24;
			this.systemDirectory.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// label15
			// 
			this.label15.Location = new System.Drawing.Point(6, 199);
			this.label15.Name = "label15";
			this.label15.Size = new System.Drawing.Size(108, 20);
			this.label15.TabIndex = 23;
			this.label15.Text = "System Directory:";
			this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// windowsDirectory
			// 
			this.windowsDirectory.BackColor = System.Drawing.Color.White;
			this.windowsDirectory.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.windowsDirectory.Location = new System.Drawing.Point(122, 175);
			this.windowsDirectory.Name = "windowsDirectory";
			this.windowsDirectory.Size = new System.Drawing.Size(397, 20);
			this.windowsDirectory.TabIndex = 22;
			this.windowsDirectory.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// label19
			// 
			this.label19.Location = new System.Drawing.Point(6, 175);
			this.label19.Name = "label19";
			this.label19.Size = new System.Drawing.Size(108, 20);
			this.label19.TabIndex = 21;
			this.label19.Text = "Windows Directory:";
			this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// OSVersion
			// 
			this.OSVersion.BackColor = System.Drawing.Color.White;
			this.OSVersion.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.OSVersion.Location = new System.Drawing.Point(68, 81);
			this.OSVersion.Name = "OSVersion";
			this.OSVersion.Size = new System.Drawing.Size(451, 20);
			this.OSVersion.TabIndex = 16;
			this.OSVersion.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// label25
			// 
			this.label25.Location = new System.Drawing.Point(6, 81);
			this.label25.Name = "label25";
			this.label25.Size = new System.Drawing.Size(56, 20);
			this.label25.TabIndex = 15;
			this.label25.Text = "Version:";
			this.label25.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// OSType
			// 
			this.OSType.BackColor = System.Drawing.Color.White;
			this.OSType.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.OSType.Location = new System.Drawing.Point(68, 20);
			this.OSType.Name = "OSType";
			this.OSType.Size = new System.Drawing.Size(451, 20);
			this.OSType.TabIndex = 14;
			this.OSType.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// label28
			// 
			this.label28.Location = new System.Drawing.Point(6, 21);
			this.label28.Name = "label28";
			this.label28.Size = new System.Drawing.Size(52, 20);
			this.label28.TabIndex = 0;
			this.label28.Text = "OS Type:";
			this.label28.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// groupBox2
			// 
			this.groupBox2.Controls.Add(this.levelCode);
			this.groupBox2.Controls.Add(this.label20);
			this.groupBox2.Controls.Add(this.revisionCode);
			this.groupBox2.Controls.Add(this.label30);
			this.groupBox2.Controls.Add(this.speedMHz);
			this.groupBox2.Controls.Add(this.label32);
			this.groupBox2.Controls.Add(this.steppingCode);
			this.groupBox2.Controls.Add(this.familyCode);
			this.groupBox2.Controls.Add(this.label35);
			this.groupBox2.Controls.Add(this.label36);
			this.groupBox2.Controls.Add(this.CPUType);
			this.groupBox2.Controls.Add(this.label38);
			this.groupBox2.Controls.Add(this.vendorID);
			this.groupBox2.Controls.Add(this.label40);
			this.groupBox2.Location = new System.Drawing.Point(8, 91);
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.Size = new System.Drawing.Size(525, 105);
			this.groupBox2.TabIndex = 23;
			this.groupBox2.TabStop = false;
			this.groupBox2.Text = "CPU Info";
			// 
			// levelCode
			// 
			this.levelCode.BackColor = System.Drawing.Color.White;
			this.levelCode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.levelCode.Location = new System.Drawing.Point(189, 73);
			this.levelCode.Name = "levelCode";
			this.levelCode.Size = new System.Drawing.Size(56, 20);
			this.levelCode.TabIndex = 29;
			this.levelCode.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// label20
			// 
			this.label20.Location = new System.Drawing.Point(142, 73);
			this.label20.Name = "label20";
			this.label20.Size = new System.Drawing.Size(39, 20);
			this.label20.TabIndex = 28;
			this.label20.Text = "Level";
			this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// revisionCode
			// 
			this.revisionCode.BackColor = System.Drawing.Color.White;
			this.revisionCode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.revisionCode.Location = new System.Drawing.Point(437, 73);
			this.revisionCode.Name = "revisionCode";
			this.revisionCode.Size = new System.Drawing.Size(56, 20);
			this.revisionCode.TabIndex = 27;
			this.revisionCode.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// label30
			// 
			this.label30.Location = new System.Drawing.Point(377, 73);
			this.label30.Name = "label30";
			this.label30.Size = new System.Drawing.Size(52, 20);
			this.label30.TabIndex = 26;
			this.label30.Text = "Revision";
			this.label30.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// speedMHz
			// 
			this.speedMHz.BackColor = System.Drawing.Color.White;
			this.speedMHz.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.speedMHz.Location = new System.Drawing.Point(439, 44);
			this.speedMHz.Name = "speedMHz";
			this.speedMHz.Size = new System.Drawing.Size(80, 20);
			this.speedMHz.TabIndex = 25;
			this.speedMHz.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// label32
			// 
			this.label32.Location = new System.Drawing.Point(396, 44);
			this.label32.Name = "label32";
			this.label32.Size = new System.Drawing.Size(49, 20);
			this.label32.TabIndex = 24;
			this.label32.Text = "Speed:";
			this.label32.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// steppingCode
			// 
			this.steppingCode.BackColor = System.Drawing.Color.White;
			this.steppingCode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.steppingCode.Location = new System.Drawing.Point(313, 73);
			this.steppingCode.Name = "steppingCode";
			this.steppingCode.Size = new System.Drawing.Size(56, 20);
			this.steppingCode.TabIndex = 22;
			this.steppingCode.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// familyCode
			// 
			this.familyCode.BackColor = System.Drawing.Color.White;
			this.familyCode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.familyCode.Location = new System.Drawing.Point(78, 73);
			this.familyCode.Name = "familyCode";
			this.familyCode.Size = new System.Drawing.Size(56, 20);
			this.familyCode.TabIndex = 20;
			this.familyCode.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// label35
			// 
			this.label35.Location = new System.Drawing.Point(253, 73);
			this.label35.Name = "label35";
			this.label35.Size = new System.Drawing.Size(52, 20);
			this.label35.TabIndex = 18;
			this.label35.Text = "Stepping";
			this.label35.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// label36
			// 
			this.label36.Location = new System.Drawing.Point(31, 73);
			this.label36.Name = "label36";
			this.label36.Size = new System.Drawing.Size(39, 20);
			this.label36.TabIndex = 16;
			this.label36.Text = "Family";
			this.label36.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// CPUType
			// 
			this.CPUType.BackColor = System.Drawing.Color.White;
			this.CPUType.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.CPUType.Location = new System.Drawing.Point(104, 44);
			this.CPUType.Name = "CPUType";
			this.CPUType.Size = new System.Drawing.Size(286, 20);
			this.CPUType.TabIndex = 15;
			this.CPUType.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// label38
			// 
			this.label38.Location = new System.Drawing.Point(10, 44);
			this.label38.Name = "label38";
			this.label38.Size = new System.Drawing.Size(88, 20);
			this.label38.TabIndex = 14;
			this.label38.Text = "CPU Type:";
			this.label38.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// vendorID
			// 
			this.vendorID.BackColor = System.Drawing.Color.White;
			this.vendorID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.vendorID.Location = new System.Drawing.Point(104, 16);
			this.vendorID.Name = "vendorID";
			this.vendorID.Size = new System.Drawing.Size(415, 20);
			this.vendorID.TabIndex = 13;
			this.vendorID.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// label40
			// 
			this.label40.Location = new System.Drawing.Point(10, 16);
			this.label40.Name = "label40";
			this.label40.Size = new System.Drawing.Size(88, 20);
			this.label40.TabIndex = 12;
			this.label40.Text = "CPU Vendor ID:";
			this.label40.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.Add(this.totalPhysical);
			this.groupBox1.Controls.Add(this.freeVirtual);
			this.groupBox1.Controls.Add(this.freePhysical);
			this.groupBox1.Controls.Add(this.totalVirtual);
			this.groupBox1.Controls.Add(this.label45);
			this.groupBox1.Controls.Add(this.label46);
			this.groupBox1.Controls.Add(this.label47);
			this.groupBox1.Controls.Add(this.label48);
			this.groupBox1.Location = new System.Drawing.Point(8, 202);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(524, 81);
			this.groupBox1.TabIndex = 22;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "Memory Status";
			// 
			// totalPhysical
			// 
			this.totalPhysical.BackColor = System.Drawing.Color.White;
			this.totalPhysical.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.totalPhysical.Location = new System.Drawing.Point(95, 20);
			this.totalPhysical.Name = "totalPhysical";
			this.totalPhysical.Size = new System.Drawing.Size(172, 16);
			this.totalPhysical.TabIndex = 12;
			this.totalPhysical.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// freeVirtual
			// 
			this.freeVirtual.BackColor = System.Drawing.Color.White;
			this.freeVirtual.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.freeVirtual.Location = new System.Drawing.Point(346, 48);
			this.freeVirtual.Name = "freeVirtual";
			this.freeVirtual.Size = new System.Drawing.Size(172, 16);
			this.freeVirtual.TabIndex = 15;
			this.freeVirtual.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// freePhysical
			// 
			this.freePhysical.BackColor = System.Drawing.Color.White;
			this.freePhysical.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.freePhysical.Location = new System.Drawing.Point(95, 48);
			this.freePhysical.Name = "freePhysical";
			this.freePhysical.Size = new System.Drawing.Size(172, 16);
			this.freePhysical.TabIndex = 14;
			this.freePhysical.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// totalVirtual
			// 
			this.totalVirtual.BackColor = System.Drawing.Color.White;
			this.totalVirtual.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.totalVirtual.Location = new System.Drawing.Point(346, 20);
			this.totalVirtual.Name = "totalVirtual";
			this.totalVirtual.Size = new System.Drawing.Size(172, 16);
			this.totalVirtual.TabIndex = 13;
			this.totalVirtual.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// label45
			// 
			this.label45.Location = new System.Drawing.Point(274, 48);
			this.label45.Name = "label45";
			this.label45.Size = new System.Drawing.Size(72, 16);
			this.label45.TabIndex = 3;
			this.label45.Text = "Free Virtual";
			// 
			// label46
			// 
			this.label46.Location = new System.Drawing.Point(5, 48);
			this.label46.Name = "label46";
			this.label46.Size = new System.Drawing.Size(93, 16);
			this.label46.TabIndex = 2;
			this.label46.Text = "Free Physical";
			// 
			// label47
			// 
			this.label47.Location = new System.Drawing.Point(274, 20);
			this.label47.Name = "label47";
			this.label47.Size = new System.Drawing.Size(75, 16);
			this.label47.TabIndex = 1;
			this.label47.Text = "Total Virtual";
			// 
			// label48
			// 
			this.label48.Location = new System.Drawing.Point(5, 20);
			this.label48.Name = "label48";
			this.label48.Size = new System.Drawing.Size(93, 16);
			this.label48.TabIndex = 0;
			this.label48.Text = "Total Physical";
			// 
			// CPUIndex
			// 
			this.CPUIndex.BackColor = System.Drawing.Color.White;
			this.CPUIndex.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.CPUIndex.Location = new System.Drawing.Point(144, 10);
			this.CPUIndex.Name = "CPUIndex";
			this.CPUIndex.Size = new System.Drawing.Size(25, 20);
			this.CPUIndex.TabIndex = 21;
			this.CPUIndex.Text = "0";
			this.CPUIndex.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// label49
			// 
			this.label49.Location = new System.Drawing.Point(100, 10);
			this.label49.Name = "label49";
			this.label49.Size = new System.Drawing.Size(44, 20);
			this.label49.TabIndex = 20;
			this.label49.Text = "CPU: #";
			this.label49.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// nextCPU
			// 
			this.nextCPU.Enabled = false;
			this.nextCPU.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.nextCPU.Image = ((System.Drawing.Image)(resources.GetObject("nextCPU.Image")));
			this.nextCPU.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.nextCPU.Location = new System.Drawing.Point(179, 10);
			this.nextCPU.Name = "nextCPU";
			this.nextCPU.Size = new System.Drawing.Size(87, 20);
			this.nextCPU.TabIndex = 17;
			this.nextCPU.Text = "Next CPU";
			this.nextCPU.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.buttonTips.SetToolTip(this.nextCPU, "This button will move to the next CPU.");
			this.nextCPU.Click += new System.EventHandler(this.nextCPU_Click);
			// 
			// previousCPU
			// 
			this.previousCPU.Enabled = false;
			this.previousCPU.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.previousCPU.Image = ((System.Drawing.Image)(resources.GetObject("previousCPU.Image")));
			this.previousCPU.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.previousCPU.Location = new System.Drawing.Point(8, 10);
			this.previousCPU.Name = "previousCPU";
			this.previousCPU.Size = new System.Drawing.Size(86, 20);
			this.previousCPU.TabIndex = 16;
			this.previousCPU.Text = "Prev CPU";
			this.previousCPU.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.buttonTips.SetToolTip(this.previousCPU, "This button will move to the previous CPU.");
			this.previousCPU.Click += new System.EventHandler(this.previousCPU_Click);
			// 
			// pageVariables
			// 
			this.pageVariables.Controls.Add(this.environmentVars);
			this.pageVariables.ImageIndex = 0;
			this.pageVariables.Location = new System.Drawing.Point(4, 23);
			this.pageVariables.Name = "pageVariables";
			this.pageVariables.Padding = new System.Windows.Forms.Padding(3);
			this.pageVariables.Size = new System.Drawing.Size(542, 522);
			this.pageVariables.TabIndex = 1;
			this.pageVariables.Text = "Environment Variables";
			this.buttonTips.SetToolTip(this.pageVariables, "This tab shows a list of the current environment variables.");
			this.pageVariables.UseVisualStyleBackColor = true;
			// 
			// environmentVars
			// 
			this.environmentVars.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
						| System.Windows.Forms.AnchorStyles.Left)
						| System.Windows.Forms.AnchorStyles.Right)));
			this.environmentVars.BackColor = System.Drawing.Color.White;
			this.environmentVars.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.environmentVars.ForeColor = System.Drawing.Color.Black;
			this.environmentVars.Location = new System.Drawing.Point(8, 6);
			this.environmentVars.Name = "environmentVars";
			this.environmentVars.ReadOnly = true;
			this.environmentVars.Size = new System.Drawing.Size(526, 508);
			this.environmentVars.TabIndex = 2;
			this.environmentVars.Text = "";
			this.environmentVars.WordWrap = false;
			// 
			// icons
			// 
			this.icons.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("icons.ImageStream")));
			this.icons.TransparentColor = System.Drawing.Color.Transparent;
			this.icons.Images.SetKeyName(0, "text_code_colored.png");
			this.icons.Images.SetKeyName(1, "cpu_view.png");
			// 
			// lblOSYou
			// 
			this.lblOSYou.BackColor = System.Drawing.Color.White;
			this.lblOSYou.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblOSYou.Location = new System.Drawing.Point(124, 72);
			this.lblOSYou.Name = "lblOSYou";
			this.lblOSYou.Size = new System.Drawing.Size(344, 20);
			this.lblOSYou.TabIndex = 26;
			// 
			// label26
			// 
			this.label26.Location = new System.Drawing.Point(12, 76);
			this.label26.Name = "label26";
			this.label26.Size = new System.Drawing.Size(48, 16);
			this.label26.TabIndex = 25;
			this.label26.Text = "You are:";
			// 
			// lblOSSysDir
			// 
			this.lblOSSysDir.BackColor = System.Drawing.Color.White;
			this.lblOSSysDir.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblOSSysDir.Location = new System.Drawing.Point(124, 120);
			this.lblOSSysDir.Name = "lblOSSysDir";
			this.lblOSSysDir.Size = new System.Drawing.Size(344, 20);
			this.lblOSSysDir.TabIndex = 24;
			// 
			// label24
			// 
			this.label24.Location = new System.Drawing.Point(12, 124);
			this.label24.Name = "label24";
			this.label24.Size = new System.Drawing.Size(98, 16);
			this.label24.TabIndex = 23;
			this.label24.Text = "System Directory:";
			// 
			// lblOSWinDir
			// 
			this.lblOSWinDir.BackColor = System.Drawing.Color.White;
			this.lblOSWinDir.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblOSWinDir.Location = new System.Drawing.Point(124, 96);
			this.lblOSWinDir.Name = "lblOSWinDir";
			this.lblOSWinDir.Size = new System.Drawing.Size(344, 20);
			this.lblOSWinDir.TabIndex = 22;
			// 
			// label22
			// 
			this.label22.Location = new System.Drawing.Point(12, 100);
			this.label22.Name = "label22";
			this.label22.Size = new System.Drawing.Size(108, 16);
			this.label22.TabIndex = 21;
			this.label22.Text = "Windows Directory:";
			// 
			// lblOSTS
			// 
			this.lblOSTS.BackColor = System.Drawing.Color.White;
			this.lblOSTS.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblOSTS.Location = new System.Drawing.Point(444, 44);
			this.lblOSTS.Name = "lblOSTS";
			this.lblOSTS.Size = new System.Drawing.Size(24, 20);
			this.lblOSTS.TabIndex = 18;
			this.lblOSTS.TextAlign = System.Drawing.ContentAlignment.TopCenter;
			// 
			// label18
			// 
			this.label18.Location = new System.Drawing.Point(340, 48);
			this.label18.Name = "label18";
			this.label18.Size = new System.Drawing.Size(100, 16);
			this.label18.TabIndex = 17;
			this.label18.Text = "Terminal Services:";
			// 
			// lblOSVer
			// 
			this.lblOSVer.BackColor = System.Drawing.Color.White;
			this.lblOSVer.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblOSVer.Location = new System.Drawing.Point(400, 20);
			this.lblOSVer.Name = "lblOSVer";
			this.lblOSVer.Size = new System.Drawing.Size(68, 20);
			this.lblOSVer.TabIndex = 16;
			// 
			// label16
			// 
			this.label16.Location = new System.Drawing.Point(348, 24);
			this.label16.Name = "label16";
			this.label16.Size = new System.Drawing.Size(56, 16);
			this.label16.TabIndex = 15;
			this.label16.Text = "Version:";
			// 
			// lblOSType
			// 
			this.lblOSType.BackColor = System.Drawing.Color.White;
			this.lblOSType.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblOSType.Location = new System.Drawing.Point(68, 20);
			this.lblOSType.Name = "lblOSType";
			this.lblOSType.Size = new System.Drawing.Size(264, 44);
			this.lblOSType.TabIndex = 14;
			// 
			// label8
			// 
			this.label8.Location = new System.Drawing.Point(12, 24);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(52, 16);
			this.label8.TabIndex = 0;
			this.label8.Text = "OS Type:";
			// 
			// lblRevision
			// 
			this.lblRevision.BackColor = System.Drawing.Color.White;
			this.lblRevision.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblRevision.Location = new System.Drawing.Point(220, 84);
			this.lblRevision.Name = "lblRevision";
			this.lblRevision.Size = new System.Drawing.Size(48, 16);
			this.lblRevision.TabIndex = 27;
			this.lblRevision.TextAlign = System.Drawing.ContentAlignment.TopCenter;
			// 
			// label6
			// 
			this.label6.Location = new System.Drawing.Point(220, 68);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(48, 16);
			this.label6.TabIndex = 26;
			this.label6.Text = "Revision";
			// 
			// lblSpeed
			// 
			this.lblSpeed.BackColor = System.Drawing.Color.White;
			this.lblSpeed.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblSpeed.Location = new System.Drawing.Point(104, 104);
			this.lblSpeed.Name = "lblSpeed";
			this.lblSpeed.Size = new System.Drawing.Size(84, 16);
			this.lblSpeed.TabIndex = 25;
			this.lblSpeed.TextAlign = System.Drawing.ContentAlignment.TopRight;
			// 
			// label12
			// 
			this.label12.Location = new System.Drawing.Point(12, 104);
			this.label12.Name = "label12";
			this.label12.Size = new System.Drawing.Size(88, 16);
			this.label12.TabIndex = 24;
			this.label12.Text = "Speed:";
			// 
			// lblSteppingID
			// 
			this.lblSteppingID.BackColor = System.Drawing.Color.White;
			this.lblSteppingID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblSteppingID.Location = new System.Drawing.Point(164, 84);
			this.lblSteppingID.Name = "lblSteppingID";
			this.lblSteppingID.Size = new System.Drawing.Size(52, 16);
			this.lblSteppingID.TabIndex = 22;
			this.lblSteppingID.TextAlign = System.Drawing.ContentAlignment.TopCenter;
			// 
			// lblFamilyID
			// 
			this.lblFamilyID.BackColor = System.Drawing.Color.White;
			this.lblFamilyID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblFamilyID.Location = new System.Drawing.Point(104, 84);
			this.lblFamilyID.Name = "lblFamilyID";
			this.lblFamilyID.Size = new System.Drawing.Size(56, 16);
			this.lblFamilyID.TabIndex = 20;
			this.lblFamilyID.TextAlign = System.Drawing.ContentAlignment.TopCenter;
			// 
			// label7
			// 
			this.label7.Location = new System.Drawing.Point(164, 68);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(52, 16);
			this.label7.TabIndex = 18;
			this.label7.Text = "Stepping";
			// 
			// label5
			// 
			this.label5.Location = new System.Drawing.Point(104, 68);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(56, 16);
			this.label5.TabIndex = 16;
			this.label5.Text = "Family";
			// 
			// lblCPUType
			// 
			this.lblCPUType.BackColor = System.Drawing.Color.White;
			this.lblCPUType.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblCPUType.Location = new System.Drawing.Point(104, 44);
			this.lblCPUType.Name = "lblCPUType";
			this.lblCPUType.Size = new System.Drawing.Size(364, 20);
			this.lblCPUType.TabIndex = 15;
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(12, 48);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(88, 16);
			this.label3.TabIndex = 14;
			this.label3.Text = "CPU Type:";
			// 
			// lblCPUVendor
			// 
			this.lblCPUVendor.BackColor = System.Drawing.Color.White;
			this.lblCPUVendor.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblCPUVendor.Location = new System.Drawing.Point(104, 20);
			this.lblCPUVendor.Name = "lblCPUVendor";
			this.lblCPUVendor.Size = new System.Drawing.Size(364, 20);
			this.lblCPUVendor.TabIndex = 13;
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(12, 24);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(88, 16);
			this.label1.TabIndex = 12;
			this.label1.Text = "CPU Vendor ID:";
			// 
			// lblFreeVirtual
			// 
			this.lblFreeVirtual.BackColor = System.Drawing.Color.White;
			this.lblFreeVirtual.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblFreeVirtual.Location = new System.Drawing.Point(346, 36);
			this.lblFreeVirtual.Name = "lblFreeVirtual";
			this.lblFreeVirtual.Size = new System.Drawing.Size(84, 16);
			this.lblFreeVirtual.TabIndex = 15;
			this.lblFreeVirtual.TextAlign = System.Drawing.ContentAlignment.TopRight;
			// 
			// lblFreePhysical
			// 
			this.lblFreePhysical.BackColor = System.Drawing.Color.White;
			this.lblFreePhysical.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblFreePhysical.Location = new System.Drawing.Point(241, 36);
			this.lblFreePhysical.Name = "lblFreePhysical";
			this.lblFreePhysical.Size = new System.Drawing.Size(84, 16);
			this.lblFreePhysical.TabIndex = 14;
			this.lblFreePhysical.TextAlign = System.Drawing.ContentAlignment.TopRight;
			// 
			// lblTotalVirtual
			// 
			this.lblTotalVirtual.BackColor = System.Drawing.Color.White;
			this.lblTotalVirtual.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblTotalVirtual.Location = new System.Drawing.Point(136, 36);
			this.lblTotalVirtual.Name = "lblTotalVirtual";
			this.lblTotalVirtual.Size = new System.Drawing.Size(84, 16);
			this.lblTotalVirtual.TabIndex = 13;
			this.lblTotalVirtual.TextAlign = System.Drawing.ContentAlignment.TopRight;
			// 
			// lblTotalPhysical
			// 
			this.lblTotalPhysical.BackColor = System.Drawing.Color.White;
			this.lblTotalPhysical.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblTotalPhysical.Location = new System.Drawing.Point(31, 36);
			this.lblTotalPhysical.Name = "lblTotalPhysical";
			this.lblTotalPhysical.Size = new System.Drawing.Size(84, 16);
			this.lblTotalPhysical.TabIndex = 12;
			this.lblTotalPhysical.TextAlign = System.Drawing.ContentAlignment.TopRight;
			// 
			// label9
			// 
			this.label9.Location = new System.Drawing.Point(344, 20);
			this.label9.Name = "label9";
			this.label9.Size = new System.Drawing.Size(84, 16);
			this.label9.TabIndex = 3;
			this.label9.Text = "Free Virtual";
			// 
			// label10
			// 
			this.label10.Location = new System.Drawing.Point(240, 20);
			this.label10.Name = "label10";
			this.label10.Size = new System.Drawing.Size(84, 16);
			this.label10.TabIndex = 2;
			this.label10.Text = "Free Physical";
			// 
			// label4
			// 
			this.label4.Location = new System.Drawing.Point(136, 20);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(84, 16);
			this.label4.TabIndex = 1;
			this.label4.Text = "Total Virtual";
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(32, 20);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(84, 16);
			this.label2.TabIndex = 0;
			this.label2.Text = "Total Physical";
			// 
			// buttonTips
			// 
			this.buttonTips.IsBalloon = true;
			this.buttonTips.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Info;
			this.buttonTips.ToolTipTitle = "What\'s this?";
			// 
			// memoryTimer
			// 
			this.memoryTimer.Interval = 5000;
			this.memoryTimer.Tick += new System.EventHandler(this.memoryTimer_Tick);
			// 
			// trayNotify
			// 
			this.trayNotify.BalloonTipIcon = System.Windows.Forms.ToolTipIcon.Info;
			this.trayNotify.BalloonTipText = "This will be physical memory.";
			this.trayNotify.BalloonTipTitle = "Physical Memory";
			this.trayNotify.ContextMenuStrip = this.popupTrayIcon;
			this.trayNotify.Icon = ((System.Drawing.Icon)(resources.GetObject("trayNotify.Icon")));
			this.trayNotify.Text = "System Information";
			this.trayNotify.MouseClick += new System.Windows.Forms.MouseEventHandler(this.trayNotify_MouseClick);
			this.trayNotify.MouseDown += new System.Windows.Forms.MouseEventHandler(this.trayNotify_MouseDown);
			this.trayNotify.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.trayNotify_MouseDoubleClick);
			// 
			// popupTrayIcon
			// 
			this.popupTrayIcon.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuRestore,
            this.toolStripSeparator1,
            this.menuExit});
			this.popupTrayIcon.Name = "popupTrayIcon";
			this.popupTrayIcon.Size = new System.Drawing.Size(114, 54);
			this.popupTrayIcon.Text = "System Menu";
			this.popupTrayIcon.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.popupTrayIcon_ItemClicked);
			// 
			// menuRestore
			// 
			this.menuRestore.Image = ((System.Drawing.Image)(resources.GetObject("menuRestore.Image")));
			this.menuRestore.Name = "menuRestore";
			this.menuRestore.Size = new System.Drawing.Size(113, 22);
			this.menuRestore.Text = "Restore";
			// 
			// toolStripSeparator1
			// 
			this.toolStripSeparator1.Name = "toolStripSeparator1";
			this.toolStripSeparator1.Size = new System.Drawing.Size(110, 6);
			// 
			// menuExit
			// 
			this.menuExit.Image = ((System.Drawing.Image)(resources.GetObject("menuExit.Image")));
			this.menuExit.Name = "menuExit";
			this.menuExit.Size = new System.Drawing.Size(113, 22);
			this.menuExit.Text = "Exit";
			// 
			// mainMenu
			// 
			this.mainMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem});
			this.mainMenu.Location = new System.Drawing.Point(0, 0);
			this.mainMenu.Name = "mainMenu";
			this.mainMenu.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional;
			this.mainMenu.Size = new System.Drawing.Size(550, 24);
			this.mainMenu.TabIndex = 1;
			this.mainMenu.Text = "Main Menu";
			// 
			// fileToolStripMenuItem
			// 
			this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.configureMenu,
            this.toolStripMenuItem1,
            this.exitMenu});
			this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
			this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
			this.fileToolStripMenuItem.Text = "&File";
			// 
			// configureMenu
			// 
			this.configureMenu.Image = ((System.Drawing.Image)(resources.GetObject("configureMenu.Image")));
			this.configureMenu.Name = "configureMenu";
			this.configureMenu.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.C)));
			this.configureMenu.Size = new System.Drawing.Size(174, 22);
			this.configureMenu.Text = "&Configure...";
			this.configureMenu.Click += new System.EventHandler(this.configureMenu_Click);
			// 
			// toolStripMenuItem1
			// 
			this.toolStripMenuItem1.Name = "toolStripMenuItem1";
			this.toolStripMenuItem1.Size = new System.Drawing.Size(171, 6);
			// 
			// exitMenu
			// 
			this.exitMenu.Image = ((System.Drawing.Image)(resources.GetObject("exitMenu.Image")));
			this.exitMenu.Name = "exitMenu";
			this.exitMenu.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.F4)));
			this.exitMenu.Size = new System.Drawing.Size(174, 22);
			this.exitMenu.Text = "E&xit";
			this.exitMenu.Click += new System.EventHandler(this.exitMenu_Click);
			// 
			// labelLogicalCPUs
			// 
			this.labelLogicalCPUs.BackColor = System.Drawing.Color.White;
			this.labelLogicalCPUs.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.labelLogicalCPUs.Location = new System.Drawing.Point(492, 68);
			this.labelLogicalCPUs.Name = "labelLogicalCPUs";
			this.labelLogicalCPUs.Size = new System.Drawing.Size(40, 20);
			this.labelLogicalCPUs.TabIndex = 33;
			this.labelLogicalCPUs.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// label23
			// 
			this.label23.Location = new System.Drawing.Point(393, 38);
			this.label23.Name = "label23";
			this.label23.Size = new System.Drawing.Size(95, 20);
			this.label23.TabIndex = 36;
			this.label23.Text = "Number of Cores:";
			this.label23.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label14
			// 
			this.label14.Location = new System.Drawing.Point(393, 8);
			this.label14.Name = "label14";
			this.label14.Size = new System.Drawing.Size(95, 20);
			this.label14.TabIndex = 34;
			this.label14.Text = "Number of CPUs:";
			this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// labelCPUCount
			// 
			this.labelCPUCount.BackColor = System.Drawing.Color.White;
			this.labelCPUCount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.labelCPUCount.Location = new System.Drawing.Point(492, 8);
			this.labelCPUCount.Name = "labelCPUCount";
			this.labelCPUCount.Size = new System.Drawing.Size(40, 20);
			this.labelCPUCount.TabIndex = 35;
			this.labelCPUCount.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// label50
			// 
			this.label50.Location = new System.Drawing.Point(346, 68);
			this.label50.Name = "label50";
			this.label50.Size = new System.Drawing.Size(142, 20);
			this.label50.TabIndex = 32;
			this.label50.Text = "Number of Logical CPUs:";
			this.label50.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// labelCores
			// 
			this.labelCores.BackColor = System.Drawing.Color.White;
			this.labelCores.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.labelCores.Location = new System.Drawing.Point(492, 38);
			this.labelCores.Name = "labelCores";
			this.labelCores.Size = new System.Drawing.Size(40, 20);
			this.labelCores.TabIndex = 37;
			this.labelCores.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// SystemInfoForm
			// 
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
			this.ClientSize = new System.Drawing.Size(550, 576);
			this.Controls.Add(this.mainMenu);
			this.Controls.Add(this.tabSysInfo);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.MainMenuStrip = this.mainMenu;
			this.MaximizeBox = false;
			this.Name = "SystemInfoForm";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "System Information";
			this.WindowState = System.Windows.Forms.FormWindowState.Minimized;
			this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.SystemInfoForm_FormClosed);
			this.SizeChanged += new System.EventHandler(this.SystemInfoForm_SizeChanged);
			this.Load += new System.EventHandler(this.SystemInfoForm_Load);
			this.tabSysInfo.ResumeLayout(false);
			this.pageSystemInfo.ResumeLayout(false);
			this.groupBox3.ResumeLayout(false);
			this.groupBox3.PerformLayout();
			this.groupBox2.ResumeLayout(false);
			this.groupBox1.ResumeLayout(false);
			this.pageVariables.ResumeLayout(false);
			this.popupTrayIcon.ResumeLayout(false);
			this.mainMenu.ResumeLayout(false);
			this.mainMenu.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl tabSysInfo;
        private System.Windows.Forms.TabPage pageSystemInfo;
        private System.Windows.Forms.TabPage pageVariables;
        private System.Windows.Forms.Label lblOSYou;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label lblOSSysDir;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label lblOSWinDir;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label lblOSTS;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label lblOSVer;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label lblOSType;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label lblRevision;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lblSpeed;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label lblSteppingID;
        private System.Windows.Forms.Label lblFamilyID;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lblCPUType;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblCPUVendor;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblFreeVirtual;
        private System.Windows.Forms.Label lblFreePhysical;
        private System.Windows.Forms.Label lblTotalVirtual;
        private System.Windows.Forms.Label lblTotalPhysical;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label loginName;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label systemDirectory;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label windowsDirectory;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label OSVersion;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label OSType;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label revisionCode;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label speedMHz;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label steppingCode;
        private System.Windows.Forms.Label familyCode;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label CPUType;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label vendorID;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label freeVirtual;
        private System.Windows.Forms.Label freePhysical;
        private System.Windows.Forms.Label totalVirtual;
        private System.Windows.Forms.Label totalPhysical;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label CPUIndex;
		private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Button nextCPU;
        private System.Windows.Forms.ToolTip buttonTips;
        private System.Windows.Forms.Button previousCPU;
        private System.Windows.Forms.Timer memoryTimer;
        private System.Windows.Forms.RichTextBox environmentVars;
        private System.Windows.Forms.CheckBox terminalServices;
        private System.Windows.Forms.Label OSEdition;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.ImageList icons;
        private System.Windows.Forms.Label domain;
        private System.Windows.Forms.Label domainCaption;
        private System.Windows.Forms.Label levelCode;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.NotifyIcon trayNotify;
        private System.Windows.Forms.ContextMenuStrip popupTrayIcon;
        private System.Windows.Forms.ToolStripMenuItem menuRestore;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem menuExit;
        private System.Windows.Forms.MenuStrip mainMenu;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem configureMenu;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem exitMenu;
        private System.Windows.Forms.CheckBox checkOneSession;
		private System.Windows.Forms.Label labelLogicalCPUs;
		private System.Windows.Forms.Label label23;
		private System.Windows.Forms.Label label14;
		private System.Windows.Forms.Label labelCPUCount;
		private System.Windows.Forms.Label label50;
		private System.Windows.Forms.Label labelCores;
    }
}