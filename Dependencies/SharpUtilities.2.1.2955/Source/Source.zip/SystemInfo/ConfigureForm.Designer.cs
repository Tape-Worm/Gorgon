namespace SystemInfo
{
    partial class ConfigureForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ConfigureForm));
            this.minimizeToTray = new System.Windows.Forms.CheckBox();
            this.trayOptions = new System.Windows.Forms.GroupBox();
            this.showBalloonOnStart = new System.Windows.Forms.CheckBox();
            this.minimizeOnStart = new System.Windows.Forms.CheckBox();
            this.Cancel = new System.Windows.Forms.Button();
            this.Save = new System.Windows.Forms.Button();
            this.buttonTips = new System.Windows.Forms.ToolTip(this.components);
            this.trayOptions.SuspendLayout();
            this.SuspendLayout();
            // 
            // minimizeToTray
            // 
            this.minimizeToTray.AutoSize = true;
            this.minimizeToTray.Location = new System.Drawing.Point(12, 12);
            this.minimizeToTray.Name = "minimizeToTray";
            this.minimizeToTray.Size = new System.Drawing.Size(104, 17);
            this.minimizeToTray.TabIndex = 0;
            this.minimizeToTray.Text = "&Minimize to tray?";
            this.buttonTips.SetToolTip(this.minimizeToTray, "Checking this item will allow the program to beplaced in the system tray when the" +
                    " minimize button is clicked.");
            this.minimizeToTray.UseVisualStyleBackColor = true;
            this.minimizeToTray.CheckedChanged += new System.EventHandler(this.minimizeToTray_CheckedChanged);
            // 
            // trayOptions
            // 
            this.trayOptions.Controls.Add(this.showBalloonOnStart);
            this.trayOptions.Controls.Add(this.minimizeOnStart);
            this.trayOptions.Enabled = false;
            this.trayOptions.Location = new System.Drawing.Point(12, 35);
            this.trayOptions.Name = "trayOptions";
            this.trayOptions.Size = new System.Drawing.Size(200, 70);
            this.trayOptions.TabIndex = 1;
            this.trayOptions.TabStop = false;
            this.trayOptions.Text = "Tray options.";
            // 
            // showBalloonOnStart
            // 
            this.showBalloonOnStart.AutoSize = true;
            this.showBalloonOnStart.Location = new System.Drawing.Point(7, 43);
            this.showBalloonOnStart.Name = "showBalloonOnStart";
            this.showBalloonOnStart.Size = new System.Drawing.Size(177, 17);
            this.showBalloonOnStart.TabIndex = 1;
            this.showBalloonOnStart.Text = "Show &balloon tooltip on startup?";
            this.buttonTips.SetToolTip(this.showBalloonOnStart, "Checking this item will show a reminder tool balloon when the program is minimize" +
                    "d on start up.");
            this.showBalloonOnStart.UseVisualStyleBackColor = true;
            this.showBalloonOnStart.CheckedChanged += new System.EventHandler(this.showBalloonOnStart_CheckedChanged);
            // 
            // minimizeOnStart
            // 
            this.minimizeOnStart.AutoSize = true;
            this.minimizeOnStart.Location = new System.Drawing.Point(7, 20);
            this.minimizeOnStart.Name = "minimizeOnStart";
            this.minimizeOnStart.Size = new System.Drawing.Size(125, 17);
            this.minimizeOnStart.TabIndex = 0;
            this.minimizeOnStart.Text = "Minimize on start &up?";
            this.buttonTips.SetToolTip(this.minimizeOnStart, "Checking this item will make the program automatically minimize when the program " +
                    "loads.");
            this.minimizeOnStart.UseVisualStyleBackColor = true;
            this.minimizeOnStart.CheckedChanged += new System.EventHandler(this.minimizeOnStart_CheckedChanged);
            // 
            // Cancel
            // 
            this.Cancel.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Cancel.Image = ((System.Drawing.Image)(resources.GetObject("Cancel.Image")));
            this.Cancel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Cancel.Location = new System.Drawing.Point(144, 111);
            this.Cancel.Name = "Cancel";
            this.Cancel.Size = new System.Drawing.Size(68, 23);
            this.Cancel.TabIndex = 2;
            this.Cancel.Text = "&Cancel";
            this.Cancel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttonTips.SetToolTip(this.Cancel, "This button will close without saving the current configuration to the registry.");
            this.Cancel.UseVisualStyleBackColor = true;
            this.Cancel.Click += new System.EventHandler(this.Cancel_Click);
            // 
            // Save
            // 
            this.Save.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Save.Image = ((System.Drawing.Image)(resources.GetObject("Save.Image")));
            this.Save.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Save.Location = new System.Drawing.Point(12, 111);
            this.Save.Name = "Save";
            this.Save.Size = new System.Drawing.Size(61, 23);
            this.Save.TabIndex = 3;
            this.Save.Text = "&Save";
            this.Save.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttonTips.SetToolTip(this.Save, "This button will save the current configuration to the registry.");
            this.Save.UseVisualStyleBackColor = true;
            this.Save.Click += new System.EventHandler(this.Save_Click);
            // 
            // buttonTips
            // 
            this.buttonTips.IsBalloon = true;
            this.buttonTips.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Info;
            this.buttonTips.ToolTipTitle = "What\'s this?";
            // 
            // ConfigureForm
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(225, 142);
            this.Controls.Add(this.Save);
            this.Controls.Add(this.Cancel);
            this.Controls.Add(this.trayOptions);
            this.Controls.Add(this.minimizeToTray);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "ConfigureForm";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Configuration";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.ConfigureForm_FormClosing);
            this.Load += new System.EventHandler(this.ConfigureForm_Load);
            this.trayOptions.ResumeLayout(false);
            this.trayOptions.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.CheckBox minimizeToTray;
        private System.Windows.Forms.GroupBox trayOptions;
        private System.Windows.Forms.CheckBox showBalloonOnStart;
        private System.Windows.Forms.CheckBox minimizeOnStart;
        private System.Windows.Forms.Button Cancel;
        private System.Windows.Forms.Button Save;
        private System.Windows.Forms.ToolTip buttonTips;
    }
}