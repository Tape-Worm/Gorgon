#region LGPL.
// 
// SharpUtils.
// Copyright (C) 2005 Michael Winsor
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
// 
// Created: Sunday, October 23, 2005 11:53:15 AM
// 
#endregion

using System;

namespace SystemInfo_Console
{
	/// <summary>
	/// Class to represent menu items.
	/// </summary>
	public class MenuItem
	{
		#region Variables.
		private SystemInformation menuApp;	// Application object for the menu.
		private string menuText;			// Menu text.
		private short menuLeft;				// Menu left position.
		private short menuTop;				// Menu top position.
		private short menuWidth;			// Menu item width.
		private bool menuMouseOver;			// Flag to indicate that the mouse cursor is over the item.
		private bool menuEnabled;			// Flag to indicate that this item is enabled or disabled.
		#endregion

		#region Properties.
		/// <summary>
		/// Property to set or return the caption for the menu item.
		/// </summary>
		public string Text
		{
			get
			{
				return menuText;
			}
			set
			{
				menuText = value;
				Paint();
			}
		}

		/// <summary>
		/// Property to set the left (horizontal) position of the item.
		/// </summary>
		public short Left
		{
			get
			{
				return menuLeft;
			}
			set
			{
				menuLeft = value;
				Paint();
			}
		}

		/// <summary>
		/// Property to set the top (vertical) position of the item.
		/// </summary>
		public short Top
		{
			get
			{
				return menuTop;
			}
			set
			{
				menuTop = value;
				Paint();
			}
		}

		/// <summary>
		/// Property to set or return the width of the menu item.
		/// </summary>
		public short Width
		{
			get
			{
				return menuWidth;
			}
			set
			{
				menuWidth = value;
			}
		}

		/// <summary>
		/// Property to set or return whether this item is enabled or not.
		/// </summary>
		public bool Enabled
		{
			get
			{
				return menuEnabled;
			}
			set
			{
				menuEnabled = value;
				Paint();
			}
		}
		#endregion

		#region Methods.
		/// <summary>
		/// Function to paint the menu item.
		/// </summary>
		public void Paint()
		{
			menuApp.Console.CursorLeft = menuLeft;
			menuApp.Console.CursorTop = menuTop;

			// Draw menu.
			if ((menuMouseOver) && (menuEnabled))
			{
				menuApp.Console.ForegroundColor = ConsoleColor.Cyan;
				menuApp.Console.BackgroundColor = ConsoleColor.Blue;
				menuApp.Console.Print("{0}{1}{2}",'\x00B3',menuText,'\x00B3');
			}
			else
			{
				if (menuEnabled)
				{
					menuApp.Console.ForegroundColor = ConsoleColor.Cyan;
					menuApp.Console.BackgroundColor = ConsoleColor.Black;
					menuApp.Console.Print("{0}{1}{2}",'\x00B3',menuText,'\x00B3');
				}
				else
				{
					menuApp.Console.ForegroundColor = ConsoleColor.Gray;
					menuApp.Console.BackgroundColor = ConsoleColor.Black;
					menuApp.Console.Print("{0}{1}{2}",'\x00B3',menuText,'\x00B3');
				}
			}
		}

		/// <summary>
		/// Function to perform a hit test on this menu item.
		/// </summary>
		/// <param name="x">Horizontal position to test.</param>
		/// <param name="y">Vertical position to test.</param>
		/// <returns>TRUE if position is over the item, FALSE if not.</returns>
		public bool HitTest(short x,short y)
		{
			bool prevMouseOver = menuMouseOver;		// Previous mouse over.

			if ((x>=menuLeft) && (x<=(menuLeft + menuWidth)) && (y == menuTop))
				menuMouseOver = true;
			else
				menuMouseOver = false;

			if (prevMouseOver != menuMouseOver)
				Paint();

			return menuMouseOver;
		}
		#endregion

		#region Constructor/Destructor.
		/// <summary>
		/// Constructor.
		/// </summary>
		/// <param name="app">Application object.</param>
		/// <param name="left">Left position of the item.</param>
		/// <param name="top">Top position of the item.</param>
		/// <param name="caption">Caption for the item.</param>
		public MenuItem(SystemInformation app,string caption,short left,short top)
		{
			menuApp = app;
			menuMouseOver = false;
			menuText = caption;
			menuLeft = left;
			menuTop = top;
			menuWidth = (short)(caption.Length + 1);
			menuEnabled = true;
		}
		#endregion

	}
}
