#region LGPL.
// 
// SharpUtils.
// Copyright (C) 2005 Michael Winsor
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
// 
// Created: Sunday, October 23, 2005 1:31:24 PM
// 
#endregion

using System;
using SharpUtilities;
using SharpUtilities.Native.Win32;

namespace SystemInfo_Console
{
	/// <summary>
	/// Object to handle timing operations.
	/// </summary>
	/// <remarks>
	/// Timers are used to regulate and measure time elapsed for frames, or maintaining consistent
	/// frame rate for animations, to just simple countdowns.
	/// </remarks>
	public class PreciseTimer
	{
		#region Variables.
		internal bool timerSystem;			// Flag to indicate that this is a system timer.
		private long timerStartTime;		// Start time for the timer.
		private long timerFrequency;		// Frequency of hi performance timer.
		private bool timerUsePrecise;		// Flag to indicate whether we're using hi performance timers.
		private long timerStartTick;		// Starting timer tick.
		#endregion

		#region Properties.
		/// <summary>
		/// Property to get the number of milliseconds elapsed since the timer was started.
		/// </summary>
		public double Milliseconds
		{
			get
			{
				long currentTime = 0;	// Current time.
				ulong time;				// Elapsed time.
				ulong check;			// Timer check.
				long diff;				// Time difference.

				if (timerUsePrecise)
				{
					Win32API.QueryPerformanceCounter(ref currentTime);
					time = (ulong)(((currentTime - timerStartTime) * 1000)/timerFrequency);

					// Compensate for timer drift on crappy motherboards (VIA, etc...).
					// See KB Q274323.
					check = (ulong)(Win32API.GetTickCount() - timerStartTick);
					diff = (long)(time - check);

					if ((diff < -100) && (diff > 100))
					{
						timerStartTime += (diff * timerFrequency) / 1000;
						time = check;
					}

					return (double)time;
				} 
				else
					return (double)(Win32API.timeGetTime() - timerStartTime);
			}
		}

		/// <summary>
		/// Property to get the number of microseconds elapsed since the timer was started.
		/// </summary>
		public double Microseconds
		{
			get
			{
				long currentTime = 0;	// Current time.
				ulong time;				// Elapsed time.
				ulong check;			// Timer check.
				long diff;				// Time difference.


				if (timerUsePrecise)
				{
					Win32API.QueryPerformanceCounter(ref currentTime);
					time = (ulong)(((currentTime - timerStartTime) * 1000000) / timerFrequency);

					// Compensate for timer drift on crappy motherboards (VIA, etc...).
					// See KB Q274323.
					check = (ulong)(Win32API.GetTickCount() - timerStartTick);
					diff = (long)((time/1000) - check);

					if ((diff < -100) && (diff > 100))
					{
						timerStartTime += (diff * timerFrequency) / 1000;
						time = time - (ulong)(diff * 1000);
					}

					return (double)time;
				}
				else
					return (double)(Win32API.timeGetTime()- timerStartTime) / 1000;	// This will probably be quite inaccurate.
			}
		}
		#endregion

		#region Methods.
		/// <summary>
		/// Function to reset the timer.
		/// </summary>
		public void Reset()
		{
			// Reset the start time.
			if (timerUsePrecise)
				Win32API.QueryPerformanceCounter(ref timerStartTime);
			else
				timerStartTime = Win32API.timeGetTime();
		}

		/// <summary>
		/// Function to convert the desired frames per second to milliseconds.
		/// </summary>
		/// <param name="FPS">Desired frames per second.</param>
		/// <returns>Frames per second in milliseconds.</returns>
		public static double FPSToMilliseconds(double FPS)
		{
			if (FPS > 0)
				return (1000/(FPS + 3));
			else
				return 0;
		}

		/// <summary>
		/// Function to convert the desired frames per second to microseconds.
		/// </summary>
		/// <param name="FPS">Desired frames per second.</param>
		/// <returns>Frames per second in microseconds.</returns>
		public static double FPSToMicroseconds(double FPS)
		{
			if (FPS > 0)
				return (1000000/(FPS + 3));
			else
				return 0;
		}
		#endregion

		#region Constructors/Destructors.
		/// <summary>
		/// Constructor.
		/// </summary>
		/// <param name="timername">Name of this timer.</param>
		internal PreciseTimer()
		{
			timerStartTime = 0;
			timerFrequency = 0;
			timerUsePrecise = false;
			timerSystem = false;
			timerStartTick = Win32API.GetTickCount();

			// Check for precise timer.
			Win32API.QueryPerformanceFrequency(ref timerFrequency);
			
			if (timerFrequency != 0)
				timerUsePrecise = true;		

			Reset();
		}
		#endregion
	}
}
