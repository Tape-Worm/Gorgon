#region LGPL.
// 
// SharpUtils.
// Copyright (C) 2005 Michael Winsor
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
// 
// Created: Sunday, October 23, 2005 11:28:19 AM
// 
#endregion

using System;
using SharpUtilities;
using SharpUtilities.Console;
using SharpUtilities.Utility;

namespace SystemInfo_Console
{
	/// <summary>
	/// Main class for system information program.
	/// </summary>
	public class SystemInformation : IDisposable
	{
		#region Variables.
		private ConsoleApplication _application;		// Application object.
		private YourComputer _systemInfo;		            // System information.
		private MenuItem _menuVariables;	            // Environment variable menu.
		private MenuItem _menuNext;	                    // Next processor item.
		private MenuItem _menuPrevious;	                // Previous processor item.
		private MenuItem _menuQuit;	                    // Quit menu.
		private int _currentCPU;			            // Current processor.
		private PreciseTimer _timer;	                // Timer for updating.
		private double _startTime;	                    // Start timer.
		private bool _displayVariables;			        // Flag to indicate that variables are displaying.
		#endregion

		#region Properties.
		/// <summary>
		/// Property to return a formatted string containing CPU information.
		/// </summary>
		private string GetCPUInfo
		{
			get
			{
				string result;		                // Result string.
                float[] mem = new float[4];         // Memory values.
                string[] memUnit = new String[4];   // Memory units.
                string unit;                        // Unit used to measure speed.
                float speed;                        // Speed.
                int i;                              // Loop.                

                for (i = 0; i < 4; i++)
                    memUnit[i] = " KB";

                speed = _systemInfo.CPU[_currentCPU].Speed;

                if (_systemInfo.CPU[_currentCPU].Speed < 1000.0f)
                    unit = " MHz";
                else
                {
                    speed = speed / 1000.0f;
                    unit = " GHz";
                }

                mem[0] = _systemInfo.TotalVirtual;
                mem[1] = _systemInfo.TotalPhysical;
                mem[2] = _systemInfo.FreePhysical;
                mem[3] = _systemInfo.FreeVirtual;

                // Update.
                for (i = 0; i < 4; i++)
                {
                    if ((mem[i] >= 1000.0f) && (mem[i] < 1000000.0f))
                    {
                        mem[i] /= 1024.0f;
                        memUnit[i] = " MB";
                    }

                    if (mem[i] >= 1000000.0f)
                    {
                        mem[i] /= 1048576.0f;
                        memUnit[i] = " GB";
                    }
                }

				result = "Current CPU #: " + string.Format("{0}", _currentCPU + 1) + "/" + _systemInfo.CPU.Count;
				if ((_systemInfo.OSType == OSTypes.WindowsVista) || (_systemInfo.OSType == OSTypes.WindowsFuture))
				{
					result += " (# of Cores: " + _systemInfo.CPU[_currentCPU].CoreCount.ToString() + ", # of Logical CPUs: " +
							_systemInfo.CPU[_currentCPU].LogicalCPUCount.ToString() + ")\n";
				}
				result += "CPU Vendor ID: " + _systemInfo.CPU[_currentCPU].Vendor + "\nCPU Type: ";
				result += _systemInfo.CPU[_currentCPU].Name;
				result += "\nRunning at: " + speed.ToString("0.00") + unit + "\n";
				result += "Family: " + _systemInfo.CPU[_currentCPU].Family + "\n";
                result += "Level: " + _systemInfo.CPU[_currentCPU].Level + "\n";
				result += "Revision: " + _systemInfo.CPU[_currentCPU].Revision + "\n";
				result += "Stepping: " + _systemInfo.CPU[_currentCPU].Stepping + "\n";
                result += "Total memory:\n";
                result += "Physical: " + mem[1].ToString("0.0") + memUnit[1] + "\t";
				result += "Virtual: " + mem[0].ToString("0.0") + memUnit[0] + "\n";
                result += "Free memory:\n";
				result += "Physical: " + mem[2].ToString("0.0") + memUnit[2] + "\t";
                result += "Virtual: " + mem[3].ToString("0.0") + memUnit[3] + "\n";

				return result + "\n";
			}
		}

		/// <summary>
		/// Property to return a formatted string containing the Operating System information.
		/// </summary>
		private string GetOSInfo
		{
			get
			{
				string result = "";		// Result string.
				string SPInfo;			// Service pack information.

				result = "OS: ";

				switch(_systemInfo.OSType)
				{
					case OSTypes.Windows95:
						result += "Windows 95 (Time to upgrade don't you think?)";					
						break;
					case OSTypes.Windows95OSR2:
						result += "Windows 95 OSR2 (UPGRADE ALREADY!!)";
						break;
					case OSTypes.Windows98:
						result += "Windows 98";
						break;
					case OSTypes.Windows98SE:
						result += "Windows 98 SE";
						break;
					case OSTypes.WindowsNT4:
						result += "Windows NT 4.0";
						break;
					case OSTypes.WindowsME:
						result += "Windows Millenium Edition (You sorry bastard.)";
						break;
					case OSTypes.Windows2000:
						result += "Windows 2000";
						break;
					case OSTypes.WindowsCE:
						result += "Windows CE";
						break;
					case OSTypes.WindowsXP:
						result += "Windows XP";
						break;
					case OSTypes.Windows2003:
						result += "Windows 2003";
						break;
                    case OSTypes.WindowsVista:
                        result += "Windows Vista";
                        break;
					case OSTypes.WindowsFuture:
						result += "Future version of Windows";
						break;
					default:
						result += "Unknown.";
						break;
				}

				switch(_systemInfo.OSExtensions)
				{
					case OSExtensions.Home:
						result += " Home";
						break;
					case OSExtensions.CommunicationServer:
						result += " Communication Server";
						break;
					case OSExtensions.DataCenter:
						result += " Data Center";
						break;
					case OSExtensions.Embedded:
						result += " Embedded";
						break;
					case OSExtensions.Enterprise:
						result += " Enterprise";
						break;
					case OSExtensions.Professional:
						result += " Professional";
						break;
					case OSExtensions.Server:
						result += " Server";
						break;
					case OSExtensions.SmallBusiness:
						result += " Small Business Server";
						break;
					case OSExtensions.SmallBusinessRestricted:
						result += " Small Business Server (Restricted)";
						break;
					case OSExtensions.Workstation:
						result += " Workstation.";
						break;
					case OSExtensions.Business:
						result += " Business.";
						break;
					case OSExtensions.BusinessN:
						result += " Business N.";
						break;
					case OSExtensions.EnterpriseServer:
						result += " Enterprise Server.";
						break;
					case OSExtensions.HomeBasic:
						result += " Home Basic.";
						break;
					case OSExtensions.HomeBasicN:
						result += " Home Basic N.";
						break;
					case OSExtensions.HomePremium:
						result += " Home Premium.";
						break;
					case OSExtensions.Starter:
						result += " Starter.";
						break;
					case OSExtensions.Ultimate:
						result += " Ultimate.";
						break;
				}

				SPInfo = "";
				if (_systemInfo.OSBuildNumber.Length > 0)
					SPInfo = " Build " + _systemInfo.OSBuildNumber;

				if (_systemInfo.OSServicePack.Length > 0) 
				{
					if (SPInfo.Length > 0)
						SPInfo += ", ";

					SPInfo += _systemInfo.OSServicePack;
				}

				result += "\nVersion: " + _systemInfo.OSVersion + SPInfo;
				result += "\nTerminal Services: ";
				if (_systemInfo.HasTerminalServices)
					result += "Y";
				else
					result += "N";
                result += "\tOnly one session: ";
                if (_systemInfo.HasLimitedTerminalSessions)
                    result += "Y";
                else
                    result += "N";

				result += "\nComputer Name: " + _systemInfo.ComputerName;
                if (_systemInfo.IsPartOfDomain)
                    result += "\nDomain Name: " + _systemInfo.DomainName;
                else
                    result += "\nWorkgroup Name: " + _systemInfo.DomainName;
				result += "\nYou are: " + _systemInfo.UserName;
				result += "\nWindows directory: " + _systemInfo.OSWindowsDirectory;
				result += "\nSystem directory: " + _systemInfo.OSSystemDirectory;

				return result;
			}
		}

		/// <summary>
		/// Property to return the console interface.
		/// </summary>
		public ConsoleApplication Console
		{
			get
			{
				return _application;
			}
		}
		#endregion

		#region Methods.
		/// <summary>
		/// Function to update the screen.
		/// </summary>
		private void Update()
		{
			_application.BackgroundColor = ConsoleColor.DarkBlue;
			_application.ForegroundColor = ConsoleColor.White;
			_application.Clear();

			_application.BufferWidth = 80;
			if (!_displayVariables)
			{
				_application.BufferHeight = 25;
				_application.ForegroundColor = ConsoleColor.Yellow;
				_application.Print("Machine Info.\n");
				_application.ForegroundColor = ConsoleColor.White;
				_application.Print(GetCPUInfo);

				_application.ForegroundColor = ConsoleColor.Yellow;
				_application.Print("Operating System Info.\n");
				_application.ForegroundColor = ConsoleColor.White;
				_application.Print(GetOSInfo);

				if (_systemInfo.CPU.Count > 1)
				{
					if (_currentCPU < 1)
						_menuPrevious.Enabled = false;
					else
						_menuPrevious.Enabled = true;

					if (_currentCPU >= _systemInfo.CPU.Count-1)
						_menuNext.Enabled = false;
					else
						_menuNext.Enabled = true;
				}

				_menuVariables.Paint();
				_menuNext.Paint();
				_menuPrevious.Paint();
				_menuQuit.Paint();
			} 
			else
			{	
				_application.BufferHeight = 256;

				for (int i=0;i<_systemInfo.EnvironmentVariables.Count;i++)
				{
					_application.ForegroundColor = ConsoleColor.Yellow;
					_application.Print("{0} = ",_systemInfo.EnvironmentVariables[i].Name);
					_application.ForegroundColor = ConsoleColor.White;
					_application.Print("{0}\n\n",_systemInfo.EnvironmentVariables[i].Value);
				}

				_application.ForegroundColor = ConsoleColor.White;
				_application.BackgroundColor = ConsoleColor.Black;
				_application.Print("Press any key to return to CPU info.");
				_application.AnyKey();
				_displayVariables = false;
				Update();
			}
		}

		/// <summary>
		/// Function to handle keyboard events.
		/// </summary>
		/// <param name="sender">Sender of this event.</param>
		/// <param name="e">Event parameters.</param>
		private void OnKey(object sender,ConsoleKeyArgs e)
		{
			if (!_displayVariables)
			{
				if (e.Key == System.Windows.Forms.Keys.Escape)
					_application.Stop();

				if (e.Key == System.Windows.Forms.Keys.F1)
				{
					_displayVariables = true;
					Update();
				}

				if (_systemInfo.CPU.Count > 1)
				{
					if (e.Key == System.Windows.Forms.Keys.Oemplus)
					{
						_currentCPU++;
						if (_currentCPU>=_systemInfo.CPU.Count-1)
							_currentCPU = _systemInfo.CPU.Count;
						Update();					
					}

					if (e.Key == System.Windows.Forms.Keys.OemMinus)
					{
						_currentCPU--;
						if (_currentCPU<1)
							_currentCPU = 0;
						Update();
					}
				}
			}
		}

		/// <summary>
		/// Function to handle mouse events.
		/// </summary>
		/// <param name="sender">Sender of this event.</param>
		/// <param name="e">Event parameters.</param>
		private void OnMouse(object sender,ConsoleMouseArgs e)
		{
			if (!_displayVariables)
			{
				if (_menuVariables.HitTest((short)e.X,(short)e.Y))
				{
					if (e.ShiftDoubleClick)
					{
						_displayVariables = true;
						Update();
					}
				}

				if (_menuQuit.HitTest((short)e.X,(short)e.Y))
				{
					if (e.ShiftDoubleClick)
						_application.Stop();
				}

				// Move to next CPU.
				if (_systemInfo.CPU.Count > 1)
				{
					if (_menuNext.HitTest((short)e.X,(short)e.Y))
					{
						if (e.ShiftDoubleClick)
						{
							_currentCPU++;
							if (_currentCPU>=_systemInfo.CPU.Count-1)
								_currentCPU = _systemInfo.CPU.Count;
							Update();					
						}
					}

					if (_menuPrevious.HitTest((short)e.X,(short)e.Y))
					{
						if (e.ShiftDoubleClick)
						{
							_currentCPU--;
							if (_currentCPU<1)
								_currentCPU = 0;
							Update();
						}
					}
				}
			}
		}

		/// <summary>
		/// Function to update the memory display.
		/// </summary>
		private void UpdateMemory()
		{
            float[] mem = new float[4];         // Memory values.
            string[] memUnit = new String[4];   // Memory units.
            int i;                              // Loop.

            mem[0] = _systemInfo.TotalVirtual;
            mem[1] = _systemInfo.TotalPhysical;
            mem[2] = _systemInfo.FreePhysical;
            mem[3] = _systemInfo.FreeVirtual;

            // Update.
            for (i = 0; i < 4; i++)
            {
                if ((mem[i] >= 1000.0f) && (mem[i] < 1000000.0f))
                {
                    mem[i] /= 1024.0f;
                    memUnit[i] = " MB";
                }

                if (mem[i] >= 1000000.0f)
                {
                    mem[i] /= 1048576.0f;
                    memUnit[i] = " GB";
                }
            }

            _application.ForegroundColor = ConsoleColor.White;
			_application.BackgroundColor = ConsoleColor.DarkBlue;

			_application.CursorLeft = 0;
			_application.CursorTop = 10;
			_application.Print("{0,70}"," ");
			_application.CursorLeft = 0;
			_application.CursorTop = 10;
			_application.Print("Physical: " + mem[1].ToString("0.0") + memUnit[1] + "\t");
            _application.Print("Virtual: " + mem[0].ToString("0.0") + memUnit[0] + "\n");
            _application.CursorLeft = 0;
            _application.CursorTop = 12;
            _application.Print("{0,70}", " ");
			_application.CursorLeft = 0;
			_application.CursorTop = 12;
            _application.Print("Physical: " + mem[2].ToString("0.0") + memUnit[2] + "\t");
            _application.Print("Virtual: " + mem[3].ToString("0.0") + memUnit[3] + "\n");
		}

		/// <summary>
		/// Function to process idle events.
		/// </summary>
		/// <param name="sender">Sender of this event.</param>
		/// <param name="e">Event parameters.</param>
		private void OnIdle(object sender,ConsoleIdleArgs e)
		{
			double currentTime;	// Current time.

			currentTime = _timer.Milliseconds;

			// Update.
			if (((currentTime - _startTime) > 5000) && (!_displayVariables))
			{
				_startTime = currentTime;
				UpdateMemory();
			}
		}

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main(string[] args)
		{
			SystemInformation app;		// Main application.

			app = new SystemInformation();
			app.Console.Run();
			app.Dispose();
			app = null;
		}
		#endregion

		#region Constructor/Destructor.
		/// <summary>
		/// Constructor.
		/// </summary>
		public SystemInformation()
		{
			_application = new ConsoleApplication();
			_application.Caption = "System Information";
			_application.OnKeyAction += new ConsoleKeyEvent(OnKey);
			_application.OnMouseAction += new ConsoleMouseEvent(OnMouse);
			_application.OnIdle += new ConsoleIdleEvent(OnIdle);
			_application.CursorVisible = false;
			_application.CodePage = 1252;
			_displayVariables = false;
			_systemInfo = new YourComputer();

			_menuVariables = new MenuItem(this,"F1 - List environment variables.",0,24);			
			_menuPrevious = new MenuItem(this,"- Previous CPU",35,24);
			_menuNext = new MenuItem(this,"+ Next CPU",52,24);
			_menuQuit = new MenuItem(this,"ESC - Quit.",65,24);

			if (_systemInfo.CPU.Count < 2)
			{
				_menuPrevious.Enabled = false;
				_menuNext.Enabled = false;
			}
			
			_timer = new PreciseTimer();
			_startTime = _timer.Milliseconds;

			_currentCPU = 0;
			
			Update();
		}

		/// <summary>
		/// Destructor.
		/// </summary>
		~SystemInformation()
		{
			Dispose(false);
		}
		#endregion

		#region IDisposable Members
		/// <summary>
		/// Function to perform clean up.
		/// </summary>
		/// <param name="disposing">TRUE to dispose all objects, FALSE to only remove unmanaged.</param>
		private void Dispose(bool disposing)
		{
			if (disposing)
			{
				_systemInfo.Dispose();
				_application.Dispose();
			}

			_systemInfo = null;
			_application = null;
		}

		/// <summary>
		/// Function to perform clean up.
		/// </summary>
		public void Dispose()
		{
			Dispose(true);
			GC.SuppressFinalize(this);
		}
		#endregion
	}
}
