#region LGPL.
// 
// SharpUtils.
// Copyright (C) 2005 Michael Winsor
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
// 
// Created: Sunday, December 11, 2005 6:06:24 PM
// 
#endregion

using System;

namespace SharpUtilities.Console
{
    /// <summary>
    /// Window size exception.
    /// </summary>
    /// <remarks>Exception thrown when the size is invalid for a console window.</remarks>
	public class WindowSizeException : SharpException
	{
		#region Constructor.
		/// <summary>
		/// Constructor.
		/// </summary>
		/// <param name="message">Message to pass through to the exception.</param>
		/// <param name="errorCode">Error code to pass through to the exception.</param>
		public WindowSizeException(string message, ConsoleErrorCodes errorCode)
			: base(message, (int)errorCode)
		{
		}

		/// <summary>
		/// Constructor.
		/// </summary>
		public WindowSizeException()
			: this("The window size cannot exceed the size of the console buffer or be less than 2 characters.",ConsoleErrorCodes.WindowSizeOutOfBounds)
		{
		}
		#endregion
	}

    /// <summary>
    /// Cursor height exception.
    /// </summary>
    /// <remarks>Exception thrown when the value entered for the cursor height is invalid.</remarks>
	public class CursorHeightException : SharpException
	{
		#region Constructor.
		/// <summary>
		/// Constructor.
		/// </summary>
		/// <param name="message">Message to pass through to the exception.</param>
		/// <param name="errorCode">Error code to pass through to the exception.</param>
		public CursorHeightException(string message, ConsoleErrorCodes errorCode)
			: base(message, (int)errorCode)
		{
		}

		/// <summary>
		/// Constructor.
		/// </summary>
		/// <param name="size">Requested size of the cursor.</param>
		public CursorHeightException(int size)
			: this("The cursor size [" + size.ToString() + "] cannot exceed 127 or be less than 0.", ConsoleErrorCodes.CursorHeightInvalid)
		{
		}
		#endregion
	}

    /// <summary>
    /// Cursor position exception.
    /// </summary>
    /// <remarks>Exception thrown when a console cursor is outside of the console boundaries.</remarks>
	public class CursorPositionException : SharpException
	{
		#region Constructor.
		/// <summary>
		/// Constructor.
		/// </summary>
		/// <param name="message">Message to pass through to the exception.</param>
		/// <param name="errorCode">Error code to pass through to the exception.</param>
		public CursorPositionException(string message, ConsoleErrorCodes errorCode)
			: base(message, (int)errorCode)
		{
		}

		/// <summary>
		/// Constructor.
		/// </summary>
		/// <param name="verticalPosition">TRUE if the vertical position is out of bounds, FALSE if horizontal.</param>
		/// <param name="position">Position that is out of bounds.</param>
		public CursorPositionException(bool verticalPosition, int position)
			: this((verticalPosition) ? "The vertical cursor position [" + position.ToString() + "] cannot be outside of the buffer height." : "The horizontal cursor position [" + position.ToString() + "] cannot be outside of the buffer width.", 
			ConsoleErrorCodes.InvalidCursorPosition)
		{
		}
		#endregion
	}

    /// <summary>
    /// String buffer overflow exception.
    /// </summary>
    /// <remarks>Exception thrown when an attempt to read more data into a string buffer than is allocated.</remarks>
	public class StringBufferException : SharpException
	{
		#region Constructor.
		/// <summary>
		/// Constructor.
		/// </summary>
		/// <param name="message">Message to pass through to the exception.</param>
		/// <param name="errorCode">Error code to pass through to the exception.</param>
		public StringBufferException(string message, ConsoleErrorCodes errorCode)
			: base(message, (int)errorCode)
		{
		}

		/// <summary>
		/// Constructor.
		/// </summary>
		/// <param name="bufferSize">Size of the string buffer that caused the exception.</param>
		public StringBufferException(int bufferSize)
			: this("The string buffer size [" + bufferSize.ToString() + "]is out of bounds.",ConsoleErrorCodes.InvalidStringBuffer)
		{
		}
		#endregion
	}
}
