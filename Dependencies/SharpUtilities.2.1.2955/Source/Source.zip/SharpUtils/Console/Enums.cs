#region LGPL.
// 
// SharpUtils.
// Copyright (C) 2005 Michael Winsor
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
// 
// Created: Sunday, December 11, 2005 6:07:54 PM
// 
#endregion

using System;

namespace SharpUtilities.Console
{
	/// <summary>
	/// Enumeration containing console error codes.
	/// </summary>
	public enum ConsoleErrorCodes
	{
		/// <summary>
		/// Window size is does not fit within buffer size.
		/// </summary>
		WindowSizeOutOfBounds = 0x6F000001,
		/// <summary>
		/// Cursor height is invalid.
		/// </summary>
		CursorHeightInvalid = 0x6F000002,
		/// <summary>
		/// Position of the cursor is out of bounds.
		/// </summary>
		InvalidCursorPosition = 0x6F000003,
		/// <summary>
		/// Size of the string buffer is invalid.
		/// </summary>
		InvalidStringBuffer = 0x6F000004
	}
}