#region LGPL.
// 
// SharpUtils.
// Copyright (C) 2005 Michael Winsor
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
// 
// Created: Wednesday, October 19, 2005 3:20:03 PM
// 
#endregion

using System;
using System.Windows.Forms;

namespace SharpUtilities
{
    namespace Console
    {
        /// <summary>
        /// Mouse event arguments.
        /// </summary>
        public class ConsoleMouseArgs : EventArgs
        {
            #region Variables.
            /// <summary>Flag to indicate the left mouse button is pressed.</summary>
            public bool Left;
            /// <summary>Flag to indicate the middle mouse button is pressed.</summary>
            public bool Middle;
            /// <summary>Flag to indicate the right mouse button is pressed.</summary>
            public bool Right;
            /// <summary>Flag to indicate the shift key is pressed.</summary>
            public bool ShiftShift;
            /// <summary>Flag to indicate the alt key is pressed.</summary>
            public bool ShiftAlt;
            /// <summary>Flag to indicate the ctrl key is pressed.</summary>
            public bool ShiftCtrl;
            /// <summary>Double click.</summary>
            public bool ShiftDoubleClick;
            /// <summary>Horizontal position of the mouse cursor.</summary>
            public int X;
            /// <summary>Vertical position of the mouse cursor.</summary>
            public int Y;
            #endregion
        }

        /// <summary>
        /// Idle event arguments.
        /// </summary>
        public class ConsoleIdleArgs : EventArgs
        {
            #region Variables.
            /// <summary>Flag to indicate that we're done.</summary>
            public bool Done;
            #endregion
        }

        /// <summary>
        /// Close event arguments.
        /// </summary>
        public class ConsoleCloseArgs : EventArgs
        {
            #region Variables.
            /// <summary>Flag to indicate that we wish to cancel the close operation.</summary>
            public bool Cancel;
            #endregion
        }

        /// <summary>
        /// Key event arguments.
        /// </summary>
        public class ConsoleKeyArgs : EventArgs
        {
            #region Variables.
            /// <summary>Key that's been pressed.</summary>
            public Keys Key;
            /// <summary>Character.</summary>
            public char Char;
            /// <summary>Flag to indicate the shift key is pressed.</summary>
            public bool ShiftShift;
            /// <summary>Flag to indicate the alt key is pressed.</summary>
            public bool ShiftAlt;
            /// <summary>Flag to indicate the ctrl key is pressed.</summary>
            public bool ShiftCtrl;
            #endregion
        }

        /// <summary>
        /// Event definition for console mouse events.
        /// </summary>
        public delegate void ConsoleMouseEvent(object Sender, ConsoleMouseArgs e);

        /// <summary>
        /// Event definition for console close events.
        /// </summary>
        public delegate void ConsoleCloseEvent(object Sender, ConsoleCloseArgs e);

        /// <summary>
        /// Event definition for console idle event.
        /// </summary>
        public delegate void ConsoleIdleEvent(object Sender, ConsoleIdleArgs e);

        /// <summary>
        /// Event definition for console key events.
        /// </summary>
        public delegate void ConsoleKeyEvent(object Sender, ConsoleKeyArgs e);
    }
}
