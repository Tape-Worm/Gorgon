#region LGPL.
// 
// SharpUtils.
// Copyright (C) 2005 Michael Winsor
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
// 
// Created: Tuesday, October 18, 2005 1:36:24 PM
// 
#endregion

using System;
using System.Text;
using System.Windows.Forms;
using SharpUtilities.Native;
using SharpUtilities.Native.Win32;

namespace SharpUtilities
{
    namespace Console
    {
        /// <summary>
        /// Class used to handle console operations.
        /// </summary>
        public sealed class ConsoleApplication : IDisposable
        {
            #region Variables.
            private IntPtr _outHandle;						    // Console output handle.
            private IntPtr _inHandle;							// Console input handle.
            private CHAR_INFO[] _oldBuffer;						// Old buffer information.
            private int _oldCursorLeft;			                // Old cursor horizontal position.
            private int _oldCursorTop;			                // Old cursor vertical position.
            private int _oldSizeWidth;                          // Old console window width.
            private int _oldSizeHeight;                         // Old console window height.
            private ConsoleColor _foregroundColor;			    // Foreground color for console.
            private ConsoleColor _backgroundColor;			    // Background color for console.
            private String _oldCaption;				            // Old caption for the window.
            private ConsoleModeFlags _oldInFlags;				// Previous console input flags.
            private ConsoleModeFlags _oldOutFlags;				// Previous console output flags.
            private int _oldBufferWidth;                        // Old console buffer width.
            private int _oldBufferHeight;                       // Old console buffer height.
            private int _oldCursorHeight;					    // Old cursor height.
            private bool _oldCursorVisible;					    // Old cursor visible flag.
            private bool _isRunning;							// Flag to indicate the console app is in a running state.
            private ConsoleCloseArgs _closeArgs;				// Close event arguments.
            private ConsoleKeyArgs _keyArgs;					// Keyboard event arguments.
            private ConsoleMouseArgs _mouseArgs;				// Mouse event arguments.
            private uint _codePage;							    // Code page for the console.

            // Console control event.
            private ConsoleCtrlDelegate _controlEvent;

            /// <summary>Mouse event.</summary>
            public event ConsoleMouseEvent OnMouseAction;
            /// <summary>Key event.</summary>
            public event ConsoleKeyEvent OnKeyAction;
            /// <summary>Close event.</summary>
            public event ConsoleCloseEvent OnClose;
            /// <summary>Idle event.</summary>
            public event ConsoleIdleEvent OnIdle;
            #endregion

            #region Properties.
            /// <summary>
            /// Property to set or return the width of the buffer in columns.
            /// </summary>
            public int BufferWidth
            {
                get
                {
                    return System.Console.BufferWidth;
                }
                set
                {
                    // Resize window if buffer is smaller.
                    if (System.Console.WindowWidth-1 > value)
                        WindowWidth = value;

                    System.Console.BufferWidth = value;
                }
            }

            /// <summary>
            /// Property to set or return the height of the buffer in rows.
            /// </summary>
            public int BufferHeight
            {
                get
                {
                    return System.Console.BufferHeight;
                }
                set
                {
                    // Resize window if buffer is smaller.			
                    if (System.Console.WindowHeight > value)
                        WindowHeight = value;

                    System.Console.BufferHeight = System.Console.WindowTop + value;
                }
            }

            /// <summary>
            /// Property to set or return the width of the console window.
            /// </summary>
            public int WindowWidth
            {
                get
                {
                    return System.Console.WindowWidth;
                }
                set
                {
					if ((value < 2) || (value > System.Console.BufferWidth))
						throw new WindowSizeException();

                    System.Console.WindowWidth = value;
                }
            }

            /// <summary>
            /// Property to set or return the height of the console window.
            /// </summary>
            public int WindowHeight
            {
                get
                {
                    return System.Console.WindowHeight;
                }
                set
                {
                    if ((value < 2) || (value > System.Console.BufferHeight))
						throw new WindowSizeException();

                    System.Console.SetWindowSize(System.Console.WindowWidth,value);
                }
            }

            /// <summary>
            /// Property to set or return the foreground color.
            /// </summary>
            public ConsoleColor ForegroundColor
            {
                get
                {
                    return _foregroundColor;
                }
                set
                {
                    _foregroundColor = value;
                    SetConsoleAttrib();
                }
            }

            /// <summary>
            /// Property to set or return the background color.
            /// </summary>
            public ConsoleColor BackgroundColor
            {
                get
                {
                    return _backgroundColor;
                }
                set
                {
                    _backgroundColor = value;
                    SetConsoleAttrib();
                }
            }

            /// <summary>
            /// Property to set or return the caption of the window.
            /// </summary>
            public string Caption
            {
                get
                {
                    return System.Console.Title;
                }
                set
                {
                    System.Console.Title = value;
                }
            }

            /// <summary>
            /// Property to set or return whether the cursor is visible.
            /// </summary>
            public bool CursorVisible
            {
                get
                {
                    return System.Console.CursorVisible;
                }
                set
                {
                    System.Console.CursorVisible = value;
                }
            }

            /// <summary>
            /// Property to set or return the cursor height.
            /// </summary>
            public int CursorHeight
            {
                get
                {
                    return System.Console.CursorSize; 
                }
                set
                {
					if ((value < 0) || (value >= 127))
						throw new CursorHeightException(value);

                    System.Console.CursorSize = value;
                }
            }

            /// <summary>
            /// Property to set or return the horizontal position of the cursor.
            /// </summary>
            public int CursorLeft
            {
                get
                {
                    return System.Console.CursorLeft;
                }
                set
                {
                    if ((value < 0) || (value >= System.Console.BufferWidth))
						throw new CursorPositionException(false,value);

                    System.Console.CursorLeft = value;
                }
            }

            /// <summary>
            /// Property to set or return the vertical position of the cursor.
            /// </summary>
            public int CursorTop
            {
                get
                {
                    return System.Console.CursorTop;
                }
                set
                {
                    if ((value < 0) || (value >= System.Console.BufferHeight))
						throw new CursorPositionException(true, value);

                    System.Console.CursorTop = value;
                }
            }

            /// <summary>
            /// Property to set or return the code page for the console.
            /// </summary>
            public uint CodePage
            {
                get
                {
                    return _codePage;
                }
                set
                {
                    _codePage = value;
					Win32API.SetConsoleOutputCP(_codePage);
					Win32API.SetConsoleCP(_codePage);
                }
            }
            #endregion

            #region Methods.
            /// <summary>
            /// Function to set the console attribute colors.
            /// </summary>
            private void SetConsoleAttrib()
            {
                System.Console.ForegroundColor = _foregroundColor;
                System.Console.BackgroundColor = _backgroundColor;
            }

            /// <summary>
            /// Function to retrieve the initial size of the window/buffer.
            /// </summary>
            private void GetInitialSizes()
            {
                // Get buffer information.
                _oldSizeWidth = System.Console.WindowWidth;
                _oldSizeHeight = System.Console.WindowHeight;
                this._oldBufferWidth = System.Console.BufferWidth;
                this._oldBufferHeight = System.Console.BufferHeight;

                _oldCursorVisible = System.Console.CursorVisible;
                _oldCursorHeight = System.Console.CursorSize;
            }

            /// <summary>
            /// Function to handle control events.
            /// </summary>
            /// <param name="ctrltype">Control type.</param>
            /// <returns>TRUE to terminate, FALSE to keep going.</returns>
            private bool ControlHandler(ControlEventTypes ctrltype)
            {
                switch (ctrltype)
                {
                    case ControlEventTypes.WindowClosed:
                    case ControlEventTypes.Logoff:
                    case ControlEventTypes.ShutDown:
                        if (OnClose != null)
                        {
                            _closeArgs.Cancel = false;
                            OnClose(this, _closeArgs);

                            if (!_closeArgs.Cancel)
                                Stop();

                            return true;
                        }
                        else
                            return false;
                }

                return false;
            }

            /// <summary>
            /// Function to handle the 'Any Key' which so befuddled the great Homer Simpson.
            /// </summary>
            public void AnyKey()
            {
                StringBuilder txt = new StringBuilder(1);		// One character.
                uint charCount;									// Character to count.

				Win32API.SetConsoleMode(_inHandle, 0);

                charCount = 0;
                while (charCount == 0)
					Win32API.ReadConsole(_inHandle, txt, 1, out charCount, IntPtr.Zero);

				Win32API.SetConsoleMode(_inHandle, ConsoleModeFlags.EnableLineInput | ConsoleModeFlags.EnableProcessedInput | ConsoleModeFlags.EnableEchoInput);
				Win32API.FlushConsoleInputBuffer(_inHandle);
            }

            /// <summary>
            /// Function to read a character.
            /// </summary>
            /// <returns>Character.</returns>
            public char ReadChar()
            {
                StringBuilder txt = new StringBuilder(1);		// One character.
                uint charCount;									// Character to count.

				Win32API.SetConsoleMode(_inHandle, 0);

                charCount = 0;
                while (charCount == 0)
					Win32API.ReadConsole(_inHandle, txt, 1, out charCount, IntPtr.Zero);

				Win32API.SetConsoleMode(_inHandle, ConsoleModeFlags.EnableLineInput | ConsoleModeFlags.EnableProcessedInput | ConsoleModeFlags.EnableEchoInput);
				Win32API.FlushConsoleInputBuffer(_inHandle);

                return txt.ToString()[0];
            }

            /// <summary>
            /// Function to read a line of text.
            /// </summary>
            /// <param name="numchars">Number characters to read.</param>
            /// <returns>String containing the text.</returns>
            public string ReadLine(uint numchars)
            {
                StringBuilder ch = new StringBuilder(1);		// Character.
                StringBuilder txt;								// Result text.
                uint charCount;									// Character count.

				if ((numchars < 1) || (numchars > uint.MaxValue - 1))
					throw new StringBufferException((int)numchars);

                // Create string builder.
                txt = new StringBuilder((int)numchars);

				Win32API.SetConsoleMode(_inHandle, ConsoleModeFlags.EnableLineInput | ConsoleModeFlags.EnableProcessedInput | ConsoleModeFlags.EnableEchoInput);
				Win32API.ReadConsole(_inHandle, txt, numchars, out charCount, IntPtr.Zero);
				Win32API.FlushConsoleInputBuffer(_inHandle);

                return txt.ToString();
            }

            /// <summary>
            /// Function to read a line of text.
            /// </summary>
            /// <returns>String containing the text.</returns>
            public string ReadLine()
            {
                return System.Console.ReadLine();
            }

            /// <summary>
            /// Function to print a line of text.
            /// </summary>
            /// <param name="line">Line of text to print.</param>
            public void Print(string line)
            {
                System.Console.Write(line);
            }

            /// <summary>
            /// Function to print a line of formatted text.
            /// </summary>
            /// <param name="format">Format to use.</param>
            /// <param name="arg">Arguments to use in formatting.</param>
            public void Print(string format, params object[] arg)
            {
                System.Console.Write(format, arg);
            }

            /// <summary>
            /// Function to clear the buffer with the specified color.
            /// </summary>
            /// <param name="color">Color to use.</param>
            public void Clear(ConsoleColor color)
            {
                System.Console.Clear();
            }

            /// <summary>
            /// Function to clear the buffer with the current background color.
            /// </summary>
            public void Clear()
            {
                Clear(_backgroundColor);
            }

            /// <summary>
            /// Function to set the console app into a running state.
            /// </summary>
            public void Run()
            {
                // Do nothing if we're already running.
                if (_isRunning)
                    return;

                ConsoleIdleArgs idleArgs = new ConsoleIdleArgs();		// Idle events arguments.			

                _isRunning = true;

                // Run.
                while (_isRunning)
                {
                    idleArgs.Done = false;

                    if (OnIdle != null)
                    {
                        OnIdle(this, idleArgs);

                        if (idleArgs.Done)
                        {
                            // Fire close event if idle args indicates that we're done.
                            _closeArgs.Cancel = false;
                            if (OnClose != null)
                                OnClose(this, _closeArgs);
                            if (!_closeArgs.Cancel)
                            {
                                _isRunning = false;
                                break;
                            }
                        }
                    }

                    // Poll the keyboard/mouse.
                    PollInput();
                }
            }

            /// <summary>
            /// Function to stop the application.
            /// </summary>
            public void Stop()
            {
                _isRunning = false;
            }

            /// <summary>
            /// Function to poll the input devices.
            /// </summary>
            public void PollInput()
            {
                uint i;														// Loop.
                uint eventCount;											// Number of events.			
                // Event list.
                INPUT_RECORD[] events = new INPUT_RECORD[256];

                // Turn on mouse input.
				Win32API.SetConsoleMode(_inHandle, ConsoleModeFlags.EnableMouseInput);

                // Get number of events.
				Win32API.GetNumberOfConsoleInputEvents(_inHandle, out eventCount);

                // No events?  Leave,
                if (eventCount == 0)
                    return;

                // Read events.
				Win32API.ReadConsoleInput(_inHandle, events, 256, out eventCount);

                // Process events.
                for (i = 0; i < eventCount; i++)
                {
                    switch (events[i].EventType)
                    {
                        case ConsoleEventTypes.MouseEvent:
                            // Get mouse event.
                            _mouseArgs.X = events[i].Event.MouseEvent.dwMousePosition.X;
                            _mouseArgs.Y = events[i].Event.MouseEvent.dwMousePosition.Y;
                            _mouseArgs.Left = Convert.ToBoolean(events[i].Event.MouseEvent.dwButtonState & ConsoleMouseButtonFlags.Left1stButton);
                            _mouseArgs.Middle = Convert.ToBoolean(events[i].Event.MouseEvent.dwButtonState & ConsoleMouseButtonFlags.Left2ndButton);
                            _mouseArgs.Right = Convert.ToBoolean(events[i].Event.MouseEvent.dwButtonState & ConsoleMouseButtonFlags.RightButton);
                            _mouseArgs.ShiftAlt = Convert.ToBoolean(events[i].Event.MouseEvent.dwControlKeyState & ConsoleControlFlags.LeftAltPressed);
                            if (!_mouseArgs.ShiftAlt)
                                _mouseArgs.ShiftAlt = Convert.ToBoolean(events[i].Event.MouseEvent.dwControlKeyState & ConsoleControlFlags.RightAltPressed);
                            _mouseArgs.ShiftCtrl = Convert.ToBoolean(events[i].Event.MouseEvent.dwControlKeyState & ConsoleControlFlags.LeftCtrlPressed);
                            if (!_mouseArgs.ShiftCtrl)
                                _mouseArgs.ShiftCtrl = Convert.ToBoolean(events[i].Event.MouseEvent.dwControlKeyState & ConsoleControlFlags.RightCtrlPressed);
                            _mouseArgs.ShiftShift = Convert.ToBoolean(events[i].Event.MouseEvent.dwControlKeyState & ConsoleControlFlags.ShiftPressed);
                            _mouseArgs.ShiftDoubleClick = Convert.ToBoolean(events[i].Event.MouseEvent.dwFlags & ConsoleMouseEventFlags.DoubleClick);

                            // Fire event.
                            if (OnMouseAction != null)
                                OnMouseAction(this, _mouseArgs);
                            break;
                        case ConsoleEventTypes.KeyEvent:
                            // Get keyboard event.
                            _keyArgs.Char = (char)events[i].Event.KeyEvent.Char.UnicodeChar;
                            _keyArgs.Key = (Keys)(events[i].Event.KeyEvent.wVirtualKeyCode);
                            _keyArgs.ShiftShift = Convert.ToBoolean(events[i].Event.KeyEvent.dwControlKeyState & ConsoleControlFlags.ShiftPressed);
                            _keyArgs.ShiftAlt = Convert.ToBoolean(events[i].Event.KeyEvent.dwControlKeyState & ConsoleControlFlags.LeftAltPressed);
                            if (!_keyArgs.ShiftAlt)
                                _keyArgs.ShiftAlt = Convert.ToBoolean(events[i].Event.KeyEvent.dwControlKeyState & ConsoleControlFlags.RightAltPressed);
                            _keyArgs.ShiftCtrl = Convert.ToBoolean(events[i].Event.KeyEvent.dwControlKeyState & ConsoleControlFlags.LeftCtrlPressed);
                            if (!_keyArgs.ShiftCtrl)
                                _keyArgs.ShiftCtrl = Convert.ToBoolean(events[i].Event.KeyEvent.dwControlKeyState & ConsoleControlFlags.RightCtrlPressed);

                            if (OnKeyAction != null)
                                OnKeyAction(this, _keyArgs);
                            break;
                    }
                }

				Win32API.SetConsoleMode(_inHandle, ConsoleModeFlags.EnableLineInput | ConsoleModeFlags.EnableProcessedInput | ConsoleModeFlags.EnableEchoInput);
				Win32API.FlushConsoleInputBuffer(_inHandle);
            }
            #endregion

            #region Constructor/Destructor.
            /// <summary>
            /// Constructor.
            /// </summary>
            public ConsoleApplication()
            {
                // Region used to capture buffer.
                SMALL_RECT region = new SMALL_RECT(0, 0, 0, 0);
                COORD bufferSize = new COORD();

                _keyArgs = new ConsoleKeyArgs();				// Keyboard event arguments.
                _mouseArgs = new ConsoleMouseArgs();		// Mouse event arguments.
                _closeArgs = new ConsoleCloseArgs();
                _oldCursorLeft = System.Console.CursorLeft;
                _oldCursorTop = System.Console.CursorTop;
                _foregroundColor = ConsoleColor.Gray;
                _backgroundColor = ConsoleColor.Black;
                _oldCaption = System.Console.Title;                
                _isRunning = false;

                // Get handles.
				_outHandle = Win32API.GetStdHandle(StandardHandles.Output);
				_inHandle = Win32API.GetStdHandle(StandardHandles.Input);

                // Remove any buffered input.
				Win32API.FlushConsoleInputBuffer(_inHandle);

                // Default to 80x25.
                GetInitialSizes();
                bufferSize.X = (short)_oldBufferWidth;
                bufferSize.Y = 25;
                WindowWidth = 80;
                WindowHeight = 25;
                BufferWidth = 80;
                BufferHeight = 25;

                // Capture old buffer.
                _oldBuffer = new CHAR_INFO[bufferSize.X * bufferSize.Y];

                // Create region.
                region.Right = 79;
                region.Bottom = 24;

                // Grab from console window.
				Win32API.ReadConsoleOutput(_outHandle, _oldBuffer, bufferSize, new COORD(), ref region);

                // Set initial colors.
                SetConsoleAttrib();

                // Save old console modes and set new ones.
				Win32API.GetConsoleMode(_outHandle, out _oldOutFlags);
				Win32API.GetConsoleMode(_inHandle, out _oldInFlags);
				Win32API.SetConsoleMode(_outHandle, ConsoleModeFlags.EnableProcessedOutput | ConsoleModeFlags.EnableWrapAtEOLOutput);
				Win32API.SetConsoleMode(_inHandle, ConsoleModeFlags.EnableLineInput | ConsoleModeFlags.EnableProcessedInput | ConsoleModeFlags.EnableEchoInput);

                // Set event handler.
                _controlEvent = new ConsoleCtrlDelegate(ControlHandler);
				Win32API.SetConsoleCtrlHandler(_controlEvent, true);

                CodePage = 1252;
            }

            /// <summary>
            /// Destructor.
            /// </summary>
            ~ConsoleApplication()
            {
                Dispose(false);
            }
            #endregion

            #region IDisposable Members
            /// <summary>
            /// Function to perform clean up.
            /// </summary>
            /// <param name="disposing">TRUE to clean up all objects, FALSE to clean up unmanaged objects only.</param>
            private void Dispose(bool disposing)
            {
                if (disposing)
                {
					Win32API.SetConsoleCtrlHandler(_controlEvent, false);
                    _controlEvent = null;

                    // Reset sizes.
                    BufferWidth = _oldBufferWidth;
                    BufferHeight = _oldBufferHeight;
                    WindowWidth = _oldSizeWidth;
                    WindowHeight = _oldSizeHeight;

                    // Reset cursor.
                    CursorVisible = _oldCursorVisible;
                    CursorHeight = _oldCursorHeight;

					Win32API.SetConsoleMode(_outHandle, _oldOutFlags);
					Win32API.SetConsoleMode(_inHandle, _oldInFlags);
                    ForegroundColor = ConsoleColor.Gray;
                    BackgroundColor = ConsoleColor.Black;
                    Clear();
                    Caption = _oldCaption.ToString();

                    SMALL_RECT rgn = new SMALL_RECT(0, 0, 79, 24);
                    COORD bufferSize = new COORD();
                    bufferSize.X = (short)_oldBufferWidth;
                    bufferSize.Y = 25;
					Win32API.WriteConsoleOutput(_outHandle, _oldBuffer, bufferSize, new COORD(), ref rgn);
                    CursorLeft = _oldCursorLeft;
                    CursorTop = _oldCursorTop;
                }
            }

            /// <summary>
            /// Function to perform clean up.
            /// </summary>
            public void Dispose()
            {
                Dispose(true);
                GC.SuppressFinalize(this);
            }
            #endregion
        }
    }
}
