//
// SharpUtils.
// Copyright (C) 2005 Michael Winsor
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
// Lesser General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
//
// Created: Thursday, March 24, 2005 10:01:02 AM
//

using System;
using System.Windows.Forms;
using System.Collections;
using System.Runtime.Serialization;
using System.Security.Permissions;
using SharpUtilities.Utility;

namespace SharpUtilities
{
    /// <summary>
    /// Base exception object.
    /// </summary>
    /// <remarks>This exception is the base exception for all other exceptions thrown from this library.</remarks>
    /// <example>
    /// [C#] The following example shows how to catch a SharpUtilities exception:
    /// <code>
    /// public void DisplayCPUName(int cpuIndex)
    /// {
    /// 	YourComputer cpuID;		// CPU information.
    /// 	/* ... create the YourComputer object, etc... */
    /// 	
    /// 	try
    /// 	{
    /// 		// This will fail if the cpuIndex is greater than the # of 
    /// 		// CPUs present on the computer.
    /// 		MessageBox.Show("This is a CPU named: " + cpuID.CPU[cpuIndex].Name);
    /// 	}
    /// 	catch(IndexOutOfBoundsException e)
    /// 	{
    /// 	    MessageBox.Show("The CPU Index is larger than the number of CPUs present in the computer.");
    /// 	}
    ///     catch(SharpException e)
    ///     {
    ///         // Alternatively, the exception can be handled this way:
    ///         if ((CollectionErrorCodes)e.ErrorCode == CollectionErrorCodes.IndexOutOfBounds)
    ///             MessageBox.Show("The CPU Index is larger than the number of CPUs present in the computer.");    
    ///     }
    /// }
    /// </code>
    /// </example>
	public class SharpException : ApplicationException
	{
		#region Variables.
        /// <summary>Flag to show execution stack info.</summary>
		protected static bool _showStack = true;
		#endregion

		#region Properties.
        /// <summary>
        /// Property to set or return whether we show stack information.
        /// </summary>
		public static bool ShowStack
		{
			get
			{
				return _showStack;
			}
			set
			{
				_showStack = value;
			}
		}

		/// <summary>
		/// Property to return the error message.
		/// </summary>
		public string ErrorLog
		{
			get 
			{
				string retStr = "";			// Return string.
				string[] stackStr = null;	// Stack list.
				string stackFile;			// Stack file name.
				Exception next = null;		// Next exception.

				// Error message.				
				if (_showStack)				
				{
					next = this;

					while (next != null)
					{
						if (retStr != string.Empty)
							retStr += "\n\n----Next inner exception----\n";
						if (next is SharpException)
							retStr += "Application Exception: " + next.Message + "\nCode: (0x" + ((SharpException)next).HResult.ToString("x").PadLeft(8, '0') + ")\n";
						else
							retStr += "Application Exception: " + next.Message + "\n";

						retStr += "Type: " + next.GetType().Name + "\n";

						// Split stack trace into multiple lines.
						stackStr = next.StackTrace.Split('\n');

						retStr += "Stack unwind:\n";
						for (int i = 0; i < stackStr.Length; i++)
						{
							// Remove the path info from the stack string, if you can't find your
							// files then you've got bigger problems.
							stackFile = stackStr[i];
							stackStr[i] = stackStr[i].Substring(1, stackFile.IndexOf("in ") + 2);
							stackFile = stackFile.Substring(stackFile.LastIndexOf(@"\") + 1, stackFile.Length - stackFile.LastIndexOf(@"\") - 1);
							stackStr[i] += stackFile;

							retStr += stackStr[i] + "\n";
						}
						retStr += "<<<Beginning of stack>>>";

						// Get the next exception.
						next = next.InnerException;
					}
				}

				return retStr;
			}
		}

		/// <summary>
		/// Property to return the error code.
		/// </summary>
		public int ErrorCode
		{
			get
			{
				return HResult;
			}
		}
		#endregion
			
		#region Constructor/Destructor.
		/// <summary>
		/// Constructor.
		/// </summary>
		/// <param name="errorMessage">Error message to display.</param>
		/// <param name="errorCode">Error code.</param>
		public SharpException(string errorMessage, int errorCode) : base(errorMessage)
		{
			HResult = errorCode;			
		}

        /// <summary>
        /// Constructor.
        /// </summary>
        /// <param name="errorMessage">Error message to display.</param>
        /// <param name="innerException">Inner exception to pass through.</param>
		public SharpException(string errorMessage, Exception innerException) : base(errorMessage,innerException)
		{
		}

		/// <summary>
		/// Constructor.
		/// </summary>
		/// <param name="errorMessage">Error message to display.</param>
		public SharpException(string errorMessage) : base(errorMessage)
		{
		}

		/// <summary>
		/// Serialized constructor.
		/// </summary>
		/// <param name="info">Serialization info.</param>
		/// <param name="context">Serialization context.</param>
		protected SharpException(SerializationInfo info, StreamingContext context) : base(info,context)
		{
		}

		/// <summary>
		/// Default constructor.
		/// </summary>
		public SharpException()
		{
		}
		#endregion
	}
}
