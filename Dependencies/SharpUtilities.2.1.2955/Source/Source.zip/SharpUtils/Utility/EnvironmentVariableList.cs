#region LGPL.
// 
// SharpUtils.
// Copyright (C) 2005 Michael Winsor
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
// 
// Created: Thursday, December 01, 2005 10:35:11 PM
// 
#endregion

using System;
using System.Collections;
using SharpUtilities.Collections;

namespace SharpUtilities.Utility
{
	/// <summary>
	/// A class representing a list of environment variables.
	/// </summary>
	public class EnvironmentVariableList 
		: Collection<EnvironmentVariable>
	{
		#region Methods.
		/// <summary>
		/// Function to add a new environment variable to the list.
		/// </summary>
		/// <param name="variableName">Name of the environment variable.</param>
		/// <param name="variableValue">Value of the environment variable.</param>
		public void Add(string variableName, string variableValue)
		{
			if (Items.ContainsKey(variableName))
				Items[variableName] = new EnvironmentVariable(variableName, variableValue);
			else
				Items.Add(variableName, new EnvironmentVariable(variableName, variableValue));
		}

		/// <summary>
		/// Function to refresh the environment variable list.
		/// This function will wipe out any user-added environment variables if they haven't been committed.
		/// </summary>
		public void Refresh()
		{
			IDictionary envList;	// Environment variable list.

			try
			{
				Clear();
				envList = Environment.GetEnvironmentVariables();
				// Loop through and add to collection.
				foreach (DictionaryEntry de in envList)
					this.Add(de.Key.ToString(), de.Value.ToString());
			}
			catch
			{
				throw new EnvironmentVariableReadException();
			}
		}

		/// <summary>
		/// Function to commit any changes to the environment variables to the
		/// real environment variable list for this process.
		/// </summary>
		public void Commit()
		{
			IDictionary envList;	// Environment variable list.

			try
			{
				envList = Environment.GetEnvironmentVariables();

				// Loop through and clear the environment variables.
				foreach (DictionaryEntry de in envList)
					Environment.SetEnvironmentVariable(de.Key.ToString(), "");

				// Now re-add the variables.
				foreach (EnvironmentVariable env in this)
					Environment.SetEnvironmentVariable(env.Name, env.Value);
			}
			catch
			{
				throw new EnvironmentVariableWriteException();				
			}
		}
		#endregion
	}
}
