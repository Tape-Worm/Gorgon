//
// SharpUtils.
// Copyright (C) 2005 Michael Winsor
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
// Lesser General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
//
// Created: Thursday, March 24, 2005 10:01:43 AM
//

using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Management;
using System.Diagnostics;
using System.Windows.Forms;
using SharpUtilities.Native.Win32;

namespace SharpUtilities.Utility
{
	/// <summary>
	/// An object containing information about the computer and the operating system.
	/// </summary>
	public class YourComputer : IDisposable
	{
		#region Variables.
		private string _computerName;								// Computer name.
		private string _domainName;									// Network domain.
		private string _userName;									// User name.
		private CPUList _cpus;							            // CPU Information list.
		private OSTypes _osType;									// Operating system type.
		private OSExtensions _osExtensions;							// Operating system extensions.
		private string _systemDirectory;							// Windows system path.
		private string _windowsDirectory;							// Windows path.
		private string _osVersion;									// Windows version.
		private string _osServicePack;								// Windows service pack.
		private string _osBuildNumber;								// Windows build number.
		private ulong _physicalTotal;							    // Total physical memory.
		private ManagementObject _osInformation;					// Operating system data.
		private bool _hasTerminalServices;							// Has terminal server capabilities.
        private bool _hasLimitedTerminalSessions;                   // Has terminal server is limited to only 1 session.
		private EnvironmentVariableList _variables;	                // Environment variable list.
		#endregion

		#region Properties.
		/// <summary>
		/// Property to return the Operating System name in full.
		/// </summary>
		public string OSFullName
		{
			get
			{
				string osName = string.Empty;	// Operating system name.

				switch (OSType)
				{
					case OSTypes.Windows95:
						osName = "Windows 95 (Time to upgrade don't you think?)";
						break;
					case OSTypes.Windows95OSR2:
						osName = "Windows 95 OSR2 (UPGRADE ALREADY!!)";
						break;
					case OSTypes.Windows98:
						osName = "Windows 98";
						break;
					case OSTypes.Windows98SE:
						osName = "Windows 98 SE";
						break;
					case OSTypes.WindowsNT4:
						osName = "Windows NT 4.0";
						break;
					case OSTypes.WindowsME:
						osName = "Windows Millenium Edition (You sorry bastard.)";
						break;
					case OSTypes.Windows2000:
						osName = "Windows 2000";
						break;
					case OSTypes.WindowsCE:
						osName = "Windows CE";
						break;
					case OSTypes.WindowsXP:
						osName = "Windows XP";
						break;
					case OSTypes.Windows2003:
						osName = "Windows 2003";
						break;
					case OSTypes.WindowsVista:
						osName = "Windows Vista";
						break;
					case OSTypes.WindowsFuture:
						osName = "Future version of Windows";
						break;
					default:
						osName = "Unknown.";
						break;
				}

				switch (OSExtensions)
				{
					case OSExtensions.Home:
						osName += " Home";
						break;
					case OSExtensions.CommunicationServer:
						osName += " Communication Server";
						break;
					case OSExtensions.DataCenter:
						osName += " Data Center";
						break;
					case OSExtensions.Embedded:
						osName += " Embedded";
						break;
					case OSExtensions.Enterprise:
						osName += " Enterprise";
						break;
					case OSExtensions.Professional:
						osName += " Professional";
						break;
					case OSExtensions.Server:
						osName += " Server";
						break;
					case OSExtensions.SmallBusiness:
						osName += " Small Business Server";
						break;
					case OSExtensions.SmallBusinessRestricted:
						osName += " Small Business Server (Restricted)";
						break;
					case OSExtensions.Workstation:
						osName += " Workstation";
						break;
					case OSExtensions.Business:
						osName += " Business";
						break;
					case OSExtensions.BusinessN:
						osName += " Business N";
						break;
					case OSExtensions.EnterpriseServer:
						osName += " Enterprise Server";
						break;
					case OSExtensions.HomeBasic:
						osName += " Home Basic";
						break;
					case OSExtensions.HomeBasicN:
						osName += " Home Basic N";
						break;
					case OSExtensions.HomePremium:
						osName += " Home Premium";
						break;
					case OSExtensions.Starter:
						osName += " Starter";
						break;
					case OSExtensions.Ultimate:
						osName += " Ultimate";
						break;
				}

				if (OSServicePack.Length > 0)
					osName += ", " + OSServicePack;

				return osName;
			}
		}

        /// <summary>
        /// Property to return whether this system has been joined to a domain.
        /// </summary>
        public bool IsPartOfDomain
        {
            get
            {
                return GetWMIValue<bool>("PartOfDomain","Win32_ComputerSystem");
            }
        }

		/// <summary>
		/// Property to return the username of the currently logged in user. 
		/// </summary>
		public string UserName 
		{
			get 
			{
				return _userName;
			}
		}

		/// <summary>
		/// Property to return this computer's name. 
		/// </summary>
		public string ComputerName
		{
			get
			{
				return _computerName;
			}
		}
		
		/// <summary>
		/// Property to return the name of the network domain. 
		/// </summary>
		public string DomainName
		{
			get
			{
				return _domainName;
			}
		}

		/// <summary>
		/// Property to return infomation about a specific processor.
		/// </summary>
		public CPUList CPU
		{
			get 
			{
				return _cpus;
			}
		}

		/// <summary>
		/// Property to return the environment variable list.
		/// </summary>
		public EnvironmentVariableList EnvironmentVariables
		{
			get
			{
				return _variables;
			}
		}

		/// <summary>
		/// Property to return the total amount of physical memory installed in KB.
		/// </summary>
		public ulong TotalPhysical
		{
			get
			{
				return _physicalTotal;
			}
		}

		/// <summary>
		/// Property to return the total amount of virtual memory in KB.
		/// </summary>
		public ulong TotalVirtual
		{
			get
			{
				if (_osInformation != null) 
				{
					_osInformation.Get();
					return (ulong)_osInformation.Properties["TotalVirtualMemorySize"].Value;
				}
				else
					return 0;
			}
		}

		/// <summary>
		/// Property to return the free amount of physical memory installed in KB.
		/// </summary>
		public ulong FreePhysical
		{
			get
			{
				if (_osInformation != null) 
				{
					_osInformation.Get();
					return (ulong)_osInformation.Properties["FreePhysicalMemory"].Value;
				}
				else
					return 0;
			}
		}

		/// <summary>
		/// Property to return the free amount of virtual memory in KB.
		/// </summary>
		public ulong FreeVirtual
		{
			get
			{
				if (_osInformation != null)
				{
					_osInformation.Get();
					return (ulong)_osInformation.Properties["FreeVirtualMemory"].Value;
				}
				else
					return 0;
			}
		}

		/// <summary>
		/// Property to return whether the OS has a terminal server.
		/// </summary>
		public bool HasTerminalServices
		{
			get
			{
				return _hasTerminalServices;
			}
		}

        /// <summary>
        /// Property to return whether the terminal server is limited to only 1 connection.
        /// </summary>
        public bool HasLimitedTerminalSessions
        {
            get
            {
                return _hasLimitedTerminalSessions;
            }
        }

		/// <summary>
		/// Property to return the OS type.
		/// </summary>
		public OSTypes OSType
		{
			get
			{
				return _osType;
			}
		}

		/// <summary>
		/// Property to return extended information about the OS.
		/// </summary>
		public OSExtensions OSExtensions
		{
			get
			{
				return _osExtensions;
			}
		}

		/// <summary>
		/// Property to return operating system version.
		/// </summary>
		public string OSVersion
		{
			get
			{
				return _osVersion;
			}
		}

		/// <summary>
		/// Property to return operating system build #.
		/// </summary>
		public string OSBuildNumber
		{
			get
			{
				return _osBuildNumber;
			}
		}

		/// <summary>
		/// Property to return operating system service pack info.
		/// </summary>
		public string OSServicePack
		{
			get
			{
				return _osServicePack;
			}
		}

		/// <summary>
		/// Property to return the windows directory.
		/// </summary>
		public string OSWindowsDirectory
		{
			get
			{
				return _windowsDirectory;
			}
		}

		/// <summary>
		/// Property to return the system directory.
		/// </summary>
		public string OSSystemDirectory
		{
			get
			{
				return _systemDirectory;
			}
		}
		#endregion

		#region Methods.
        /// <summary>
        /// Function to retrieve a WMI value.
        /// </summary>
        /// <typeparam name="T">Type of data to retrieve.</typeparam>
        /// <param name="WMIItem">Name of the item to retrieve.</param>
        /// <param name="WMIClass">Class to retrieve data from.</param>
        private T GetWMIValue<T>(string WMIItem,string WMIClass)
        {
            T result = default(T);                          // Result.
            ManagementObjectSearcher search = null;         // WMI search query.
            ManagementObjectCollection results = null;      // WMI search results.

            try
            {
                // Get info.
                search = new ManagementObjectSearcher("SELECT " + WMIItem + " FROM " + WMIClass);                
                results = search.Get();

                // Get value.
                foreach (ManagementObject entry in results)
                    result = (T)entry[WMIItem];
            }
            catch
            {
                throw;
            }
            finally
            {
                // Clean up.
                if (search != null)
                    search.Dispose();
                if (results != null)
                    results.Dispose();

                search = null;
                results = null;
            }

            // Return result.
            return result;
        }

        /// <summary>
        /// Function to retrieve login information.
        /// </summary>
        private void GetLoginInfo()
        {
            StringBuilder usernameBuffer;       // User name.
            StringBuilder computerBuffer;       // Computer name.
            uint bufferLength = 2048;           // Length of buffers.

            _computerName = GetWMIValue<string>("Name", "Win32_ComputerSystem");
            _userName = System.Windows.Forms.SystemInformation.UserName;
            _domainName = GetWMIValue<string>("Workgroup", "Win32_ComputerSystem");
            if (IsPartOfDomain)
            {   
                _domainName = GetWMIValue<string>("Domain", "Win32_ComputerSystem");
                if (this._osType >= OSTypes.Windows2000)
                {
                    // Get the username.
                    usernameBuffer = new StringBuilder((int)bufferLength);
                    computerBuffer = new StringBuilder((int)bufferLength);
                    if (Win32API.GetUserNameEx(ExtendedNameFormat.UserPrincipal, usernameBuffer, ref bufferLength) != 0)
                        _userName = usernameBuffer.ToString();

                    // Get the computer name.
                    bufferLength = 2048;
                    if (Win32API.GetComputerNameEx(ComputerNameFormat.DnsFullyQualified, computerBuffer, ref bufferLength))
                        _computerName = computerBuffer.ToString();
                }
            }
                
            if (_domainName == null)
                _domainName = GetWMIValue<string>("Domain", "Win32_ComputerSystem");
        }

		/// <summary>
		/// Function to retrieve CPU information.
		/// </summary>
		private void GetCPUInfo()
		{
			ManagementClass				WMICPUInfo;	// CPU ID class.
			ManagementObjectCollection	CPUList;	// List of cpu information.

			// Get CPU details.            
			WMICPUInfo = new ManagementClass("Win32_Processor");
			CPUList = WMICPUInfo.GetInstances();
			
			// Go through each object in the cpu list.
			foreach(ManagementObject CPU in CPUList) 
			{
				_cpus.Add(CPU.Properties, OSType);
				
				// Clean up.
				CPU.Dispose();
			}			

			// Clean up.
			CPUList.Dispose();
            WMICPUInfo.Dispose();
		}

		/// <summary>
		/// Function to retrieve the operating system information.
		/// </summary>
		private void GetOSInfo()
		{
			ManagementClass				WMIOSInfo;	// Operating system info.
			ManagementObjectCollection	OSList;		// Operating system list.
			uint						OSSuite;	// Operating system suite type.
            uint                        OSSKU;      // Operating system SKU.

			// Retrieve OS info.
			WMIOSInfo = new ManagementClass("Win32_OperatingSystem");
			OSList = WMIOSInfo.GetInstances();
		
			// Go through each operating system.
			foreach (ManagementObject OS in OSList) 
			{
				_osInformation = OS;
				_systemDirectory = OS.Properties["SystemDirectory"].Value.ToString();
				_windowsDirectory = OS.Properties["WindowsDirectory"].Value.ToString();
				_osVersion = OS.Properties["Version"].Value.ToString();
				_osBuildNumber = OS.Properties["BuildNumber"].Value.ToString();
				_physicalTotal = (ulong)OS.Properties["TotalVisibleMemorySize"].Value;
				if (OS.Properties["CSDVersion"].Value != null) 
					_osServicePack = OS.Properties["CSDVersion"].Value.ToString();
				else
					_osServicePack = "";

				// Get operating system type.
				switch ((ushort)OS.Properties["OSType"].Value)
				{
					case 16:
						// 95 or 95 OSR2
						if ((_osServicePack.IndexOf("C")>-1) || (_osServicePack.IndexOf("B")>-1))
							_osType = OSTypes.Windows95OSR2;
						else
							_osType = OSTypes.Windows95;						
						break;
					case 17:
						// 98 or 98 SE
						if (_osServicePack.IndexOf("A")>-1)
							_osType = OSTypes.Windows98SE;
						else
							_osType = OSTypes.Windows98;

						// Me
						if (_osVersion == "4.90")
							_osType = OSTypes.WindowsME;

						break;						
					case 18:
						// NT 4
						if (_osVersion == "4.0")
							_osType = OSTypes.WindowsNT4;
						else {
							_osType = OSTypes.WindowsFuture;
							// Determine what version of NT.
							if (_osVersion.IndexOf("5.0") == 0)
								_osType = OSTypes.Windows2000;
							if (_osVersion.IndexOf("5.1") == 0)
								_osType = OSTypes.WindowsXP;
							if (_osVersion.IndexOf("5.2") == 0)
								_osType = OSTypes.Windows2003;
                            if (_osVersion.IndexOf("6.0") == 0)
                                _osType = OSTypes.WindowsVista;
						}
						break;
					case 19:
						_osType = OSTypes.WindowsCE;
						break;
					default:
						_osType = OSTypes.Unknown;
						break;
				}

				// Get operating system suite info.
				_osExtensions = OSExtensions.None;

                OSSuite = 0;
				OSSKU = 0;
                switch (_osType)
                {
                    case OSTypes.WindowsXP:
                    case OSTypes.Windows2003:
                        OSSuite = (uint)OS.Properties["SuiteMask"].Value;
                        break;
                    case OSTypes.WindowsVista:
                        OSSuite = (uint)OS.Properties["SuiteMask"].Value;
                        OSSKU = (uint)OS.Properties["OperatingSystemSKU"].Value;
                        break;
                    case OSTypes.Unknown:
                        break;
                    default:
                        // If we're using Windows NT/2000, get the product suite with
                        // another property.  If this property is null, then we're
                        // using a Workstation.
                        if (OS.Properties["OSProductSuite"].Value == null)
                        {
                            // 2000 doesn't have a workstation suffix, so
                            // set the suite type to Professional.
                            if (_osType == OSTypes.Windows2000)
                                _osExtensions = OSExtensions.Professional;
                            else
                                _osExtensions = OSExtensions.Workstation;
                        }
                        else
                        {
                            // Default to server if we have a value.
                            OSSuite = (uint)OS.Properties["OSProductSuite"].Value;
                            _osExtensions = OSExtensions.Server;
                        }
                        break;
                }

                // Determine suite type if there's any suite type at all.
				if ((OSSuite & 1)>0)
					_osExtensions = OSExtensions.SmallBusiness;
				if ((OSSuite & 2)>0)
					_osExtensions = OSExtensions.Enterprise;
				if ((OSSuite & 8)>0)
					_osExtensions = OSExtensions.CommunicationServer;
				if ((OSSuite & 32)>0)
					_osExtensions = OSExtensions.SmallBusinessRestricted;
				if ((OSSuite & 64)>0)
					_osExtensions = OSExtensions.Embedded;
				if ((OSSuite & 128)>0)
					_osExtensions = OSExtensions.DataCenter;
				
				// For Windows XP only.  Determine which type of product.
                switch(_osType)
                {
                    case OSTypes.WindowsXP:
					if ((OSSuite & 512) == 0)
						_osExtensions = OSExtensions.Professional;
					else
						_osExtensions = OSExtensions.Home;
                        break;
                    case OSTypes.WindowsVista:                        
                        // I just LOVE</sarcasm> that Microsoft has decided to make 14,000,000 
                        // versions of Vista... don't you?
                        switch(OSSKU)
                        {
                            case 1:
                                _osExtensions = OSExtensions.Ultimate;
                                break;
                            case 2:
                                _osExtensions = OSExtensions.HomeBasic;
                                break;
                            case 3:
								_osExtensions = OSExtensions.HomePremium;
                                break;
							case 4:
								_osExtensions = OSExtensions.Enterprise;
								break;
							case 5:
								_osExtensions = OSExtensions.HomeBasicN;
								break;
							case 6:
								_osExtensions = OSExtensions.Business;
								break;
							case 7:
							case 13:
								_osExtensions = OSExtensions.Server;
								break;
							case 8:
							case 12:
								_osExtensions = OSExtensions.DataCenter;
								break;
							case 9:
								_osExtensions = OSExtensions.SmallBusinessRestricted;
								break;
							case 10:
							case 14:
							case 15:
								_osExtensions = OSExtensions.EnterpriseServer;
								break;
							case 11:
								_osExtensions = OSExtensions.Starter;
								break;
							case 16:
								_osExtensions = OSExtensions.BusinessN;
								break;
							case 25:
								_osExtensions = OSExtensions.SmallBusiness;
								break;
							default:
								_osExtensions = OSExtensions.None;
								break;
						}
                        break;
                }

                _hasTerminalServices = false;
                _hasLimitedTerminalSessions = false;

				// Determine if we have terminal services support.
				if ((OSSuite & 0x16)>0)
					_hasTerminalServices = true;
                if ((OSSuite & 0x256) != 0)
                {
                    _hasTerminalServices = true;
                    _hasLimitedTerminalSessions = true;
                }
			
				// Clean up.
				OS.Dispose();
			}			

			// Clean up.
			WMIOSInfo.Dispose();
		}

        /// <summary>
        /// Function to force an update to the system information.
        /// </summary>
        public void Refresh()
        {
			GetOSInfo();
            GetCPUInfo();            
        }
		#endregion

		#region Constructor/Destructor
		/// <summary>
		/// Constructor.
		/// </summary>
		public YourComputer()
		{
			// Create a new CPU list object.
			_cpus = new CPUList();			
			
			// Create environment variable list.
			_variables = new EnvironmentVariableList();
			_variables.Refresh();

			GetOSInfo();
			GetCPUInfo();			
            GetLoginInfo();
		}

		/// <summary>
		/// Function to perform actual clean-up.
		/// </summary>
		/// <param name="disposing">TRUE if disposing managed items and unmanaged items, FALSE if only disposing unmanaged.</param>
		protected virtual void Dispose(bool disposing)
		{
			if (disposing)
			{
    			_variables.Clear();			
				_osInformation.Dispose();				
			}

            _cpus = null;
            _osInformation = null;				
            _variables = null;
		}

		/// <summary>
		/// Function to clean up.
		/// </summary>
		public void Dispose()
		{
			Dispose(true);
			// Notify the garbage collection that we've cleaned up already.
			GC.SuppressFinalize(this);
		}

		/// <summary>
		/// Destructor.
		/// </summary>
		~YourComputer()
		{
			Dispose(false);
		}
		#endregion
	}
}
