#region LGPL.
// 
// SharpUtils.
// Copyright (C) 2005 Michael Winsor
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
// 
// Created: Thursday, December 01, 2005 10:26:38 PM
// 
#endregion

using System;
using System.Management;
using SharpUtilities.Collections;

namespace SharpUtilities.Utility
{
	/// <summary>
	/// An object representing all of the CPUs in the computer.
	/// </summary>
	public class CPUList 
		: DynamicArray<CPU>
	{
		#region Methods
		/// <summary>
		/// Function to add a CPU object to the list.
		/// </summary>
		/// <param name="cpuInfo">CPU management object info.</param>
		/// <param name="os">Operating system information.</param>
		internal void Add(PropertyDataCollection cpuInfo, OSTypes os)
		{
			CPU cpuObj;	// CPU object.

			cpuObj = new CPU(cpuInfo, os);
			Items.Add(cpuObj);			
		}
		#endregion
	}
}
