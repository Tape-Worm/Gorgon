#region LGPL.
// 
// SharpUtils.
// Copyright (C) 2005 Michael Winsor
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
// 
// Created: Thursday, December 01, 2005 10:24:57 PM
// 
#endregion

using System;
using System.Management;

namespace SharpUtilities.Utility
{
	/// <summary>
	/// A value type to hold information about a CPU.
	/// </summary>
	public struct CPU
	{
		#region Variables.
		private uint _speed;			// Speed of the CPU in MHz.
		private uint _level;			// Level ID of the CPU.
		private uint _revision;		    // Revision of the CPU.
		private uint _family;	        // Family ID returned by manager.
		private string _stepping;		// Stepping value of the CPU.
		private string _name;			// Name of the CPU.
		private string _vendor;		    // Vendor for this CPU.
		private int _cores;				// Number of cores.
		private int _logicalCPUs;		// Number of logical CPUs.
		#endregion

		#region Properties.
		/// <summary>
		/// Property to return CPU speed in MHz.
		/// </summary>
		public uint Speed
		{
			get
			{
				return _speed;
			}
		}

		/// <summary>
		/// Property to return CPU family ID.
		/// </summary>
		public uint Family
		{
			get
			{
				return _family;
			}
		}

		/// <summary>
		/// Property to return the CPU level ID.
		/// </summary>
		public uint Level
		{
			get
			{
				return _level;
			}
		}

		/// <summary>
		/// Property to return CPU revision number.
		/// </summary>
		public uint Revision
		{
			get
			{
				return _revision;
			}
		}

		/// <summary>
		/// Property to return CPU stepping ID.
		/// </summary>
		public string Stepping
		{
			get
			{
				return _stepping;
			}
		}

		/// <summary>
		/// Property to return CPU name.
		/// </summary>
		public string Name
		{
			get
			{
				return _name;
			}
		}

		/// <summary>
		/// Property to return CPU vendor name.
		/// </summary>
		public string Vendor
		{
			get
			{
				return _vendor;
			}
		}

		/// <summary>
		/// Property to return the number of logical CPUs.
		/// </summary>
		public int LogicalCPUCount
		{
			get
			{
				return _logicalCPUs;
			}
		}

		/// <summary>
		/// Property to return the number of 'cores'.
		/// </summary>
		public int CoreCount
		{
			get
			{
				return _cores;
			}
		}
		#endregion

		#region Constructors.
		/// <summary>
		/// Constructor.
		/// </summary>
		/// <param name="cpuInfo">CPU information object.</param>
		/// <param name="os">Operating system information.</param>
		public CPU(PropertyDataCollection cpuInfo, OSTypes os)
		{
			_cores = 0;			// Default to one core.
			_logicalCPUs = 0;	// Number of logical CPUs.

			_family = _level = _revision = 0;
			_speed = 0;
			_stepping = _name = _vendor = "";
			// Get CPU info.
			try
			{
				_family = (ushort)cpuInfo["Family"].Value;
				_speed = (uint)cpuInfo["CurrentClockSpeed"].Value;
				_level = (ushort)cpuInfo["Level"].Value;
				_revision = (ushort)cpuInfo["Revision"].Value;
				_vendor = cpuInfo["Manufacturer"].Value.ToString();
				_name = cpuInfo["Name"].Value.ToString().Trim();
				_stepping = cpuInfo["Stepping"].Value.ToString();
				// Grab info only if we're on Vista.
				if ((os == OSTypes.WindowsVista) || (os == OSTypes.WindowsFuture))
				{
					_cores = Convert.ToInt32(cpuInfo["NumberOfCores"].Value);
					_logicalCPUs = Convert.ToInt32(cpuInfo["NumberOfLogicalProcessors"].Value);
				}
			}
			catch
			{
				// Do nothing if error.  FXCop will surely complain about this.
			}
		}
		#endregion
	}
}
