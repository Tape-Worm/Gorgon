#region LGPL.
// 
// SharpUtils.
// Copyright (C) 2005 Michael Winsor
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
// 
// Created: Thursday, December 01, 2005 9:43:07 PM
// 
#endregion

namespace SharpUtilities.Utility
{
	/// <summary>
	/// Enumeration of operating system types.
	/// </summary>
	public enum OSTypes
	{
		/// <summary>
		/// Unknown operating system.
		/// </summary>
		Unknown = 0,
		/// <summary>
		/// Windows 95.
		/// </summary>
		Windows95 = 1,
		/// <summary>
		/// Windows 95 OSR 2.
		/// </summary>
		Windows95OSR2 = 2,
		/// <summary>
		/// Windows 98.
		/// </summary>
		Windows98 = 3,
		/// <summary>
		/// Windows 98 SE.
		/// </summary>
		Windows98SE = 4,
		/// <summary>
		/// Windows Millenium.  (That's money well wasted.)
		/// </summary>
		WindowsME = 5,
		/// <summary>
		/// Windows NT 4.0.
		/// </summary>
		WindowsNT4 = 6,
		/// <summary>
		/// Windows 2000.
		/// </summary>
		Windows2000 = 7,
		/// <summary>
		/// Windows XP.
		/// </summary>
		WindowsXP = 8,
		/// <summary>
		/// Windows 2003.
		/// </summary>
		Windows2003 = 9,
		/// <summary>
		/// Windows CE.
		/// </summary>
		WindowsCE = 0xA,
        /// <summary>
        /// Windows Vista.
        /// </summary>
        WindowsVista = 0xB,
		/// <summary>
		/// Windows, unknown version.
		/// </summary>
		WindowsFuture = 0xFFFF
	}

	/// <summary>
	/// Enumeration of OS extensions.
	/// </summary>
	public enum OSExtensions
	{
		/// <summary>
		/// No extension.
		/// </summary>
		None = 0,
		/// <summary>
		/// Small business version.
		/// </summary>
		SmallBusiness = 1,
		/// <summary>
		/// Enterprise version.
		/// </summary>
		Enterprise = 2,
		/// <summary>
		/// Communication server.
		/// </summary>
		CommunicationServer = 3,
		/// <summary>
		/// Restricted small business.
		/// </summary>
		SmallBusinessRestricted = 4,
		/// <summary>
		/// Data center version.
		/// </summary>
		DataCenter = 5,
		/// <summary>
		/// Professional version.
		/// </summary>
		Professional = 6,
		/// <summary>
		/// Embedded version.
		/// </summary>
		Embedded = 7,
		/// <summary>
		/// Workstation version.
		/// </summary>
		Workstation = 8,
		/// <summary>
		/// Home version (XP).
		/// </summary>
		Home = 9,
		/// <summary>
		/// Server version.
		/// </summary>
		Server = 0xA,
        /// <summary>
        /// Windows Vista Home Basic.
        /// </summary>
        HomeBasic = 0xF10,
        /// <summary>
        /// Windows Vista Home Basic N.
        /// </summary>
        HomeBasicN = 0xF10A,
        /// <summary>
        /// Windows Vista Home Premium.
        /// </summary>
        HomePremium = 0xF11,
        /// <summary>
        /// Windows Vista Business.
        /// </summary>
        Business = 0xF12,
        /// <summary>
        /// Windows Vista Business N.
        /// </summary>
        BusinessN = 0xF12A,
        /// <summary>
        /// Windows Vista Ultimate.
        /// </summary>
        Ultimate = 0xF13,
        /// <summary>
        /// Enterprise Server.
        /// </summary>
        EnterpriseServer = 0xF14,
		/// <summary>
		/// Windows Vista Starter.
		/// </summary>
		Starter = 0xF15
    }

	/// <summary>
	/// Enumeration containing the logging levels.
	/// </summary>
	public enum LoggingLevel
	{
		/// <summary>None, this will disable the log.</summary>
		None = 0,
		/// <summary>This will only pass messages marked as simple.</summary>
		Simple = 1,
		/// <summary>This will only pass messages marked as intermediate.</summary>
		Intermediate = 2,
		/// <summary>This will only pass messages marked as verbose.</summary>
		Verbose = 3,
		/// <summary>This will print all messages regardless of level.</summary>
		All = 4
	}

	#region Error Codes.
	/// <summary>
	/// Enumeration for logger error codes.
	/// </summary>
	public enum LoggerErrorCodes
	{
		/// <summary>
		/// Cannot write to the log file.
		/// </summary>
		CannotWrite = 0x1F000002,
		/// <summary>
		/// Cannot open the log file for writing.
		/// </summary>
		CannotOpen = 0x1F000003
	}

	/// <summary>
	/// Enumeration for environment variable error codes.
	/// </summary>
	public enum EnvironmentVariableErrorCodes
	{
		/// <summary>
		/// Cannot read the environment variable.
		/// </summary>
		CannotReadVariable = 0x1F000004,
		/// <summary>
		/// Cannot write to the environment variable.
		/// </summary>
		CannotWriteVariable = 0x1F000005
	}

	/// <summary>
	/// Enumeration for error dialog icons.
	/// </summary>
	public enum ErrorDialogIcons
	{
		/// <summary>
		/// Default round error icon.
		/// </summary>
		Default = 0,
		/// <summary>
		/// Icon for a general bug.
		/// </summary>
		Bug = 1,
		/// <summary>
		/// Same as the round error icon, except in a square.
		/// </summary>
		Box = 2,
		/// <summary>
		/// Icon for a disk error.
		/// </summary>
		Disk = 3,
		/// <summary>
		/// Icon for a data error.
		/// </summary>
		Data = 4,
		/// <summary>
		/// Icon for a hardware error.
		/// </summary>
		Hardware = 5
	}

	/// <summary>
	/// Enumeration for joystick errors.
	/// </summary>
	public enum JoystickErrors
	{
		/// <summary>Invalid joystick ID.</summary>
		InvalidID = 0,
		/// <summary>Invalid parameter.</summary>
		InvalidParameter = 1,
		/// <summary>Joystick driver not present.</summary>
		DriverNotPresent = 2,
		/// <summary>Cannot retrieve the joystick name.</summary>
		CannotGetName = 3
	}
	#endregion
}
