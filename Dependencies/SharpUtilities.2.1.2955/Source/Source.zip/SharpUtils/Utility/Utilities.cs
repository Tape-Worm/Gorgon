#region LGPL.
// 
// SharpUtils.
// Copyright (C) 2006 Michael Winsor
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
// 
// Created: Tuesday, August 08, 2006 9:17:51 AM
// 
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Drawing;
using System.Runtime.InteropServices;
using Microsoft.Win32;
using SharpUtilities.Native.Win32;

namespace SharpUtilities.Utility
{
	/// <summary>
	/// Delegate used for callback when enumerating joystick devices.
	/// </summary>
	/// <param name="ID">ID of the joystick.</param>
	/// <param name="name">Name of the joystick.</param>
	/// <param name="caps">Capabilities of the joystick.</param>
	/// <param name="threshold">Threshold of the joystick.</param>
	/// <param name="connected">TRUE if the device is connected, FALSE if not.</param>
	/// <returns>TRUE to keep enumerating, FALSE to stop.</returns>
	public delegate bool JoystickEnumerator(int ID, string name, JOYCAPS caps,  int threshold, bool connected);

	/// <summary>
	/// Value type containing a font character set.
	/// </summary>
	public struct FontCharSetData
	{
		#region Variables.
		private string _name;		// Name of the character set.
		private int _start;			// Starting ordinal.
		private int _end;			// Ending ordinal.
		#endregion

		#region Properties.
		/// <summary>
		/// Property to return the character set name.
		/// </summary>
		public string Name
		{
			get
			{
				return _name;
			}
		}

		/// <summary>
		/// Property to return the starting ordinal.
		/// </summary>
		public int StartOrdinal
		{
			get
			{
				return _start;
			}
		}

		/// <summary>
		/// Property to return the ending ordinal.
		/// </summary>
		public int EndOrdinal
		{
			get
			{
				return _end;
			}
		}
		#endregion

		#region Constructor.
		/// <summary>
		/// Constructor.
		/// </summary>
		/// <param name="name">Character set name.</param>
		/// <param name="startOrdinal">Starting ordinal.</param>
		/// <param name="endOrdinal">Ending ordinal.</param>
		internal FontCharSetData(string name, int startOrdinal, int endOrdinal)
		{
			_name = name;
			_start = startOrdinal;
			_end = endOrdinal;
		}
		#endregion
	}

	/// <summary>
	/// Value type containing font data.
	/// </summary>
	public struct FontData
	{
		#region Variables.
		private string _name;					// Name of the font.
		private FontCharSetData[] _charSets;	// Character sets available to the font.
		private char _start;					// Starting character.
		private char _end;						// Ending character.
		private char _default;					// Default character.
		private char _break;					// Word break character.
		#endregion

		#region Properties.
		/// <summary>
		/// Property to return the name of the font.
		/// </summary>
		public string Name
		{
			get
			{
				return _name;
			}
		}

		/// <summary>
		/// Property to return the character sets available to the font.
		/// </summary>
		public FontCharSetData[] CharacterSets
		{
			get
			{
				return _charSets;
			}
		}

		/// <summary>
		/// Propert to return the starting character.
		/// </summary>
		public char StartingCharacter
		{
			get
			{
				return _start;
			}
		}

		/// <summary>
		/// Property to return the ending character.
		/// </summary>
		public char EndingCharacter
		{
			get
			{
				return _end;
			}
		}

		/// <summary>
		/// Property to return the default character.
		/// </summary>
		public char DefaultCharacter
		{
			get
			{
				return _default;
			}
		}

		/// <summary>
		/// Property to return the word breaking character.
		/// </summary>
		public char WordBreakCharacter
		{
			get
			{
				return _break;
			}
		}
		#endregion

		#region Methods.		
		/// <summary>
		/// Function to retrieve the character sets from the font.
		/// </summary>
		/// <param name="charSetData">Data for the character sets.</param>
		private void GetCharSets(uint[] charSetData)
		{
			List<FontCharSetData> charSets = null;	// List of font character sets.

			charSets = new List<FontCharSetData>();			

			// Characters 0000 - 005A, 0060-007A
			charSets.Add(new FontCharSetData("Basic Latin", 0, 0x007A));

			// 1 0x00A0 - 0x00FF - Latin-1 Supplement 
			if ((charSetData[0] & 2) == 2)
				charSets[0] = new FontCharSetData("Basic Latin + Latin-1 Supplement", 0x0000, 0x00FF);

			// 2 0x0100 - 0x017F - Latin Extended-A 
			if ((charSetData[0] & 4) == 4)
				charSets.Add(new FontCharSetData("Latin Extended-A", 0x0100, 0x017F));

			// 3 0x0180 - 0x024F - Latin Extended-B 
			if ((charSetData[0] & 8) == 8)
				charSets.Add(new FontCharSetData("Latin Extended-B", 0x0180, 0x024F));

			// 4 0x0250 - 0x02AF - IPA Extensions 
			if ((charSetData[0] & 16) == 16)
				charSets.Add(new FontCharSetData("IPA Extensions", 0x0250, 0x02AF));

			// 5 0x02B0 - 0x02FF - Spacing Modifier Letters 
			if ((charSetData[0] & 32) == 32)
				charSets.Add(new FontCharSetData("Spacing Modifier Letters", 0x02B0, 0x02FF));

			// 6 0x0300 - 0x036F - Combining Diacritical Marks 
			if ((charSetData[0] & 64) == 64)
				charSets.Add(new FontCharSetData("Combining Diacritical Marks", 0x0300, 0x036F));

			// 7 0x0370 - 0x03FF - Greek and Coptic 
			if ((charSetData[0] & 128) == 128)
				charSets.Add(new FontCharSetData("Greek and Coptic", 0x0370, 0x03FF));

			// 9 0x0400 - 0x052F - Cyrillic Cyrillic + Supplementary  
			if ((charSetData[0] & 512) == 512)
			{
				charSets.Add(new FontCharSetData("Cyrillic", 0x0400, 0x04FF));
				charSets.Add(new FontCharSetData("Cyrillic + Supplementary", 0x500, 0x52F));
			}

			// 10 0x0530 - 0x058F - Armenian 
			if ((charSetData[0] & 1024) == 1024)
				charSets.Add(new FontCharSetData("Armenian", 0x0530, 0x058F));

			// 11 0x0590 - 0x05FF - Basic Hebrew 
			if ((charSetData[0] & 2048) == 2048)
				charSets.Add(new FontCharSetData("Basic Hebrew", 0x0590, 0x05FF));

			// 13 0x0600 - 0x06FF - Basic Arabic 
			if ((charSetData[0] & 8192) == 8192)
				charSets.Add(new FontCharSetData("Basic Arabic", 0x0600, 0x06FF));

			// 15 0x0900 - 0x097F - Devanagari 
			if ((charSetData[0] & 32768) == 32768)
				charSets.Add(new FontCharSetData("Devanagari", 0x0900, 0x097F));

			// 16 0x0980 - 0x09FF - Bengali 
			if ((charSetData[0] & 65536) == 65536)
				charSets.Add(new FontCharSetData("Bengali", 0x0980, 0x09FF));

			// 17 0x0A00 - 0x0A7F - Gurmukhi 
			if ((charSetData[0] & 131072) == 131072)
				charSets.Add(new FontCharSetData("Gurmukhi", 0x0A00, 0x0A7F));

			// 18 0x0A80 - 0x0AFF - Gujarati 
			if ((charSetData[0] & 262144) == 262144)
				charSets.Add(new FontCharSetData("Gujarati", 0x0A80, 0x0AFF));

			// 19 0x0B00 - 0x0B7F - Oriya 
			if ((charSetData[0] & 524288) == 524288)
				charSets.Add(new FontCharSetData("Oriya", 0x0B00, 0x0B7F));

			// 20 0x0B80 - 0x0BFF - Tamil 
			if ((charSetData[0] & 1048576) == 1048576)
				charSets.Add(new FontCharSetData("Tamil", 0x0B80, 0x0BFF));

			// 21 0x0C00 - 0x0C7F - Telugu 
			if ((charSetData[0] & 2097152) == 2097152)
				charSets.Add(new FontCharSetData("Telugu", 0x0C00, 0x0C7F));

			// 22 0x0C80 - 0x0CFF - Kannada 
			if ((charSetData[0] & 4194304) == 4194304)
				charSets.Add(new FontCharSetData("Kannada", 0x0C80, 0x0CFF));

			// 23 0x0D00 - 0x0D7F - Malayalam 
			if ((charSetData[0] & 8388608) == 8388608)
				charSets.Add(new FontCharSetData("Malayalam", 0x0D00, 0x0D7F));

			// 24 0x0E00 - 0x0E7F - Thai 
			if ((charSetData[0] & 16777216) == 16777216)
				charSets.Add(new FontCharSetData("Thai", 0x0E00, 0x0E7F));

			// 25 0x0E80 - 0x0EFF - Lao 
			if ((charSetData[0] & 33554432) == 33554432)
				charSets.Add(new FontCharSetData("Lao", 0x0E80, 0x0EFF));

			// 26 0x10A0 - 0x10FF - Georgian 
			if ((charSetData[0] & 67108864) == 67108864)
				charSets.Add(new FontCharSetData("Georgian", 0x10A0, 0x10FF));

			// 28 0x1100 - 0x11FF - Hangul Jamo 
			if ((charSetData[0] & 268435456) == 268435456)
				charSets.Add(new FontCharSetData("Hangul Jamo", 0x1100, 0x11FF));

			// 29 0x1E00 - 0x1EFF - Latin Extended Additional 
			if ((charSetData[0] & 536870912) == 536870912)
				charSets.Add(new FontCharSetData("Latin Extended Additional", 0x1E00, 0x1EFF));

			// 30 0x1F00 - 0x1FFF - Greek Extended 
			if ((charSetData[0] & 1073741824) == 1073741824)
				charSets.Add(new FontCharSetData("Greek Extended", 0x1F00, 0x1FFF));

			// 31 0x2000 - 0x206F - General Punctuation 
			if ((charSetData[0] & 2147483648) == 2147483648)
				charSets.Add(new FontCharSetData("General Punctuation", 0x2000, 0x206F));

			// 32 0x2070 - 0x209F - Subscripts and Superscripts 
			if ((charSetData[1] & 1) == 1)
				charSets.Add(new FontCharSetData("Subscripts and Superscripts", 0x2070, 0x209F));

			// 33 0x20A0 - 0x20CF - Currency Symbols 
			if ((charSetData[1] & 2) == 2)
				charSets.Add(new FontCharSetData("Currency Symbols", 0x20A0, 0x20CF));

			// 34 0x20D0 - 0x20FF - Combining Diacritical Marks for Symbols 
			if ((charSetData[1] & 4) == 4)
				charSets.Add(new FontCharSetData("Combining Diacritical Marks for Symbols", 0x20D0, 0x20FF));

			// 35 0x2100 - 0x214F - Letter-like Symbols 
			if ((charSetData[1] & 8) == 8)
				charSets.Add(new FontCharSetData("Letter-like Symbols", 0x2100, 0x214F));

			// 36 0x2150 - 0x218F - Number Forms 
			if ((charSetData[1] & 16) == 16)
				charSets.Add(new FontCharSetData("Number Forms", 0x2150, 0x218F));

			// 37 0x2190 - 0x297F - Arrows + Supplemental + Arrows-A Supplemental + Arrows-B  
			if ((charSetData[1] & 32) == 32)
			{
				charSets.Add(new FontCharSetData("Arrows", 0x2190, 0x21FF));
				charSets.Add(new FontCharSetData("Arrows - Supplemental A", 0x27F0, 0x27FF));
				charSets.Add(new FontCharSetData("Arrows - Supplemental B", 0x2900, 0x297F));
			}

			// 38 0x2200 - 0x2AFF - Mathematical Operators + Supplemental Mathematical Operators + Miscellaneous Mathematical Symbols - A + Miscellaneous Mathematical Symbols - B  
			if ((charSetData[1] & 64) == 64)
			{
				charSets.Add(new FontCharSetData("Mathematical Operators", 0x2200, 0x22FF));
				charSets.Add(new FontCharSetData("Mathematical Operators - Supplemental", 0x2A00, 0x2AFF));
				charSets.Add(new FontCharSetData("Misc Mathematical Symbols - A", 0x27C0, 0x27EF));
				charSets.Add(new FontCharSetData("Misc Mathematical Symbols - B", 0x2980, 0x29FF));
			}

			// 39 0x2300 - 0x23FF - Miscellaneous Technical 
			if ((charSetData[1] & 128) == 128)
				charSets.Add(new FontCharSetData("Miscellaneous Technical", 0x2300, 0x23FF));

			// 40 0x2400 - 0x243F - Control Pictures 
			if ((charSetData[1] & 256) == 256)
				charSets.Add(new FontCharSetData("Control Pictures", 0x2400, 0x243F));

			// 41 0x2440 - 0x245F - Optical Character Recognition 
			if ((charSetData[1] & 512) == 512)
				charSets.Add(new FontCharSetData("Optical Character Recognition", 0x2440, 0x245F));

			// 42 0x2460 - 0x24FF - Enclosed Alphanumerics 
			if ((charSetData[1] & 1024) == 1024)
				charSets.Add(new FontCharSetData("Enclosed Alphanumerics", 0x2460, 0x24FF));

			// 43 0x2500 - 0x257F - Box Drawing 
			if ((charSetData[1] & 2048) == 2048)
				charSets.Add(new FontCharSetData("Box Drawing", 0x2500, 0x257F));

			// 44 0x2580 - 0x259F - Block Elements 
			if ((charSetData[1] & 4096) == 4096)
				charSets.Add(new FontCharSetData("Block Elements", 0x2580, 0x259F));

			// 45 0x25A0 - 0x25FF - Geometric Shapes 
			if ((charSetData[1] & 8192) == 8192)
				charSets.Add(new FontCharSetData("Geometric Shapes", 0x25A0, 0x25FF));

			// 46 0x2600 - 0x26FF - Miscellaneous Symbols 
			if ((charSetData[1] & 16384) == 16384)
				charSets.Add(new FontCharSetData("Miscellaneous Symbols", 0x2600, 0x26FF));

			// 47 0x2700 - 0x27BF - Dingbats 
			if ((charSetData[1] & 32768) == 32768)
				charSets.Add(new FontCharSetData("Dingbats", 0x2700, 0x27BF));

			// 48 0x3000 - 0x303F - Chinese, Japanese, and Korean (CJK) Symbols and Punctuation 
			if ((charSetData[1] & 65536) == 65536)
				charSets.Add(new FontCharSetData("Chinese, Japanese, and Korean (CJK) Symbols and Punctuation", 0x3000, 0x303F));

			// 49 0x3040 - 0x309F - Hiragana 
			if ((charSetData[1] & 131072) == 131072)
				charSets.Add(new FontCharSetData("Hiragana", 0x3040, 0x309F));

			// 50 0x30A0 - 0x30FF - 31F0 - 31FF  Katakana Katakana Phonetic Extensions  
			if ((charSetData[1] & 262144) == 262144)
			{
				charSets.Add(new FontCharSetData("Katakana", 0x30A0, 0x30FF));
				charSets.Add(new FontCharSetData("Katakana Phonetic Ext.", 0x31F0, 0x31FF));
			}

			// 51 0x3100 - 0x312F - 31A0 - 31Bf Bopomofo Extended Bopomofo 
			if ((charSetData[1] & 524288) == 524288)
			{
				charSets.Add(new FontCharSetData("Bopomofo", 0x3100, 0x312F));
				charSets.Add(new FontCharSetData("Bopomofo Extended", 0x31A0, 0x31BF));
			}

			// 52 0x3130 - 0x318F - Hangul Compatibility Jamo 
			if ((charSetData[1] & 1048576) == 1048576)
				charSets.Add(new FontCharSetData("Hangul Compatibility Jamo", 0x3130, 0x318F));

			// 54 0x3200 - 0x32FF - Enclosed CJK Letters and Months 
			if ((charSetData[1] & 4194304) == 4194304)
				charSets.Add(new FontCharSetData("Enclosed CJK Letters and Months", 0x3200, 0x32FF));

			// 55 0x3300 - 0x33FF - CJK Compatibility 
			if ((charSetData[1] & 8388608) == 8388608)
				charSets.Add(new FontCharSetData("CJK Compatibility", 0x3300, 0x33FF));

			// 56 0xAC00 - 0xD7A3 - Hangul 
			if ((charSetData[1] & 16777216) == 16777216)
				charSets.Add(new FontCharSetData("Hangul", 0xAC00, 0xD7A3));

			// 57 0xD800 - 0xDFFF - Surrogates.
			if ((charSetData[1] & 33554432) == 33554432)
				charSets.Add(new FontCharSetData("Surrogates.", 0xD800, 0xDFFF));

			// 59 Lots of ranges - Various ideographs.
			if ((charSetData[1] & 134217728) == 134217728)
			{
				charSets.Add(new FontCharSetData("CJK Unified Ideographs", 0x4E00, 0x9FFF));
				charSets.Add(new FontCharSetData("CJK Radicals Supplement", 0x2E80, 0x2EFF));
				charSets.Add(new FontCharSetData("Kangxi Radicals", 0x2F00, 0x2FDF));
				charSets.Add(new FontCharSetData("Ideographic Description", 0x2FF0, 0x2FFF));
				charSets.Add(new FontCharSetData("CJK Unified Ideographs Extension A", 0x3400, 0x4DBF));
				charSets.Add(new FontCharSetData("CJK Unified Ideographs Extension B", 0x20000, 0x2A6DF));
			}

			// 60 0xE000 - 0xF8FF - Private Use Area 
			if ((charSetData[1] & 268435456) == 268435456)
				charSets.Add(new FontCharSetData("Private Use Area", 0xE000, 0xF8FF));


			// 61 0xF900 - 0xFAFF, 0x2F800 - 0x2FA1F - Private Use Area 
			if ((charSetData[1] & 536870912) == 536870912)
			{
				charSets.Add(new FontCharSetData("CJK Compatibility Ideographs", 0xF900, 0xFAFF));
				charSets.Add(new FontCharSetData("CJK Compatibility Ideographs - Supplement", 0x2F800, 0x2FA1F));
			}
			
			// 62 0xFB00 - 0xFB4F - Alphabetic Presentation Forms 
			if ((charSetData[1] & 1073741824) == 1073741824)
				charSets.Add(new FontCharSetData("Alphabetic Presentation Forms", 0xFB00, 0xFB4F));

			// 63 0xFB50 - 0xFDFF - Arabic Presentation Forms-A 
			if ((charSetData[1] & 2147483648) == 2147483648)
				charSets.Add(new FontCharSetData("Arabic Presentation Forms-A", 0xFB50, 0xFDFF));

			// 64 0xFE20 - 0xFE2F - Combining Half Marks 
			if ((charSetData[2] & 1) == 1)
				charSets.Add(new FontCharSetData("Combining Half Marks", 0xFE20, 0xFE2F));

			// 65 0xFE30 - 0xFE4F - CJK Compatibility Forms 
			if ((charSetData[2] & 2) == 2)
				charSets.Add(new FontCharSetData("CJK Compatibility Forms", 0xFE30, 0xFE4F));

			// 66 0xFE50 - 0xFE6F - Small Form Variants 
			if ((charSetData[2] & 4) == 4)
				charSets.Add(new FontCharSetData("Small Form Variants", 0xFE50, 0xFE6F));

			// 67 0xFE70 - 0xFEFE - Arabic Presentation Forms-B 
			if ((charSetData[2] & 8) == 8)
				charSets.Add(new FontCharSetData("Arabic Presentation Forms-B", 0xFE70, 0xFEFE));

			// 68 0xFF00 - 0xFFEF - Halfwidth and Fullwidth Forms 
			if ((charSetData[2] & 16) == 16)
				charSets.Add(new FontCharSetData("Halfwidth and Fullwidth Forms", 0xFF00, 0xFFEF));

			// 69 0xFFF0 - 0xFFFF - Specials 
			if ((charSetData[2] & 32) == 32)
				charSets.Add(new FontCharSetData("Specials", 0xFFF0, 0xFFFF));

			// 70 0x0F00 - 0x0FFF - Tibetan 
			if ((charSetData[2] & 64) == 64)
				charSets.Add(new FontCharSetData("Tibetan", 0x0F00, 0x0FFF));

			// 71 0x0700 - 0x074F - Syriac 
			if ((charSetData[2] & 128) == 128)
				charSets.Add(new FontCharSetData("Syriac", 0x0700, 0x074F));

			// 72 0x0780 - 0x07BF - Thaana 
			if ((charSetData[2] & 256) == 256)
				charSets.Add(new FontCharSetData("Thaana", 0x0780, 0x07BF));

			// 73 0x0D80 - 0x0DFF - Sinhala 
			if ((charSetData[2] & 512) == 512)
				charSets.Add(new FontCharSetData("Sinhala", 0x0D80, 0x0DFF));

			// 74 0x1000 - 0x109F - Myanmar 
			if ((charSetData[2] & 1024) == 1024)
				charSets.Add(new FontCharSetData("Myanmar", 0x1000, 0x109F));

			// 75 0x1200 - 0x12BF - Ethiopic 
			if ((charSetData[2] & 2048) == 2048)
				charSets.Add(new FontCharSetData("Ethiopic", 0x1200, 0x12BF));

			// 76 0x13A0 - 0x13FF - Cherokee 
			if ((charSetData[2] & 4096) == 4096)
				charSets.Add(new FontCharSetData("Cherokee", 0x13A0, 0x13FF));

			// 77 0x1400 - 0x167F - Canadian Aboriginal Syllabics 
			if ((charSetData[2] & 8192) == 8192)
				charSets.Add(new FontCharSetData("Canadian Aboriginal Syllabics", 0x1400, 0x167F));

			// 78 0x1680 - 0x169F - Ogham 
			if ((charSetData[2] & 16384) == 16384)
				charSets.Add(new FontCharSetData("Ogham", 0x1680, 0x169F));

			// 79 0x16A0 - 0x16FF - Runic 
			if ((charSetData[2] & 32768) == 32768)
				charSets.Add(new FontCharSetData("Runic", 0x16A0, 0x16FF));

			// 80 0x1780 - 0x17FF - 19E0 - 19FF  Khmer Khmer Symbols  
			if ((charSetData[2] & 65536) == 65536)
			{
				charSets.Add(new FontCharSetData("Khmer", 0x1780, 0x17FF));
				charSets.Add(new FontCharSetData("Khmer Symbols", 0x19E0, 0x19FF));
			}

			// 81 0x1800 - 0x18AF - Mongolian 
			if ((charSetData[2] & 131072) == 131072)
				charSets.Add(new FontCharSetData("Mongolian", 0x1800, 0x18AF));

			// 82 0x2800 - 0x28FF - Braille 
			if ((charSetData[2] & 262144) == 262144)
				charSets.Add(new FontCharSetData("Braille", 0x2800, 0x28FF));

			// 83 0xA000 - 0xA4CF - Yi + Yi Radicals 
			if ((charSetData[2] & 524288) == 524288)
			{
				charSets.Add(new FontCharSetData("Yi", 0xA000, 0xA48F));
				charSets.Add(new FontCharSetData("Yi Radicals", 0xA480, 0xA4CF));
			}

			// 84 0x1700 - 0x177F - Tagalog Hanunoo Buhid Tagmanwa
			if ((charSetData[2] & 1048576) == 1048576)
			{
				charSets.Add(new FontCharSetData("Tagalog", 0x1700, 0x171F));
				charSets.Add(new FontCharSetData("Hanunoo", 0x1720, 0x173F));
				charSets.Add(new FontCharSetData("Buhid", 0x1740, 0x175F));
				charSets.Add(new FontCharSetData("Tagmanwa", 0x1760, 0x177F));
			}

			// 85 0x10300 - 0x1032F - Old Italic 
			if ((charSetData[2] & 2097152) == 2097152)
				charSets.Add(new FontCharSetData("Old Italic", 0x10300, 0x1032F));

			// 86 0x10330 - 0x1034F - Gothic 
			if ((charSetData[2] & 4194304) == 4194304)
				charSets.Add(new FontCharSetData("Gothic", 0x10330, 0x1034F));

			// 87 0x10440 - 0x1044F - Deseret 
			if ((charSetData[2] & 8388608) == 8388608)
				charSets.Add(new FontCharSetData("Deseret", 0x10440, 0x1044F));

			// 88 0x1D000 - 0x1D1FF - Byzantine Musical Symbols Musical Symbols 
			if ((charSetData[2] & 16777216) == 16777216)
			{
				charSets.Add(new FontCharSetData("Byzantine Musical Symbols", 0x1D000, 0x1D0FF));
				charSets.Add(new FontCharSetData("Musical Symbols", 0x1D100, 0x1D1FF));
			}

			// 89 0x1D400 - 0x1D7FF - Mathematical Alphanumeric Symbols 
			if ((charSetData[2] & 33554432) == 33554432)
				charSets.Add(new FontCharSetData("Mathematical Alphanumeric Symbols", 0x1D400, 0x1D7FF));

			// 90 0xFFF80 - 0xFFFFF, 0x10FF80 - 0x10FFFF - Private use (plane 15 and 16).
			if ((charSetData[2] & 67108864) == 67108864)
			{
				charSets.Add(new FontCharSetData("Private use - Plane 15", 0xFFF80, 0xFFFFF));
				charSets.Add(new FontCharSetData("Private use - Plane 16", 0x10FF80, 0x10FFFF));
			}

			// Note:  Most of the other bits are reserved so they are not included.

			// Copy into an array.
			_charSets = charSets.ToArray();			
		}
		#endregion

		#region Constructor/Destructor.
		/// <summary>
		/// Constructor.
		/// </summary>
		/// <param name="fontName">Name of the font.</param>
		/// <param name="fontData">Data for the font.</param>
		internal FontData(string fontName, NEWTEXTMETRICEX fontData)
		{
			_name = fontName;
			_start = Convert.ToChar(fontData.ntmTm.tmFirstChar);
			_end = Convert.ToChar(fontData.ntmTm.tmLastChar);
			_default = Convert.ToChar(fontData.ntmTm.tmDefaultChar);
			_break = Convert.ToChar(fontData.ntmTm.tmBreakChar);
			_charSets = null;
			GetCharSets(fontData.ntmFontSig.fsUsb);
		}
		#endregion
	}

	/// <summary>
	/// Static object that contains helper functionality.
	/// </summary>
	public static class Utilities
	{
		#region Variables.
		private static FontData _fontData;			// Font data.
		#endregion

		#region Methods.
		/// <summary>
		/// Function called during font family enumeration.
		/// </summary>
		/// <param name="logFont">Logical font data.</param>
		/// <param name="textMetric">Physical font data.</param>
		/// <param name="type">Type of font.</param>
		/// <param name="param">User supplied parameter.</param>
		/// <returns>0 to stop enumeration, -1 to keep going.</returns>
		private static int FontEnumerator(ref ENUMLOGFONTEX logFont, ref NEWTEXTMETRICEX textMetric, FontTypes type, IntPtr param)
		{			
			_fontData = new FontData(logFont.elfLogFont.lfFaceName, textMetric);
			return 0;
		}

		/// <summary>
		/// Function to build a managed icon from an unmanaged icon handle.
		/// </summary>
		/// <param name="iconHandle">Icon handle to create from.</param>
		/// <returns>A new managed icon.</returns>
		private static Icon ConvertUnmanagedIcon(IntPtr iconHandle)
		{
			Icon icon = null;		// New icon.
			Icon clone = null;		// Clone of the icon.

			// Get the icon from the unmanaged handle.
			icon = Icon.FromHandle(iconHandle);
			clone = (Icon)icon.Clone();

			// Clean up.
			icon.Dispose();
			Win32API.DestroyIcon(iconHandle);

			return clone;
		}

		/// <summary>
		/// Function to retrieve font data.
		/// </summary>
		/// <param name="context">Device context.</param>
		/// <param name="font">Font to extract data for.</param>
		/// <param name="charSet">Character set used to restrict enumeration.</param>
		/// <returns>A value type containing information about the font.</returns>
		public static FontData GetFontData(IDeviceContext context, Font font, FontCharacterSet charSet)
		{
			LOGFONT fontData;				// Logical font data.
			IntPtr dc = IntPtr.Zero;		// Device context.

			if (font == null)
				throw new ArgumentNullException("font");

			try
			{				
				fontData = new LOGFONT();
				fontData.lfCharSet = charSet;
				fontData.lfFaceName = font.Name;
				dc = context.GetHdc();

				Win32API.EnumFontFamiliesEx(dc, ref fontData, FontEnumerator, IntPtr.Zero, 0);

				return _fontData;
			}
			catch (Exception ex)
			{
				throw new CannotRetrieveFontDataException("Unable to retrieve the font data for the font '" + font.Name + "'", ex);
			}
			finally 
			{
				if (dc != IntPtr.Zero)
					context.ReleaseHdc();
			}
		}

		/// <summary>
		/// Gets the font data.
		/// </summary>
		/// <param name="context">The context.</param>
		/// <param name="font">The font.</param>
		/// <returns></returns>
		public static FontData GetFontData(IDeviceContext context, Font font)
		{
			return GetFontData(context, font, FontCharacterSet.Default);
		}

		/// <summary>
		/// Function to return a string formatted to the nearest unit of measure for byte amounts.
		/// </summary>
		/// <param name="amount">Amount in bytes.</param>
		/// <returns>A string containing the amount and proper unit for memory.</returns>
		public static string FormatByteUnits(ulong amount)
		{
			double value = amount;		// Amount to convert.

			// If we get less than 1 here, we're dealing with bytes.
			if ((value / 1024) < 1)
				return amount.ToString() + " bytes";

			// Convert to KB.
			value /= 1024;

			// If we get less than 1 here, we're dealing with kilobytes.
			if ((value / 1024) < 1)
				return value.ToString("0.00") + " KB";

			// Convert to MB.
			value /= 1024;

			// If we get less than 1 here, we're dealing with megabytes.
			if ((value / 1024) < 1)
				return value.ToString("0.00") + " MB";

			// Convert to GB.
			value /= 1024;

			// If we get less than 1 here, we're dealing with gigabytes.
			if ((value / 1024) < 1)
				return value.ToString("0.00") + " GB";

			// Convert to TB.
			value /= 1024;

			// Default to terrabytes.
			return value.ToString("0.00") + " TB";
		}

		/// <summary>
		/// Function to enumerate the available joysticks.
		/// </summary>
		/// <param name="enumerator">Enumerator callback.</param>
		/// <param name="includeDisconnected">TRUE to include all joysticks, include those that are disconnected, FALSE to exclude.</param>
		/// <returns>The number of devices enumerated.</returns>
		public static int EnumerateJoysticks(JoystickEnumerator enumerator, bool includeDisconnected)
		{
			JOYCAPS capabilities = new JOYCAPS();	// Joystick capabilities.
			string name = string.Empty;				// Name of the joystick.
			int error = 0;							// Error code.
			bool connected = false;					// Is the joystick connected?
			int deviceCount = 0;					// Number of devices.
			int threshold = 0;						// Joystick threshold.
			int count = 0;							// Count of enumerated devices.

			// Get the number of devices.
			deviceCount = Win32API.joyGetNumDevs();
			if (deviceCount == 0)
				return 0;

			// Enumerate devices.
			for (int i = 0; i < deviceCount; i++)
			{
				error = Win32API.joyGetDevCaps(i, ref capabilities, Marshal.SizeOf(typeof(JOYCAPS)));

				// If the joystick has no registry key, then skip it.
				if ((capabilities.RegistryKey != null) && (capabilities.RegistryKey != string.Empty) && 
					(capabilities.Name != null) && (capabilities.Name != string.Empty))
				{
					// Check for error, stop enumeration.
					if (error > 0)
						throw new JoystickDriverNotPresentException();

					// Get the name.
					name = GetJoystickName(capabilities, i);
					connected = IsJoystickConnected(i);					
					// Enumerate.
					if (((connected) && (!includeDisconnected)) || (includeDisconnected))
					{
						error = Win32API.joyGetThreshold(i, out threshold);

						// Check for error, stop enumeration.
						if (error > 0)
							throw new JoystickDriverNotPresentException();

						count++;

						if (!enumerator(i,name, capabilities, threshold, connected))
							return count;						
					}
				}
			}

			return count;
		}

		/// <summary>
		/// Function to determine if a joystick is connected.
		/// </summary>
		/// <param name="ID">ID of the joystick to check.</param>
		/// <returns>TRUE if connected, FALSE if not.</returns>
		public static bool IsJoystickConnected(int ID)
		{
			JOYINFO info = new JOYINFO();		// Joystick information.
			int error = 0;						// Error code.

			error = Win32API.joyGetPos(ID, ref info);

			switch (error)
			{
				case 0:
					return true;
				case 6:
					throw new JoystickDriverNotPresentException();
			}

			return false;
		}

		/// <summary>
		/// Function to retrieve a joystick name from the registry.
		/// </summary>
		/// <param name="ID">ID of the joystick to retrieve data for.</param>
		/// <returns>The name of the joystick.</returns>
		public static string GetJoystickName(int ID)		
		{
			JOYCAPS caps = new JOYCAPS();		// Joystick capabilities.
			int error = 0;						// Error code.

			error = Win32API.joyGetDevCaps(ID, ref caps, Marshal.SizeOf(typeof(JOYCAPS)));

			switch (error)
			{
				case 165:
				case 11:
				case 2:
					throw new InvalidJoystickIDException(ID);
				case 6:
					throw new JoystickDriverNotPresentException();
			}

			return GetJoystickName(caps, ID);
		}

		/// <summary>
		/// Function to retrieve a joystick name from the registry.
		/// </summary>
		/// <param name="joystickData">Joystick capability data.</param>
		/// <param name="ID">ID of the joystick to retrieve data for.</param>
		/// <returns>The name of the joystick.</returns>
		public static string GetJoystickName(JOYCAPS joystickData, int ID)
		{
			RegistryKey rootKey = null;			// Root registry key.
			RegistryKey lookup = null;			// Look up key.
			RegistryKey nameKey = null;			// Name key.
			string key = string.Empty;			// Key name.
			string defaultName = string.Empty;	// Default name.

			try
			{
				defaultName = joystickData.AxisCount.ToString() + "-axis, " + joystickData.ButtonCount.ToString() + "-button joystick.";
				rootKey = Registry.CurrentUser;
				
				// Get the device ID.				
				lookup = rootKey.OpenSubKey(@"SYSTEM\CurrentControlSet\Control\MediaResources\Joystick\" + joystickData.RegistryKey + @"\CurrentJoystickSettings");

				// Try the local machine key as a root if that lookup failed.
				if (lookup == null)
				{
					rootKey.Close();
					rootKey = Registry.LocalMachine;
					lookup = rootKey.OpenSubKey(@"SYSTEM\CurrentControlSet\Control\MediaResources\Joystick\" + joystickData.RegistryKey + @"\CurrentJoystickSettings");
				}

				if (lookup != null)
				{
					key = lookup.GetValue("Joystick" + (ID + 1) + "OEMName", string.Empty).ToString();

					// If we have no name, then build one.
					if (key == string.Empty)
						return defaultName;

					// Get the name.
					nameKey = rootKey.OpenSubKey(@"SYSTEM\CurrentControlSet\Control\MediaProperties\PrivateProperties\Joystick\OEM\" + key);
					return nameKey.GetValue("OEMName", defaultName).ToString();
				}
				else
					return defaultName;
			}
			catch(Exception ex)
			{
				throw new CannotRetrieveJoystickNameException(ex);
			}
			finally
			{
				if (nameKey != null)
					nameKey.Close();
				if (lookup != null)
					lookup.Close();
				if (rootKey != null)
					rootKey.Close();
			}
		}

		/// <summary>
		/// Function to determine if a function is numeric or not.
		/// </summary>
		/// <param name="value">Value to test.</param>
		/// <returns>TRUE if the value is numeric, FALSE if not.</returns>
		public static bool IsNumeric(string value)
		{
			Decimal result;							// Result.

			return Decimal.TryParse(value, out result);
		}

		/// <summary>
		/// Function to return the widths for a character.
		/// </summary>
		/// <param name="dc">Device context in which the font resides.</param>
		/// <param name="character">Character to retrieve metrics for.</param>
		/// <param name="font">Font to use.</param>
		/// <returns>ABC character metrics.</returns>
		public static ABC GetCharacterWidth(IDeviceContext dc, char character, Font font)
		{
			IntPtr hDc = IntPtr.Zero;					// Handle to the device context.
			IntPtr oldHandle = IntPtr.Zero;				// Previous object handle.			
			IntPtr fontHandle = IntPtr.Zero;			// Font handle.
			ABC[] fontSize;								// Font character size.

			fontSize = new ABC[1];

			try
			{
				// Get the font handle.
				fontHandle = font.ToHfont();

				// Default to the desktop device context handle.
				hDc = dc.GetHdc();

				// Switch to the font.
				oldHandle = Win32API.SelectObject(hDc, fontHandle);

				// Get font character widths.
				Win32API.GetCharABCWidths(hDc, (uint)character, (uint)character, fontSize);
			}
			catch (Exception ex)
			{
				UI.ErrorBox(null, ex);
			}
			finally
			{
				// Restore and release handles.
				if (oldHandle != IntPtr.Zero)
					Win32API.SelectObject(hDc, oldHandle);
				if (fontHandle != IntPtr.Zero)
					Win32API.DeleteObject(fontHandle);
				if (hDc != IntPtr.Zero)
					dc.ReleaseHdc();
			}

			return fontSize[0];
		}

		/// <summary>
		/// Function to return the widths for a character.
		/// </summary>
		/// <param name="dc">Device context in which the font resides.</param>
		/// <param name="character">Character to retrieve metrics for.</param>
		/// <param name="font">Font to use.</param>
		/// <returns>ABC character metrics.</returns>
		public static ABCFloat GetCharacterWidthFloat(IDeviceContext dc, char character, Font font)
		{
			IntPtr hDc = IntPtr.Zero;					// Handle to the device context.
			IntPtr oldHandle = IntPtr.Zero;				// Previous object handle.			
			IntPtr fontHandle = IntPtr.Zero;			// Font handle.
			ABCFloat[] fontSize;						// Font character size.

			fontSize = new ABCFloat[1];

			try
			{
				// Get the font handle.
				fontHandle = font.ToHfont();

				// Default to the desktop device context handle.
				hDc = dc.GetHdc();

				// Switch to the font.
				oldHandle = Win32API.SelectObject(hDc, fontHandle);

				// Get font character widths.
				Win32API.GetCharABCWidthsFloat(hDc, (uint)character, (uint)character, fontSize);
			}
			catch (Exception ex)
			{
				UI.ErrorBox(null, ex);
			}
			finally
			{
				// Restore and release handles.
				if (oldHandle != IntPtr.Zero)
					Win32API.SelectObject(hDc, oldHandle);
				if (fontHandle != IntPtr.Zero)
					Win32API.DeleteObject(fontHandle);
				if (hDc != IntPtr.Zero)
					dc.ReleaseHdc();
			}

			return fontSize[0];
		}

		/// <summary>
		/// Function to return all the icons from a file.
		/// </summary>
		/// <param name="fileName">Path and name of the file.</param>
		/// <param name="size">Size of the icon to retrieve.</param>
		/// <returns>A list of icons.</returns>
		/// <remarks>This code was created by Gil Schmidt from CodeProject.com.  http://www.codeproject.com/csharp/iconhandler.asp</remarks>
		public static Icon[] GetIconsFromFile(string fileName, ShellIconSize size)
		{
			int count = 0;						// Icon count.
			IntPtr[] iconHandles = null;		// Icon handles.
			Icon[] newIcons = null;				// New icons.


			// Get number of icons.
			count = Win32API.ExtractIconEx(fileName, -1, null, null, 0);

			if (count == 0)
				return null;

			// Get list of handles.
			iconHandles = new IntPtr[count];

			// Get icon handles.
			if (size == ShellIconSize.Small)
				Win32API.ExtractIconEx(fileName, 0, null, iconHandles, count);
			else
				Win32API.ExtractIconEx(fileName, 0, iconHandles, null, count);

			// Create icon list.
			newIcons = new Icon[count];

			//gets the icons in a list.
			for (int i = 0; i < count; i++)
				newIcons[i] = ConvertUnmanagedIcon(iconHandles[i]);

			return newIcons;
		}

		/// <summary>
		/// Function to get an icon based on a file extension.
		/// </summary>
		/// <param name="extension">File extension to use.</param>
		/// <param name="size">Size of the icon.</param>
		/// <returns>An icon from the shell that is related to the extension passed.</returns>
		/// <remarks>This code was created by Gil Schmidt from CodeProject.com.  http://www.codeproject.com/csharp/iconhandler.asp</remarks>
		public static Icon IconFromExtension(string extension, ShellIconSize size)
        {
			Icon newIcon = null;			// New icon.
			SHFILEINFO shellInfo;			// Shell file info data.
			uint flags = 0;					// Flags for function.

			if (extension == null)
				throw new ArgumentNullException("extension");

            try
            {
                //add '.' if nessesry
                if ((extension.Length > 0) && (extension[0] != '.'))
                    extension = '.' + extension;
				
				shellInfo = new SHFILEINFO();

				// Get the icon through the shell.
				flags = (uint)(ShellInfoFlags.Icon | ShellInfoFlags.UseFileAttributes) | (uint)size;
				Win32API.SHGetFileInfo(extension, 0, ref shellInfo, (uint)Marshal.SizeOf(typeof(SHFILEINFO)), flags);

				newIcon = ConvertUnmanagedIcon(shellInfo.IconHandle);
                return newIcon;
            }
            catch 
            {
				throw;
            }
        }
#endregion
	}
}
