#region LGPL.
// 
// SharpUtils.
// Copyright (C) 2005 Michael Winsor
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
// 
// Created: Thursday, December 01, 2005 10:34:02 PM
// 
#endregion

using System;

namespace SharpUtilities.Utility
{
	/// <summary>
	/// A value type representing an environment variable and its value.
	/// </summary>
	public struct EnvironmentVariable
	{
		#region Variables.		
		private string _name;		// Environment variable name.
		private string _value;		// Environment variable value.
		#endregion

		#region Properties.
		/// <summary>
		/// Property to return the variable name.
		/// </summary>
		public string Name
		{
			get
			{
				return _name;
			}
		}

		/// <summary>
		/// Property to return the variable value.
		/// </summary>
		public string Value
		{
			get
			{
				return _value;
			}
		}
		#endregion

		#region Constructor.
		/// <summary>
		/// Constructor.
		/// </summary>
		/// <param name="name">Name of the variable.</param>
		/// <param name="value">Value of the variable.</param>
		public EnvironmentVariable(string name, string value)
		{
			_name = name;
			_value = value;
		}
		#endregion
	}
}
