#region LGPL.
// 
// SharpUtils.
// Copyright (C) 2005 Michael Winsor
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
// 
// Created: Sunday, December 11, 2005 5:39:27 PM
// 
#endregion

using System;

namespace SharpUtilities.Utility
{
    /// <summary>
    /// Cannot open file exception.
    /// </summary>
    /// <remarks>Exception thrown by the logger object when the log file cannot be opened.</remarks>
	public class CannotOpenException : SharpException
	{
		#region Constructor.
		/// <summary>
		/// Constructor.
		/// </summary>
		/// <param name="fileName">Filename of the log file.</param>
		/// <param name="ex">Inner exception.</param>
		public CannotOpenException(string fileName, Exception ex)
			: base("Could not open the log file '" + fileName + "'.", ex)
		{
		}

		/// <summary>
		/// Constructor.
		/// </summary>
		/// <param name="fileName">Filename of the log file.</param>
		public CannotOpenException(string fileName)
			: this(fileName, null)
		{
		}
		#endregion
	}

    /// <summary>
    /// Cannot write file exception.
    /// </summary>
    /// <remarks>Exception thrown when the logger object cannot write to the log file.</remarks>
	public class CannotWriteException : SharpException
	{
		#region Constructor.
		/// <summary>
		/// Constructor.
		/// </summary>
		/// <param name="fileName">Filename of the log file.</param>
		/// <param name="ex">Inner exception.</param>
		public CannotWriteException(string fileName, Exception ex)
			: base("Cannot write to the log file '" + fileName + "'.", ex)
		{
		}

		/// <summary>
		/// Constructor.
		/// </summary>
		/// <param name="fileName">Filename of the log file.</param>
		public CannotWriteException(string fileName)
			: this(fileName, null)
		{
		}
		#endregion
	}

    /// <summary>
    /// Environment variable read exception.
    /// </summary>
    /// <remarks>Exception thrown when an attempt to read an environment variable fails or the environment variable is not found.</remarks>
	public class EnvironmentVariableReadException : SharpException
	{
		#region Constructor.
		/// <summary>
		/// Constructor.
		/// </summary>
		/// <param name="message">Message to pass through.</param>
		/// <param name="errorCode">Error code for the exception.</param>
		public EnvironmentVariableReadException(string message, EnvironmentVariableErrorCodes errorCode)
			: base(message, (int)errorCode)
		{
		}

		/// <summary>
		/// Constructor.
		/// </summary>
		public EnvironmentVariableReadException()
			: this("The environment variable could not be read.", EnvironmentVariableErrorCodes.CannotReadVariable)
		{
		}
		#endregion
	}

    /// <summary>
    /// Environment variable write exception.
    /// </summary>
    /// <remarks>Exception thrown when an attempt to read an environment variable fails or the environment variable is not found.</remarks>
	public class EnvironmentVariableWriteException : SharpException
	{
		#region Constructor.
		/// <summary>
		/// Constructor.
		/// </summary>
		/// <param name="message">Message to pass through.</param>
		/// <param name="errorCode">Error code for the exception.</param>
		public EnvironmentVariableWriteException (string message, EnvironmentVariableErrorCodes errorCode)
			: base(message, (int)errorCode)
		{
		}

		/// <summary>
		/// Constructor.
		/// </summary>
		public EnvironmentVariableWriteException()
			: this("The environment variable could not be written.", EnvironmentVariableErrorCodes.CannotWriteVariable)
		{
		}
		#endregion
	}

    /// <summary>
    /// Invalid joystick ID exception.
    /// </summary>
    /// <remarks>Exception thrown when a joystick ID is invalid.</remarks>
	public class InvalidJoystickIDException
		: SharpException
	{
		#region Constructor.
		/// <summary>
		/// Constructor.
		/// </summary>
		/// <param name="message">Message to pass through.</param>
		/// <param name="errorCode">Error code for the exception.</param>
		public InvalidJoystickIDException(string message, JoystickErrors errorCode)
			: base(message, (int)errorCode)
		{
		}

		/// <summary>
		/// Constructor.
		/// </summary>
		public InvalidJoystickIDException(int ID)
			: this("The joystick ID (" + ID.ToString() + ") is not valid.", JoystickErrors.InvalidID)
		{
		}
		#endregion
	}

    /// <summary>
    /// Invalid joystick parameter exception.
    /// </summary>
    /// <remarks>Exception thrown when a joystick function receives invalid data as a parameter.</remarks>
	public class InvalidJoystickParameterException
		: SharpException
	{
		#region Constructor.
		/// <summary>
		/// Constructor.
		/// </summary>
		/// <param name="message">Message to pass through.</param>
		/// <param name="errorCode">Error code for the exception.</param>
		public InvalidJoystickParameterException(string message, JoystickErrors errorCode)
			: base(message, (int)errorCode)
		{
		}

		/// <summary>
		/// Constructor.
		/// </summary>
		public InvalidJoystickParameterException()
			: this("Joystick parameter is invalid.", JoystickErrors.InvalidParameter)
		{
		}
		#endregion
	}

    /// <summary>
    /// Joystick driver not present exception.
    /// </summary>
    /// <remarks>Exception thrown when there's no joystick driver present for the joystick ID passed.</remarks>
	public class JoystickDriverNotPresentException
		: SharpException
	{
		#region Constructor.
		/// <summary>
		/// Constructor.
		/// </summary>
		/// <param name="message">Message to pass through.</param>
		/// <param name="errorCode">Error code for the exception.</param>
		public JoystickDriverNotPresentException(string message, JoystickErrors errorCode)
			: base(message, (int)errorCode)
		{
		}

		/// <summary>
		/// Constructor.
		/// </summary>
		public JoystickDriverNotPresentException()
			: this("The joystick driver is not present.", JoystickErrors.InvalidParameter)
		{
		}
		#endregion
	}

    /// <summary>
    /// Cannot retrieve joystick name exception.
    /// </summary>
    /// <remarks>Exception thrown when the function is unable to retrieve the joystick name.</remarks>
	public class CannotRetrieveJoystickNameException
		: SharpException
	{
		#region Constructor.
		/// <summary>
		/// Constructor.
		/// </summary>
		/// <param name="message">Message to pass through.</param>
		/// <param name="errorCode">Error code for the exception.</param>
		public CannotRetrieveJoystickNameException(string message, JoystickErrors errorCode)
			: base(message, (int)errorCode)
		{
		}

		/// <summary>
		/// Constructor.
		/// </summary>
		public CannotRetrieveJoystickNameException(Exception ex)
			: this("Cannot retrieve the joystick name.\n" + ex.Message, JoystickErrors.CannotGetName)
		{
		}
		#endregion
	}

	/// <summary>
	/// Cannot retrieve font data exception.
	/// </summary>
	/// <remarks>Exception thrown when the function is unable to retrieve the requested font data.</remarks>
	public class CannotRetrieveFontDataException
		: SharpException
	{
		#region Constructor.
		/// <summary>
		/// Constructor.
		/// </summary>
		/// <param name="message">Message to pass through.</param>
		/// <param name="ex">Inner exception.</param>
		public CannotRetrieveFontDataException(string message, Exception ex)
			: base(message, ex)
		{
		}

		/// <summary>
		/// Constructor.
		/// </summary>
		/// <param name="message">Message to display.</param>
		public CannotRetrieveFontDataException(string message)
			: this(message, null)
		{
		}

		/// <summary>
		/// Constructor.
		/// </summary>
		/// <param name="ex">Inner exception.</param>
		public CannotRetrieveFontDataException(Exception ex)
			: this("Cannot retrieve the joystick name.", ex)
		{
		}
		#endregion
	}
}
