#region LGPL.
// 
// SharpUtils.
// Copyright (C) 2006 Michael Winsor
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
// 
// Created: Tuesday, May 16, 2006 6:57:27 PM
// 
#endregion

using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using SharpUtilities.Collections;

namespace SharpUtilities.Buffers
{
	/// <summary>
	/// Object representing a circular (or "ring") buffer.
	/// </summary>
	/// <remarks>A ring buffer contains no start and no end, the read and write position should wrap around to beginning of the buffer if the size is reached.
	/// <para>Thanks to SuperPig from http://www.gamedev.net for the idea and code.</para>
	/// </remarks>
	public class RingBuffer<T>
	{
		#region Variables.
		private int _bufferSize;			// Buffer size.
		private T[] _buffer;				// Buffer.
		private int _readPointer;			// Read position.
		private int _writePointer;			// Write position.
		#endregion

		#region Properties.
		/// <summary>
		/// Property to return the buffer.
		/// </summary>
		public T[] Buffer
		{
			get
			{
				return _buffer;
			}
		}

		/// <summary>
		/// Property to return the position of the read pointer.
		/// </summary>
		public int ReadPosition
		{
			get
			{
				return _readPointer;
			}
		}

		/// <summary>
		/// Property to return the position of the write pointer.
		/// </summary>
		public int WritePosition
		{
			get
			{
				return _writePointer;
			}
		}

		/// <summary>
		/// Property to set or return the size of buffer in elements of T.
		/// </summary>
		public int BufferSize
		{
			get
			{
				return _bufferSize;
			}
			set
			{
				if (value < 4)
					throw new BufferSizeInvalid(4);
				_bufferSize = value;
				_buffer = new T[_bufferSize];
				FormatBuffer();
			}
		}

		/// <summary>
		/// Property to return the size of the data already written to the buffer.
		/// </summary>
		public int DataSize
		{
			get
			{
				int prevWrite = _writePointer;		// Previous writer.

				while (prevWrite < _readPointer)
					prevWrite += _buffer.Length;

				return prevWrite - _readPointer - 1;
			}
		}
		#endregion

		#region Methods.
		/// <summary>
		/// Function to erase and initialize the buffer.
		/// </summary>
		public void FormatBuffer()
		{
			for (int i = 0; i < _buffer.Length;i++)
				_buffer[i] = default(T);
			_readPointer = 0;
			_writePointer = 1;
		}

		/// <summary>
		/// Function to read the item at the current read position.
		/// </summary>
		/// <returns>Item at the read position.</returns>
		public T Read()
		{
			// Get the value.			
			++_readPointer;

			while (_readPointer >= _buffer.Length)
				_readPointer -= _buffer.Length;

			if (_readPointer == _writePointer)
			{
				++_writePointer;
				while (_writePointer > _buffer.Length)
					_writePointer -= _buffer.Length;
			}

			return _buffer[_readPointer];
		}

		/// <summary>
		/// Function to write the specified data into the current write position.
		/// </summary>
		/// <param name="data">Data to write.</param>
		public void Write(T data)
		{
			// Write the value.
			_buffer[_writePointer] = data;
			++_writePointer;

			while (_writePointer > _buffer.Length)
				_writePointer -= _buffer.Length;

			if (_readPointer == _writePointer)
			{
				--_writePointer;
				while (_writePointer < 0)
					_writePointer += _buffer.Length;
			}
		}
		#endregion

		#region Constructor/Destructor.
		/// <summary>
		/// Constructor.
		/// </summary>
		/// <param name="size">Size in elements of "T".</param>
		public RingBuffer(int size)
		{
			BufferSize = size;
		}

		/// <summary>
		/// Constructor.
		/// </summary>
		/// <param name="data">Array of data to copy.</param>
		public RingBuffer(Array data)
		{
			if (!(data.GetType() == typeof(T)))
				throw new BufferTypeMismatch(typeof(T));

			BufferSize = data.Length;

			// Copy.
			for (int i = 0; i < data.Length; i++)
				_buffer[i] = (T)data.GetValue(i);
		}

		/// <summary>
		/// Constructor.
		/// </summary>
		/// <param name="data">Data to copy.</param>
		public RingBuffer(Collection<T> data)
		{
			BufferSize = data.Count;

			// Copy.
			for (int i = 0; i < data.Count; i++)
				_buffer[i] = data[i];
		}

		/// <summary>
		/// Constructor.
		/// </summary>
		/// <param name="data">Data to copy.</param>
		public RingBuffer(DynamicArray<T> data)
		{
			BufferSize = data.Count;

			// Copy.
			for (int i = 0; i < data.Count; i++)
				_buffer[i] = data[i];
		}

		/// <summary>
		/// Constructor.
		/// </summary>
		/// <param name="data">Data to copy.</param>
		public RingBuffer(DictionaryCollection<T> data)
		{
			BufferSize = data.Count;

			// Copy.
			int i = 0;
			foreach (T item in data)
			{
				_buffer[i] = item;
				i++;
			}
		}
		#endregion
	}
}
