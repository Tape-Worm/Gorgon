#region LGPL.
// 
// SharpUtils.
// Copyright (C) 2006 Michael Winsor
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
// 
// Created: Tuesday, May 16, 2006 7:06:51 PM
// 
#endregion

using System;

namespace SharpUtilities.Buffers
{
    /// <summary>
    /// Buffer size invalid exception.
    /// </summary>
    /// <remarks>Exception thrown when a buffer's capacity is below a specified threshold.</remarks>
	public class BufferSizeInvalid : SharpException
	{
		#region Constructor.
		/// <summary>
		/// Constructor.
		/// </summary>
		/// <param name="message">Message to pass through to the exception.</param>
		/// <param name="errorCode">Error code to pass through to the exception.</param>
		public BufferSizeInvalid(string message, BufferErrorCodes errorCode)
			: base(message, (int)errorCode)
		{
		}

		/// <summary>
		/// Constructor.
		/// </summary>
		/// <param name="minimumSize">Minimum number of elements.</param>
		public BufferSizeInvalid(int minimumSize)
			: this("The size of the buffer must be greater than " + minimumSize.ToString() + " elements.",BufferErrorCodes.InvalidBufferSize)
		{
		}
		#endregion
	}

    /// <summary>
    /// Buffer type mismatch exception.
    /// </summary>
    /// <remarks>Exception thrown when a buffer contains a specific data type, but there was an attempt to store another type of data.</remarks>
	public class BufferTypeMismatch : SharpException
	{
		#region Constructor.
		/// <summary>
		/// Constructor.
		/// </summary>
		/// <param name="message">Message to pass through to the exception.</param>
		/// <param name="errorCode">Error code to pass through to the exception.</param>
		public BufferTypeMismatch(string message, BufferErrorCodes errorCode)
			: base(message, (int)errorCode)
		{
		}

		/// <summary>
		/// Constructor.
		/// </summary>
		/// <param name="type">Type of data to be stored within the buffer.</param>
		public BufferTypeMismatch(Type type)
			: this("The type specified does not match the type '" + type.Name + "' used by the buffer.", BufferErrorCodes.TypeMismatch)
		{
		}
		#endregion
	}
}
