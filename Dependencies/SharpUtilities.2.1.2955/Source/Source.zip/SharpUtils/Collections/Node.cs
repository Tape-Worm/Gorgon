#region LGPL.
// 
// SharpUtils.
// Copyright (C) 2005 Michael Winsor
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
// 
// Created: Wednesday, May 18, 2005 8:28:57 AM
// 
#endregion

using System;
using System.Collections;
using System.Collections.Generic;
using SharpUtilities.Utility;

namespace SharpUtilities.Collections
{
	/// <summary>
	/// Abstract Class representing a node for an acyclic graph.
	/// </summary>
	/// <remarks>
	/// Nodes are used to represent connected points in a graph.  This allows us to create a hierarchy of objects, like an upside down tree.  A node that has no parent node is considered the root of the node-tree.
	/// <para>Objects deriving from this class will be able to be interconnected with other Node objects.</para>
	/// 	<para>Node objects can also contain other objects deriving from the <seealso cref="INodeObject">INodeObject</seealso> interface which the derived object can modify those contained objects depending on function of the containing Node.</para>
	/// </remarks>
	public abstract class Node 
		: NamedObject, IEnumerable<Node> 
	{
		#region Variables.
		/// <summary>
		/// A list of children for this node.
		/// </summary>
        protected SortedList<string,Node> _children;
		/// <summary>
		/// The parent of this node, Null (or nothing) if this is the root node.
		/// </summary>
		protected Node _parent;

		/// <summary>
		/// A list of child nodes that need to be updated.
		/// </summary>
		protected List<Node> _dirty;                  // List of child nodes that need updating.
		/// <summary>
		/// A flag to indicate that the node has changed in some way.
		/// </summary>
		protected bool _changed;	                    // Flag to indicate that the node has changed and should call its invalidate event.			
		private NodeObjects _items;                 // List of items attached to this node.
		
		#endregion

		#region Properties.
		/// <summary>
		/// Property to return the number of children contained within this node.
		/// </summary>
		public int Count
		{
			get
			{
				return _children.Count;
			}
		}

		/// <summary>
		/// Read-only property to return a list of node objects.
		/// </summary>
		/// <remarks>
		/// The <seealso cref="NodeObjects">NodeObjects</seealso> collection is a container of objects that will be associated with this node.
		/// <para>The purpose of having objects contained within the node is to allow changes to the node to be propagated to these objects via the <seealso cref="Invalidate">Invalidate()</seealso> function.</para>
		/// </remarks>
		/// <value>This will return a <see cref="NodeObjects">NodeObjects</see> collection containing items that are associated with this node.</value>
        public NodeObjects NodeObjects
        {
            get
            {
                return _items;
            }
        }

		/// <summary>
		/// Read-only property to return a child node by its <seealso cref="NamedObject">name</seealso>.
		/// </summary>
		/// <value>Returns a <see cref="Node">Node</see> object representing the child node.</value>
		/// <exception cref="KeyNotFoundException">The name of the child node was not found.</exception>
		public virtual Node this[string key]
		{
			get
			{
				if (!_children.ContainsKey(key))
					throw new KeyNotFoundException(key);

				return _children[key];
			}
		}

		/// <summary>
		/// Property to return a child node by its index.
		/// </summary>
		/// <value>Returns a <see cref="Node">Node</see> object representing the child node.</value>
		/// <exception cref="IndexOutOfBoundsException">The index is not within the range of 0 to <seealso cref="Count">Count</seealso>-1 or the child list is empty.</exception>
        public virtual Node this[int index]
        {
            get
            {
				if ((index < 0) || (index >= _children.Count))
					throw new IndexOutOfBoundsException(index);

                return _children[_children.Keys[index]];
            }
        }

		/// <summary>
		/// Property to return or set the parent for this node.
		/// </summary>
		/// <remarks>
		/// Use this property if it is necessary to alter the hierarchy relationship of this node.
		/// <para>
		/// Null (or Nothing) will be returned if this node is a root node and setting Null will detach this node from its current parent and make ths node a root node.
		/// </para>
		/// </remarks>
		/// <value>Sets or returns a <see cref="Node">Node</see> object that is the parent of this object.</value>
        public Node Parent
        {
            get
            {
                return _parent;
            }
            set
            {
                SetParent(value);
            }
        }
		#endregion

		#region Methods.
		/// <summary>
		/// Function to set the parent of this node.
		/// </summary>
		/// <remarks>
		/// This is the actual implementation for parent reassignment.  
		/// <para>See the <seealso cref="Parent">Parent</seealso> property for more details.</para>
		/// </remarks>
		/// <param name="parent">Parent of this node.</param>
		protected void SetParent(Node parent)
		{
			// Remove from previous parent.
			if (_parent != null)
				_parent.Remove(this.Name);

			_parent = null;

			// Add to new parent.
			if (parent != null)                
				parent.AddChildNode(this);

			Refresh();
		}

		/// <summary>
		/// Function to set nodes to a 'dirty' state.
		/// </summary>
		/// <remarks>This function can set the calling Node to a dirty state as well, or it can only just set the children to a dirty state.  This can be useful when this node needs to propagate current changes to its children.</remarks>
		/// <param name="onlychildren">TRUE to only update the children of this node, FALSE to mark this node as well.</param>
		/// <example>
		/// [C#] The following will extend the <seealso cref="Invalidate">Invalidate</seealso> example to illustrate how to use MarkDirty():
		/// <code>
		/// using System;
		/// using System.Windows.Forms;
		/// using SharpUtilities;
		/// 
		/// public class MyNodeObject : INodeObject
		/// {
		///		// Sum.
		///		private int _sum = 0;
		/// 
		///		// ... Implement required functions ...
		///		public void Calculate()
		///		{
		///			_sum += Owner.TheValue;
		///		}
		/// }
		/// 
		/// // Your derived node.
		/// public MyNode : Node
		/// {
		///		// The value for this node.
		///		private int _theValue;
		/// 
		///		// ... Add required functions and so on ...
		/// 
		///		// Property to return the value.
		///		public int TheValue
		///		{
		///			get
		///			{
		///				return _theValue;
		///			}
		///		}
		/// 
		///		// Function called when updating the node.
		///		protected override Invalidate()
		///		{
		///			// Calculate.
		///			foreach (MyNodeObject obj in NodeObjects)
		///				obj.Calculate();
		///		}
		/// 
		///		// Function to update the value for this node.
		///		public void UpdateValue(int someValue)
		///		{
		///			_theValue = someValue;
		///			// MARKDIRTY IS CALLED HERE.  This will also update the children.
		///			// Calling Invalidate would only update this node.
		///			MarkDirty(true);
		///			// Commit the changes.
		///			Refresh();
		///		}
		/// 
		///		// Function to add a child node.
		///		public Add(string childName)
		///		{
		///			MyNode childNode = new MyNode(childName);
		/// 
		///			try
		///			{
		///				// ... Do custom things to the node ...
		///				AddChildNode(node);
		///			}
		///			catch (SharpException e)
		///			{
		///				if (e.ErrorCode == SharpErrors.DuplicateObject)
		///					MessageBox.Show("Error",childName + " already exists.  Did not add to the node.");
		///			}
		///		}
		/// }
		/// </code>
		/// </example>
		protected void MarkDirty(bool onlychildren)
		{		
			// Mark all child nodes of this node as dirty.
			foreach(Node n in this)
				n.MarkDirty(false);

			if (!onlychildren)
			{
				// Mark us as dirty.
				if (_parent != null)
				{
					// Add us to the parent node's dirty list (if we aren't already there).
					if (!_parent._dirty.Contains(this))
					{
						_changed = true;
						_parent._dirty.Add(this);
					}
				} else
					_changed = true;				
			}
		}
		/// <summary>
		/// Function called when the node is changed in some way.
		/// </summary>
		/// <remarks>
		/// Derived classes must implement this function.
		/// <para>This function can be used to update the system in response to the change to the node.  For example the objects contained within this node can be updated in response to the change in this node.</para>
		/// </remarks>
		/// <example>
		/// [C#] The following will illustrate how to use Invalidate():
		/// <code>
		/// using System;
		/// using System.Windows.Forms;
		/// using SharpUtilities;
		/// 
		/// public class MyNodeObject : INodeObject
		/// {
		///		// Sum.
		///		private int _sum = 0;
		/// 
		///		// ... Implement required functions ...
		///		public void Calculate()
		///		{
		///			_sum += Owner.TheValue;
		///		}
		/// }
		/// 
		/// // Your derived node.
		/// public MyNode : Node
		/// {
		///		// The value for this node.
		///		private int _theValue;
		/// 
		///		// ... Add required functions and so on ...
		/// 
		///		// Property to return the value.
		///		public int TheValue
		///		{
		///			get
		///			{
		///				return _theValue;
		///			}
		///		}
		/// 
		///		// Function called when updating the node.
		///		protected override Invalidate()
		///		{
		///			// Calculate.
		///			foreach (MyNodeObject obj in NodeObjects)
		///				obj.Calculate();
		///		}
		/// 
		///		// Function to update the value for this node.
		///		public void UpdateValue(int someValue)
		///		{
		///			_theValue = someValue;
		///			Invalidate();
		///		}
		/// 
		///		// Function to add a child node.
		///		public Add(string childName)
		///		{
		///			MyNode childNode = new MyNode(childName);
		/// 
		///			try
		///			{
		///				// ... Do custom things to the node ...
		///				AddChildNode(node);
		///			}
		///			catch (SharpException e)
		///			{
		///				if (e.ErrorCode == SharpErrors.DuplicateObject)
		///					MessageBox.Show("Error",childName + " already exists.  Did not add to the node.");
		///			}
		///		}
		/// }
		/// </code>
		/// </example>
		protected abstract void Invalidate();

		/// <summary>
		/// Function to add a chlid node to this node.
		/// </summary>
		/// <remarks>
		/// Call this function in the derived class to add a child node to this node.
		/// <para>
		/// When the child node is added, it will be marked as dirty and ready to receive any notifications/changes from the <seealso cref="Parent">Parent</seealso>.</para>
		/// </remarks>
		/// <param name="node"><see cref="Node">Node</see> object to add.</param>
		/// <example>
		/// [C#] The following will illustrate how to use AddChildNode:
		/// <code>
		/// using System;
		/// using System.Windows.Forms;
		/// using SharpUtilities;
		/// 
		/// // Your derived node.
		/// public MyNode : Node
		/// {
		///		// ... Add required functions and so on ...
		/// 
		///		// Function to add a child node.
		///		public Add(string childName)
		///		{
		///			MyNode childNode = new MyNode(childName);
		/// 
		///			try
		///			{
		///				// ... Do custom things to the node ...
		///				AddChildNode(node);
		///			}
		///			catch (SharpException e)
		///			{
		///				if (e.ErrorCode == SharpErrors.DuplicateObject)
		///					MessageBox.Show("Error",childName + " already exists.  Did not add to the node.");
		///			}
		///		}
		/// }
		/// </code>
		/// </example>
		/// <exception cref="DuplicateObjectException">A child node with the same name already exists.</exception>
        protected virtual void AddChildNode(Node node)
        {
			if (_children.ContainsKey(node.Name))
				throw new DuplicateObjectException(node.Name);

            node._parent = this;
            _children.Add(node.Name, node);

            // Mark any children as dirty.
            node.MarkDirty(false);
        }

		/// <summary>
		/// Function to invalidate and update the node.
		/// </summary>
		/// <remarks>This function will commit any changes for this node and any nodes in the internal <see cref="_dirty">dirty</see> list.</remarks>
		public void Refresh()
		{
			// Update dirty nodes.
			for (int i = 0;i<_dirty.Count;i++)
				_dirty[i].Refresh();

			// Remove dirty nodes.
			_dirty.Clear();

			if (_changed)
				Invalidate();

			_changed = false;
		}

		/// <summary>
		/// Function to clear the children from this node.
		/// </summary>		
		public void Clear()
		{
			// Turn off parent.
			foreach (Node n in this)			
			{
				n.MarkDirty(false);
				n._parent = null;
			}

			_children.Clear();			
			Refresh();
		}

		/// <summary>
		/// Function to remove a child node by its key <see cref="NamedObject">name</see>.
		/// </summary>
		/// <param name="key"><seealso cref="NamedObject">Name</seealso> of the node to remove.</param>
		/// <exception cref="KeyNotFoundException">The name of the child node was not found.</exception>
		public virtual void Remove(string key)
		{
			if (!_children.ContainsKey(key))
				throw new KeyNotFoundException(key);
			
			this[key]._parent = null;
			this[key].MarkDirty(false);			
			_children.Remove(key);
		}

		/// <summary>
		/// Function to remove a child node by its index.
		/// </summary>
		/// <param name="index">Index of the node to remove.</param>
		/// <exception cref="IndexOutOfBoundsException">The index is not within the range of 0 to <seealso cref="Count">Count</seealso>-1 or the child list is empty.</exception>
        public virtual void Remove(int index)
        {
			if ((index < 0) || (index >= _children.Count))
				throw new IndexOutOfBoundsException(index);

            Remove(_children.Keys[index]);
        }


		/// <summary>
		/// Function to return an enumerator for the node.
		/// </summary>
		/// <returns>An IEnumerator interface to iterate through the child nodes.</returns>
		IEnumerator IEnumerable.GetEnumerator()
		{
			return _children.GetEnumerator();
		}

		/// <summary>
		/// Function to return an enumerator for the node.
		/// </summary>
		/// <returns>An IEnumerator interface to iterate through the child nodes.</returns>
        public IEnumerator<Node> GetEnumerator()
        {
            foreach (KeyValuePair<string,Node> child in _children)
                yield return child.Value;
        }

		/// <summary>
		/// Function to determine if this object is the same as another.
		/// </summary>
		/// <param name="obj">Object to compare.</param>
		/// <returns>TRUE if equal, FALSE if not.</returns>
		public override bool Equals(object obj)
		{
			if (obj is Node)
				return (((Node)obj).Name == this.Name);
			else
				return false;
		}

		/// <summary>
		/// Function to return the string representation of this object.
		/// </summary>
		/// <returns>A string containing the type of the object and the name.</returns>
		public override string ToString()
		{
			return string.Format("Node: [" + Name + "]");
		}

		/// <summary>
		/// Function to return the hash code for this object.
		/// </summary>
		/// <remarks>
		/// A hash code is used by dictionaries and hash tables to determine uniqueness of an object within those collections.
		/// <para>
		/// Hash values are related to their types, and as such should use one or more of its instance fields hash codes to build the hash code.
		/// </para>
		/// </remarks>
		/// <returns>A 32 bit integer representing the hash code.</returns>
		public override int GetHashCode()
		{
			return _objectName.GetHashCode() ^ _children.GetHashCode();
		}
		#endregion

		#region Constructor.
		/// <summary>
		/// Constructor.
		/// </summary>
		/// <remarks>This will create a new node with the name specified in the parameter.</remarks>
		/// <param name="nodename">Name for this node.</param>
		public Node(string nodename) : base(nodename)
		{
            _children = new SortedList<string,Node>(19);
			_dirty = new List<Node>();
            _items = new NodeObjects(this);
			_parent = null;
			_changed = true;
		}
		#endregion
	}
}