#region LGPL.
// 
// SharpUtils.
// Copyright (C) 2005 Michael Winsor
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
// 
// Created: Monday, May 23, 2005 12:21:12 AM
// 
#endregion

using System;
using System.Collections;
using System.Collections.Generic;

namespace SharpUtilities.Collections
{
	/// <summary>
	/// A collection of objects that are contained within a node.
	/// </summary>
	/// <remarks>
	/// A node is an organizational unit, representing a position within a list.  
	/// A node is also a container for items.  For example, a node may contain 
	/// names and descriptions of people within a company.  With this we can organize
	/// groups of objects into a tree hierarchy.
	/// </remarks>
	public class NodeObjects 
		: Collection<INodeObject>
	{
		#region Variables.
		private Node _owner;			                                // Owning node of this collection.
		#endregion

		#region Methods.
		/// <summary>
		/// Function to add a node object to this collection.
		/// </summary>
		/// <param name="obj">Node object to add.</param>
        public void Add(INodeObject obj)
		{
			AddItem(obj.Name, obj);
			obj.Owner = _owner;
		}

		/// <summary>
		/// Function to remove a node by its name.
		/// </summary>
		/// <param name="key">Name of the node to remove.</param>
		public override void Remove(string key)
		{
			Items[key].Owner = null;
			base.Remove(key);
		}

		/// <summary>
		/// Function to remove a node by its index.
		/// </summary>
		/// <param name="index">Index of the node to remove.</param>
		public override void Remove(int index)
		{
			GetItem(index).Owner = null;
			base.Remove(index);
		}

		/// <summary>
		/// Function to clear the list.
		/// </summary>
		public override void Clear()
		{
			foreach(INodeObject n in this)
				n.Owner = null;

			base.Clear();
		}
		#endregion

		#region Constructor.
		/// <summary>
		/// Constructor.
		/// </summary>
		/// <param name="owner">Node that owns this collection.</param>
		internal NodeObjects(Node owner)
		{
			_owner = owner;			
		}
		#endregion
	}
}
