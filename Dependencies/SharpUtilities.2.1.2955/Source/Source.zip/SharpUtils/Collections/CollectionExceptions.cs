#region LGPL.
// 
// SharpUtils.
// Copyright (C) 2005 Michael Winsor
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
// 
// Created: Saturday, December 10, 2005 2:21:46 PM
// 
#endregion

using System;

namespace SharpUtilities.Collections
{
    /// <summary>
    /// Duplicate object exception.
    /// </summary>
    /// <remarks>Exception thrown when there is an attempt to add an object with the same key as another object already existing in the collection.</remarks>
	public class DuplicateObjectException : SharpException
	{
		#region Constructor.
		/// <summary>
		/// Constructor.
		/// </summary>
		/// <param name="keyName">Key name of the object that caused the exception.</param>
		public DuplicateObjectException(string keyName)
			: base("The object named '" + keyName + "' already exists in this collection.")
		{
		}
		#endregion
	}

    /// <summary>
    /// Key not found exception.
    /// </summary>
    /// <remarks>Exception thrown when a key does not exist within a collection.</remarks>
	public class KeyNotFoundException : SharpException
	{
		#region Constructor.
		/// <summary>
		/// Constructor.
		/// </summary>
		/// <param name="keyName">Key name of the object that caused the exception.</param>
		public KeyNotFoundException(string keyName)
			: base("There is no object named '" + keyName + "' in this collection.")
		{
		}
		#endregion
	}

    /// <summary>
    /// Invalid index exception.
    /// </summary>
    /// <remarks>Exception thrown when an index is outside of the bounds of an array/collection.</remarks>
	public class IndexOutOfBoundsException : SharpException
	{
		#region Constructor.
		/// <summary>
		/// Constructor.
		/// </summary>
		/// <param name="index">Index that was outside of the bounds of the collection.</param>
		public IndexOutOfBoundsException(int index)
			: base("The index [" + index.ToString() + "] is outside of the boundaries of this collection.")
		{
		}
		#endregion
	}
}
