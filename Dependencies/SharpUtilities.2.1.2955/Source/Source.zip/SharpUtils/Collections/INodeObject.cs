#region LGPL.
// 
// SharpUtils.
// Copyright (C) 2005 Michael Winsor
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
// 
// Created: Sunday, May 22, 2005 11:53:01 PM
// 
#endregion

using System;

namespace SharpUtilities.Collections
{
	/// <summary>
	/// An interface to define an object that can be attached to a node.
	/// </summary>
	/// <remarks>
	/// A node is an organizational unit, representing a position within a list.  
	/// A node is also a container for items.  For example, a node may contain 
	/// names and descriptions of people within a company.  With this we can organize
	/// groups of objects into a tree hierarchy.
	/// </remarks>
	public interface INodeObject
	{
		#region Properties.
		/// <summary>
		/// Property to return or set the owning node of this item.
		/// </summary>
		Node Owner
		{
			get;
			set;
		}

		/// <summary>
		/// Property to return whether this object is attached to a node.
		/// </summary>
		bool Attached
		{
			get;
		}

		/// <summary>
		/// Property to return the name of this object.
		/// </summary>
		/// <remarks>
		/// If the object is derived from this and named object, then this will be
		/// filled automatically.
		/// </remarks>
		string Name
		{
			get;
		}
		#endregion
	}
}
