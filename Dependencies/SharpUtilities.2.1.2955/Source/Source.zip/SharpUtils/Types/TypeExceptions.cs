#region LGPL.
// 
// SharpUtils.
// Copyright (C) 2005 Michael Winsor
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
// 
// Created: Sunday, December 11, 2005 5:39:27 PM
// 
#endregion

using System;

namespace SharpUtilities
{
    /// <summary>
    /// Invalid name exception.
    /// </summary>
    /// <remarks>Exception thrown when a NULL or an empty string is passed into the NamedObject constructor.</remarks>
	public class InvalidNameException : SharpException
	{
		#region Constructor.
		/// <summary>
		/// Constructor.
		/// </summary>
		/// <param name="message">Message to pass through.</param>
		/// <param name="errorCode">Error code for the exception.</param>
		public InvalidNameException(string message, NamedObjectErrorCodes errorCode)
			: base(message, (int)errorCode)
		{
		}

		/// <summary>
		/// Constructor.
		/// </summary>
		public InvalidNameException()
			: this("The name of the object is not valid (possibly zero-length or NULL).", NamedObjectErrorCodes.InvalidName)
		{
		}
		#endregion
	}
}
