#region LGPL.
// 
// SharpUtils.
// Copyright (C) 2006 Michael Winsor
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
// 
// Created: Tuesday, July 04, 2006 9:43:58 AM
// 
#endregion

using System;
using System.Collections.Generic;
using System.Text;

namespace SharpUtilities
{
	/// <summary>
	/// A value type representing a 3D rectangle.
	/// </summary>
	public struct Rectangle3D
	{
		#region Variables.
		private int _left;					// Left of the cube.
		private int _top;					// Top of the cube.
		private int _width;					// Width of the cube.
		private int _height;				// Height of the cube.
		private int _near;					// Nearest Z depth of the cube.
		private int _depth;					// Depth of the cube.
		#endregion

		#region Properties.
		/// <summary>
		/// Property to set or return the left position of the cube.
		/// </summary>
		public int Left
		{
			get
			{
				return _left;
			}
			set
			{
				_left = value;
			}
		}

		/// <summary>
		/// Property to set or return the top position of the cube.
		/// </summary>
		public int Top
		{
			get
			{
				return _top;
			}
			set
			{
				_top = value;
			}
		}

		/// <summary>
		/// Property to set or return the nearest depth position of the cube.
		/// </summary>
		public int Near
		{
			get
			{
				return _near;
			}
			set
			{
				_near = value;
			}
		}

		/// <summary>
		/// Property to return the right most point of the cube.
		/// </summary>
		public int Right
		{
			get
			{
				return _left + _width;
			}
		}

		/// <summary>
		/// Property to return the bottom most point of the cube.
		/// </summary>
		public int Bottom
		{
			get
			{
				return _top + _height;
			}
		}

		/// <summary>
		/// Property to return the furthest point of the cube.
		/// </summary>
		public int Far
		{
			get
			{
				return _near + _depth;
			}
		}

		/// <summary>
		/// Property to set or return the width of the cube.
		/// </summary>
		public int Width
		{
			get
			{
				return _width;
			}
			set
			{
				_width = value;
			}
		}

		/// <summary>
		/// Property to set or return the height of the cube.
		/// </summary>
		public int Height
		{
			get
			{
				return _height;
			}
			set
			{
				_height = value;
			}
		}

		/// <summary>
		/// Property to set or return the depth of the cube.
		/// </summary>
		public int Depth
		{
			get
			{
				return _depth;
			}
			set
			{
				_depth = value;
			}
		}
		#endregion

		#region Methods.
		/// <summary>
		/// Function to set the points of the cube.
		/// </summary>
		/// <param name="x">Horizontal position of the cube.</param>
		/// <param name="y">Vertical position of the cube.</param>
		/// <param name="z">Depth position of the cube.</param>
		/// <param name="width">Width of the cube.</param>
		/// <param name="height">Height of the cube.</param>
		/// <param name="depth">Depth of the cube.</param>
		public void SetPoints(int x, int y, int z, int width, int height, int depth)
		{
			_left = x;
			_top = y;
			_width = width;
			_height = height;
			_near = z;
			_depth = depth;
		}

		/// <summary>
		/// Function to set the volume of the cube.
		/// </summary>
		/// <param name="width">Width of the cube.</param>
		/// <param name="height">Height of the cube.</param>
		/// <param name="depth">Depth of the cube.</param>
		public void SetVolume(int width, int height, int depth)
		{
			_width = width;
			_height = height;
			_depth = depth;
		}
		#endregion

		#region Constructor/Destructor.
		/// <summary>
		/// Constructor.
		/// </summary>
		/// <param name="x">Horizontal position of the cube.</param>
		/// <param name="y">Vertical position of the cube.</param>
		/// <param name="z">Depth position of the cube.</param>
		/// <param name="width">Width of the cube.</param>
		/// <param name="height">Height of the cube.</param>
		/// <param name="depth">Depth of the cube.</param>
		public Rectangle3D(int x, int y, int z, int width, int height, int depth)
		{
			_left = x;
			_top = y;
			_width = width;
			_height = height;
			_near = z;
			_depth = depth;
		}
		#endregion
	}

	/// <summary>
	/// A value type representing a 3D rectangle.
	/// </summary>
	public struct Rectangle3DF
	{
		#region Variables.
		private float _left;				// Left of the cube.
		private float _top;					// Top of the cube.
		private float _width;				// Width of the cube.
		private float _height;				// Height of the cube.
		private float _near;				// Nearest Z depth of the cube.
		private float _depth;				// Depth of the cube.
		#endregion

		#region Properties.
		/// <summary>
		/// Property to set or return the left position of the cube.
		/// </summary>
		public float Left
		{
			get
			{
				return _left;
			}
			set
			{
				_left = value;
			}
		}

		/// <summary>
		/// Property to set or return the top position of the cube.
		/// </summary>
		public float Top
		{
			get
			{
				return _top;
			}
			set
			{
				_top = value;
			}
		}

		/// <summary>
		/// Property to set or return the nearest depth position of the cube.
		/// </summary>
		public float Near
		{
			get
			{
				return _near;
			}
			set
			{
				_near = value;
			}
		}

		/// <summary>
		/// Property to return the right most pofloat of the cube.
		/// </summary>
		public float Right
		{
			get
			{
				return _left + _width;
			}
		}

		/// <summary>
		/// Property to return the bottom most pofloat of the cube.
		/// </summary>
		public float Bottom
		{
			get
			{
				return _top + _height;
			}
		}

		/// <summary>
		/// Property to return the furthest pofloat of the cube.
		/// </summary>
		public float Far
		{
			get
			{
				return _near + _depth;
			}
		}

		/// <summary>
		/// Property to set or return the width of the cube.
		/// </summary>
		public float Width
		{
			get
			{
				return _width;
			}
			set
			{
				_width = value;
			}
		}

		/// <summary>
		/// Property to set or return the height of the cube.
		/// </summary>
		public float Height
		{
			get
			{
				return _height;
			}
			set
			{
				_height = value;
			}
		}

		/// <summary>
		/// Property to set or return the depth of the cube.
		/// </summary>
		public float Depth
		{
			get
			{
				return _depth;
			}
			set
			{
				_depth = value;
			}
		}
		#endregion

		#region Methods.
		/// <summary>
		/// Function to set the points of the cube.
		/// </summary>
		/// <param name="x">Horizontal position of the cube.</param>
		/// <param name="y">Vertical position of the cube.</param>
		/// <param name="z">Depth position of the cube.</param>
		/// <param name="width">Width of the cube.</param>
		/// <param name="height">Height of the cube.</param>
		/// <param name="depth">Depth of the cube.</param>
		public void SetPoints(float x, float y, float z, float width, float height, float depth)
		{
			_left = x;
			_top = y;
			_width = width;
			_height = height;
			_near = z;
			_depth = depth;
		}

		/// <summary>
		/// Function to set the volume of the cube.
		/// </summary>
		/// <param name="width">Width of the cube.</param>
		/// <param name="height">Height of the cube.</param>
		/// <param name="depth">Depth of the cube.</param>
		public void SetVolume(float width, float height, float depth)
		{
			_width = width;
			_height = height;
			_depth = depth;
		}
		#endregion

		#region Constructor/Destructor.
		/// <summary>
		/// Constructor.
		/// </summary>
		/// <param name="x">Horizontal position of the cube.</param>
		/// <param name="y">Vertical position of the cube.</param>
		/// <param name="z">Depth position of the cube.</param>
		/// <param name="width">Width of the cube.</param>
		/// <param name="height">Height of the cube.</param>
		/// <param name="depth">Depth of the cube.</param>
		public Rectangle3DF(float x, float y, float z, float width, float height, float depth)
		{
			_left = x;
			_top = y;
			_width = width;
			_height = height;
			_near = z;
			_depth = depth;
		}
		#endregion
	}
}
