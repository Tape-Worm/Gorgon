#region LGPL.
// 
// SharpUtils.
// Copyright (C) 2005 Michael Winsor
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
// 
// Created: Tuesday, May 17, 2005 2:10:48 PM
// 
#endregion

using System;

namespace SharpUtilities
{
	/// <summary>
	/// Abstract Class representing a named object.
	/// </summary>
	/// <remarks>Classes inheriting from this object will have a name associated with it.  This is handy when dealing with unique objects within a collection.</remarks>
	public abstract class NamedObject
	{
		#region Variables.
		/// <summary>
		/// The name of the object.
		/// </summary>
		protected string _objectName;
		#endregion
		
		#region Properties.
		/// <summary>
		/// Read-only property to return the name of this object.
		/// </summary>
		/// <remarks>The name of an object need not be unique, however if it is used as a key value for a collection then it should be unique.</remarks>
		/// <value>A <see cref="string">string</see> containing the name of this object.</value>
		public virtual string Name
		{
			get
			{
				return _objectName;
			}
		}
		#endregion

		#region Methods.
		/// <summary>
		/// Function to determine if this named object is the same as another named object.
		/// </summary>
		/// <param name="obj">Object to compare.</param>
		/// <returns>TRUE if equal, FALSE if not.</returns>
		public override bool Equals(object obj)
		{
			if (obj is NamedObject)
				return (((NamedObject)obj).Name == _objectName);
			else
				return false;
		}

		/// <summary>
		/// Function to return the hash code for this object.
		/// </summary>
		/// <remarks>
		/// A hash code is used by dictionaries and hash tables to determine uniqueness of an object within those collections.
		/// <para>
		/// Hash values are related to their types, and as such should use one or more of its instance fields hash codes to build the hash code.
		/// </para>
		/// </remarks>
		/// <returns>A 32 bit integer representing the hash code.</returns>
		public override int GetHashCode()
		{
			return _objectName.GetHashCode();
		}

		/// <summary>
		/// Function to return the string representation of this object.
		/// </summary>
		/// <returns>A string containing the name of the type and the name stored within the object.</returns>
		public override string ToString()
		{
			return "Named object: [" + _objectName + "]";
		}
		#endregion

		#region Constructor.
		/// <summary>
		/// Constructor.
		/// </summary>
		/// <remarks>
		/// Since the <seealso cref="Name"></seealso><see cref="Name">Name</see> property is read-only, the name for an object must be passed to this constructor.  
		/// <para>Typically it will be difficult to rename an object that resides in a collection with its name as the key, thus making the property writable would be counter-productive.</para>
		/// 	<para>However, objects that descend from this object may choose to implement their own renaming scheme if they so choose.</para>
		/// 	<para>Ensure that the name parameter has a non-null string or is not a zero-length string.  Failing to do so will raise a <see cref="SharpException">SharpException</see>.</para>
		/// </remarks>
		/// <exception cref="InvalidNameException">Thrown when the name parameter is NULL or a zero length string.</exception>
		/// <param name="name">Name for this object.</param>
		public NamedObject(string name)
		{
			if ((name == null) || (name.Length == 0))
				throw new InvalidNameException();

			_objectName = name;
		}
		#endregion
	}
}
