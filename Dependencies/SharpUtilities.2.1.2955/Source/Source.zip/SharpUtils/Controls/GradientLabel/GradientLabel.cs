#region LGPL.
// 
// SharpUtils.
// Copyright (C) 2007 Michael Winsor
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
// 
// Created: Friday, May 11, 2007 5:27:30 PM
// 
#endregion

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Design;
using System.Data;
using System.Text;
using System.Windows.Forms;
using System.Windows.Forms.Design;

namespace SharpUtilities.Controls
{
	/// <summary>
	/// Object representing a gradient filled control.
	/// </summary>
	[ToolboxItem(true)]
	[ToolboxBitmap(typeof(SURes), "SharpUtilities.Controls.GradientLabel.RoundBox32bpp.bmp")]
	public partial class GradientLabel 
		: Label
	{
		#region Variables.
		private Color _background2 = Color.FromKnownColor(KnownColor.GradientActiveCaption);		// Background color for gradient fill.
		private LinearGradientBrush _backBrush = null;												// Background brush.
		private float _angle;																		// Angle of gradient.
		#endregion

		#region Properties.
		/// <summary>
		/// Property to set or return the second background color.
		/// </summary>
		[Browsable(true), Category("Appearance"), Description("Sets the second color used by the gradient."), DefaultValue(typeof(Color), "GradientActiveCaption"), RefreshProperties(RefreshProperties.Repaint)]
		public Color BackColor2
		{
			get
			{
				return _background2;
			}
			set
			{
				if (value == _background2)
					return;

				_background2 = value;
				Refresh();
			}
		}

		/// <summary>
		/// Property to set or return the gradient angle.
		/// </summary>
		[Browsable(true), Category("Appearance"), Description("Sets the angle (in degrees) used by the gradient."), DefaultValue(0.0f), RefreshProperties(RefreshProperties.Repaint)]
		public float GradientAngle
		{
			get
			{
				return _angle;
			}
			set
			{
				_angle = value;
				Refresh();
			}
		}

		/// <summary>
		/// N/A.
		/// </summary>
		[Browsable(false), EditorBrowsable(EditorBrowsableState.Never)]
		public new bool UseCompatibleTextRendering
		{
			get
			{
				return false;
			}
			set
			{
			}
		}
		#endregion

		#region Methods.
		/// <summary>
		/// Function to update the background brush.
		/// </summary>
		private void UpdateBrush()
		{
			Rectangle rect = Rectangle.Empty;		// Clipping rectangle.

			if (_backBrush != null)
				_backBrush.Dispose();

			rect = ClientRectangle;

			if (rect.Width < 1)
				rect.Width = 1;
			if (rect.Height < 1)
				rect.Height = 1;
			
			_backBrush = new LinearGradientBrush(rect, BackColor, BackColor2, _angle, true);
		}

		/// <summary>
		/// Raises the <see cref="E:Paint"/> event.
		/// </summary>
		/// <param name="e">The <see cref="System.Windows.Forms.PaintEventArgs"/> instance containing the event data.</param>
		protected override void OnPaint(PaintEventArgs e)
		{
			TextFormatFlags flags;								// Text format flags.
			
			base.OnPaint(e);

			UpdateBrush();

			// Align to top & left.
			flags = TextFormatFlags.Left | TextFormatFlags.Top;

			switch (TextAlign)
			{
				case ContentAlignment.MiddleLeft:
					flags = TextFormatFlags.Left | TextFormatFlags.VerticalCenter;
					break;
				case ContentAlignment.MiddleRight:
					flags = TextFormatFlags.Right | TextFormatFlags.VerticalCenter;
					break;
				case ContentAlignment.MiddleCenter:
					flags = TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter;
					break;
				case ContentAlignment.BottomCenter:
					flags = TextFormatFlags.HorizontalCenter | TextFormatFlags.Bottom;
					break;
				case ContentAlignment.BottomLeft:
					flags = TextFormatFlags.Left | TextFormatFlags.Bottom;
					break;
				case ContentAlignment.BottomRight:
					flags = TextFormatFlags.Right | TextFormatFlags.Bottom;
					break;
				case ContentAlignment.TopCenter:
					flags = TextFormatFlags.HorizontalCenter | TextFormatFlags.Top;
					break;
				case ContentAlignment.TopRight:
					flags = TextFormatFlags.Right | TextFormatFlags.Top;
					break;
			}			
			
			// Draw the gradient.
			e.Graphics.FillRectangle(_backBrush, e.ClipRectangle);
			TextRenderer.DrawText(e.Graphics, Text, Font, e.ClipRectangle, ForeColor, flags);
			
			//TextRenderer.DrawText(e.Graphics.
		}
		#endregion

		#region Constructor/Destructor.
		/// <summary>
		/// Constructor.
		/// </summary>
		public GradientLabel()
			: base()
		{
			SetStyle(ControlStyles.SupportsTransparentBackColor, true);
			SetStyle(ControlStyles.ResizeRedraw, true);

			InitializeComponent();
		}
		#endregion
	}
}
