#region LGPL.
// 
// SharpUtils.
// Copyright (C) 2005 Michael Winsor
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
// 
// Created: Sunday, November 20, 2005 4:22:03 PM
// 
// NOTE: Some of this class contains code from Axiom (http://www.axiom3d.org/) and
// Ogre3D (http://www.ogre3d.org).
#endregion


using System;

namespace SharpUtilities.Mathematics
{
	/// <summary>
	/// A value type representing a ray.
	/// </summary>
	/// <remarks>
	/// A ray is straight line extending from a point to an infinite distance.  This is represented
	/// as the equation: Ax + By + Cz + D = 0.
	/// They are often used in 3D mathematics to determine whether intersections exist and
	/// where they exist.
	/// </remarks>
	public struct Ray
	{
		#region Variables.
		// Static vector declarations to minimize object creation.		
		private static readonly Ray _unitZRay = new Ray(Vector3D.Zero, Vector3D.UnitZ);
		private static readonly Ray _unitYRay = new Ray(Vector3D.Zero, Vector3D.UnitY);
		private static readonly Ray _unitXRay = new Ray(Vector3D.Zero, Vector3D.UnitX);

		/// <summary>
		/// Starting point of the ray.
		/// </summary>
		public Vector3D Position;
		/// <summary>
		/// Direction the ray is pointing towards.
		/// </summary>
		public Vector3D Direction;
		#endregion

		#region Properties.
		/// <summary>
		/// Property to return a unit ray that extends from the origin along the X-axis.
		/// </summary>
		public static Ray UnitX
		{
			get
			{
				return _unitXRay;
			}
		}

		/// <summary>
		/// Property to return a unit ray that extends from the origin along the Y-axis.
		/// </summary>
		public static Ray UnitY
		{
			get
			{
				return _unitYRay;
			}
		}

		/// <summary>
		/// Property to return a unit ray that extends from the origin along the Z-axis.
		/// </summary>
		public static Ray UnitZ
		{
			get
			{
				return _unitZRay;
			}
		}
		#endregion

		#region Methods.
		/// <summary>
		/// Function to set the source position of the ray.
		/// </summary>
		/// <param name="x">Horizontal position.</param>
		/// <param name="y">Vertical position.</param>
		/// <param name="z">Depth position.</param>
		public void SetPosition(float x, float y, float z)
		{
			Position.X = x;
			Position.Y = y;
			Position.Z = z;
		}

		/// <summary>
		/// Function to set the direction of the ray.
		/// </summary>
		/// <param name="x">Horizontal direction.</param>
		/// <param name="y">Vertical direction.</param>
		/// <param name="z">Depth direction.</param>
		public void SetDirection(float x, float y, float z)
		{
			Direction.X = x;
			Direction.Y = y;
			Direction.Z = z;
		}

		/// <summary>
		/// Function to return a point at the specified number of units along a ray.
		/// </summary>
		/// <param name="distance">Distance from the origin.</param>
		/// <returns>Point at distance.</returns>
		public Vector3D Point(float distance)
		{
			return Position + (Direction * distance);
		}

		/// <summary>
		/// Function to determine whether this ray intersects with the passed plane.
		/// </summary>
		/// <param name="plane">Plane to test.</param>
		/// <returns>Intersection results.</returns>
		public RayIntersectionQueryResult Intersects(Plane plane)
		{
			return IntersectionQueries.Query(this, plane);
		}

		/// <summary>
		/// Function to determine if this ray will intersect the given AABB.
		/// </summary>
		/// <param name="box">AABB to test.</param>
		/// <returns>Intersection results.</returns>
		public RayIntersectionQueryResult Intersects(AABB box)
		{
			return IntersectionQueries.Query(this,box);
		}

		/// <summary>
		/// Function to determine if this ray will intersect the given sphere volume.
		/// </summary>
		/// <param name="sphere">Sphere volume to test.</param>
		/// <returns>Intersection results.</returns>
		public RayIntersectionQueryResult Intersects(SphereVolume sphere)
		{
			return IntersectionQueries.Query(this, sphere, false);
		}

		/// <summary>
		/// Function to determine if this ray will intersect the given sphere volume.
		/// </summary>
		/// <param name="sphere">Sphere volume to test.</param>
		/// <param name="discardInside">TRUE to discard results inside the sphere, FALSE to include.</param>
		/// <returns>Intersection results.</returns>
		public RayIntersectionQueryResult Intersects(SphereVolume sphere,bool discardInside)
		{
			return IntersectionQueries.Query(this, sphere, discardInside);
		}

		/// <summary>
		/// Function to compare an object with this one for equality.
		/// </summary>
		/// <param name="obj">Object to compare.</param>
		/// <returns>TRUE if equal, FALSE if not.</returns>
		public override bool Equals(object obj)
		{
			if (obj is Ray) 
			{
				if (((Ray)obj) == this)
					return true;
				else
					return false;
			}
			else
				return false;
		}

		/// <summary>
		/// Function to return the hashcode for this object.
		/// </summary>
		/// <returns>Hashcode for this object.</returns>
		public override int GetHashCode()
		{
			return Direction.GetHashCode() ^ Position.GetHashCode();
		}

		/// <summary>
		/// Function to return a string representation of this object.
		/// </summary>
		/// <returns>String containing object information.</returns>
		public override string ToString()
		{
			return string.Format("Ray:\n\tPosition: [{0}]\n\tDirection: [{1}]",Position.ToString(),Direction.ToString());
		}
		#endregion

		#region Operators.
		/// <summary>
		/// Operator to test two rays for equality.
		/// </summary>
		/// <param name="left">Left ray value to compare.</param>
		/// <param name="right">Right ray value to compare.</param>
		/// <returns>TRUE if equal, FALSE if not.</returns>
		public static bool operator ==(Ray left, Ray right)
		{
			if ((left.Position == right.Position) && (left.Direction == right.Direction))
				return true;
			else
				return false;
		}

		/// <summary>
		/// Operator to test two rays for inequality.
		/// </summary>
		/// <param name="left">Left ray value to compare.</param>
		/// <param name="right">Right ray value to compare.</param>
		/// <returns>TRUE if not equal, FALSE if they are.</returns>
		public static bool operator !=(Ray left, Ray right)
		{
			return !(left == right);
		}

		/// <summary>
		/// Operator to return a point at the specified number of units along a ray.
		/// </summary>
		/// <param name="ray">Ray to use.</param>
		/// <param name="distance">Distance from the origin.</param>
		/// <returns>Point at distance.</returns>
		public static Vector3D operator *(Ray ray, float distance)
		{
			return ray.Point(distance);
		}
		#endregion

		#region Constructor.
		/// <summary>
		/// Constructors.
		/// </summary>
		/// <param name="position">Origin of the ray.</param>
		/// <param name="direction">Direction of the ray.</param>
		public Ray(Vector3D position,Vector3D direction)
		{
			Position = position;
			Direction = direction;
		}
		#endregion
	}
}
