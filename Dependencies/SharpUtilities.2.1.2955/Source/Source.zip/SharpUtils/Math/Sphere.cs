#region LGPL.
// 
// SharpUtils.
// Copyright (C) 2005 Michael Winsor
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
// 
// Created: Sunday, November 20, 2005 9:52:14 PM
// 
// NOTE: Some of this class contains code from Axiom (http://www.axiom3d.org/) and
// Ogre3D (http://www.ogre3d.org).
#endregion

using System;

namespace SharpUtilities.Mathematics
{
	/// <summary>
	/// Object representing a sphere volume.
	/// </summary>
	/// <remarks>
	/// This volume is often used to determine occlusion/culling of objects in a 3D
	/// scene.  Combined with intersection queries it can approximately determine if 
	/// a point/volume lies within the volume or not.
	/// </remarks>
	public class SphereVolume
	{	
		#region Variables.
		private float _radius;			// Radius of the sphere.
		private Vector3D _center;		// Center of the sphere.
		#endregion

		#region Properties.
		/// <summary>
		/// Property to return or set the radius of this bounding volume.
		/// </summary>
		public float Radius
		{
			get
			{
				return _radius;
			}
			set
			{
				_radius = value;
			}
		}

		/// <summary>
		/// Property to return or set the center of the bounding volume.
		/// </summary>
		public Vector3D Center
		{
			get
			{
				return _center;
			}
			set
			{
				_center = value;
			}
		}
		#endregion

		#region Methods.
		/// <summary>
		/// Function to set the center of the bounding volume.
		/// </summary>
		/// <param name="x">Horizontal position.</param>
		/// <param name="y">Vertical position.</param>
		/// <param name="z">Depth position.</param>
		public void SetCenter(float x, float y, float z)
		{
			_center.X = x;
			_center.Y = y;
			_center.Z = z;
		}

		/// <summary>
		/// Function to update the dimensions and position of the bounding value.
		/// </summary>
		/// <param name="center">Position of the bounding volume.</param>
		/// <param name="radius">Radius of the sphere.</param>
		public void Update(Vector3D center, float radius)
		{
			_center = center;
			_radius = radius;
		}

		/// <summary>
		/// Function to perform an intersection test with a point.
		/// </summary>
		/// <param name="point">Point to test.</param>
		/// <returns>TRUE if an intersection exists, FALSE if not.</returns>
		public bool Intersects(Vector3D point)
		{
			Vector3D intersectPoint = point - _center;		// Point of intersection.

			if (intersectPoint.Length <= _radius)
				return true;
			else
				return false;
		}

		/// <summary>
		/// Function to perform an intersection test with another sphere volume.
		/// </summary>
		/// <param name="sphere">Sphere volume to test.</param>
		/// <returns>TRUE if an intersection exists, FALSE if not.</returns>
		public bool Intersects(SphereVolume sphere)
		{
			Vector3D intersectPoint = sphere.Center - _center;		// Point of intersection.

			if (intersectPoint.Length <= _radius + sphere.Radius)
				return true;
			else
				return false;
		}

		/// <summary>
		/// Function to determine if this sphere will intersect the given ray.
		/// </summary>
		/// <param name="ray">Ray to test.</param>
		/// <returns>Intersection results.</returns>
		public RayIntersectionQueryResult Intersects(Ray ray)
		{
			return IntersectionQueries.Query(ray, this, false);
		}

		/// <summary>
		/// Function to determine if this sphere will intersect the given ray.
		/// </summary>
		/// <param name="ray">Ray to test.</param>
		/// <param name="discardInside">TRUE to discard results inside the sphere, FALSE to include.</param>
		/// <returns>Intersection results.</returns>
		public RayIntersectionQueryResult Intersects(Ray ray, bool discardInside)
		{
			return IntersectionQueries.Query(ray, this, discardInside);
		}

		/// <summary>
		/// Function to test for an intersection with a plane.
		/// </summary>
		/// <param name="plane">Plane to test.</param>
		/// <returns>TRUE if there was an intersection, FALSE if not.</returns>
		public bool Intersects(Plane plane)
		{
			return IntersectionQueries.Query(this, plane);
		}

		/// <summary>
		/// Function to perform an intersection test on an AABB.
		/// </summary>
		/// <param name="aabb">AABB to test.</param>
		/// <returns>TRUE if an intersection exists, FALSE if not.</returns>
		public bool Intersects(AABB aabb)
		{
			return IntersectionQueries.Query(this, aabb);
		}
		#endregion

		#region Constructor/Destructor.
		/// <summary>
		/// Constructor.
		/// </summary>
		/// <param name="center">Center position of the sphere.</param>
		/// <param name="radius">Radius of the sphere.</param>
		public SphereVolume(Vector3D center, float radius)
		{
			_radius = radius;
			_center = center;
		}

		/// <summary>
		/// Constructor.
		/// </summary>
		public SphereVolume()
		{
			_radius = 1.0f;
			_center = Vector3D.Zero;
		}
		#endregion
	}
}
