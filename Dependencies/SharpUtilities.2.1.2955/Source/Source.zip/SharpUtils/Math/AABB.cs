#region LGPL.
// 
// SharpUtils.
// Copyright (C) 2005 Michael Winsor
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
// 
// Created: Sunday, November 20, 2005 4:20:25 PM
// 
// NOTE: Some of this class contains code from Axiom (http://www.axiom3d.org/) and
// Ogre3D (http://www.ogre3d.org).
#endregion

using System;
using SharpUtilities.Collections;

namespace SharpUtilities.Mathematics
{
	/// <summary>
	/// Object representing an axis aligned bounding box.
	/// </summary>
	/// <remarks>An AABB is a boxed bounding volume.  This volume is often used to determine occlusion/culling of objects in a 3D scene.  Combined with intersection queries it can approximately determine if a point/volume lies within the volume or not.</remarks>
	public class AABB
	{
		#region Variables.
		private Vector3D _minimumExtent;		// Minimum extent of the box.
		private Vector3D _maximumExtent;		// Maximum extent of the box.
		private Vector3D[] _corners;		    // Corners of the box.
		private bool _empty;			        // This box is empty.
		#endregion

		#region Properties.
		/// <summary>
		/// Static read-only property to return an empty box.
		/// </summary>
		/// <remarks>This can be used to create a new bounding box value.</remarks>
		/// <value>Returns a bounding box with default extents and the empty flag set to TRUE.</value>
		/// <example>
		/// [C#] This is an example of how to create a new bounding box with this member:
		/// <code>
		///	public void GetBoundingBox()
		/// {
		///		AABB myBox = AABB.EmptyBox;
		/// }
		/// </code>
		/// </example>
		public static AABB EmptyBox
		{
			get
			{
				return new AABB();
			}
		}

		/// <summary>
		/// Property to return whether the box is empty or not.
		/// </summary>
		/// <remarks>Use this to determine if a bounding box has been assigned or not.  The extents are not adequate to determine this.</remarks>
		/// <value>Set to TRUE if the bounding box is empty, FALSE if it is not.</value>
		public bool Empty
		{
			get
			{
				return _empty;
			}
			set
			{
				_empty = value;
			}
		}

		/// <summary>
		/// Property to set or return the minimum extent of the bounding box.
		/// </summary>
		/// <value>This property uses a <seealso cref="Vector3D">Vector3D</seealso> to represent the extent.</value>
		public Vector3D MinimumExtent
		{
			get
			{
				return _minimumExtent;
			}
			set
			{
				_minimumExtent = value;
				_empty = false;
				UpdateCorners();
			}
		}

		/// <summary>
		/// Property to set or return the maximum extent of the bounding box.
		/// </summary>
		/// <value>This property uses a <seealso cref="Vector3D">Vector3D</seealso> to represent the extent.</value>
		public Vector3D MaximumExtent
		{
			get
			{
				return _maximumExtent;
			}
			set
			{
				_maximumExtent = value;
				_empty = false;
				UpdateCorners();
			}
		}

		/// <summary>
		/// Read only property to return the center of the bounding box.
		/// </summary>
		/// <remarks>This can be used to get an approximate center of an object.</remarks>
		/// <value>Returns a <seealso cref="Vector3D">Vector3D</seealso> value containing the center of the bounding box.</value>
		public Vector3D Center
		{
			get
			{
				return (_minimumExtent + _maximumExtent) * 0.5f;
			}
		}

		/// <summary>
		/// Read-only property to return the corners of the box.
		/// </summary>
		/// <remarks>
		/// The index should be between 0 and 7 (8 corners) or an exception will be thrown.
		/// <para>
		/// The corners are automatically generated when the volume extents change.
		/// </para>
		/// </remarks>
		/// <value>Returns a <seealso cref="Vector3D">Vector3D</seealso> representing the corner of the box.</value>
		/// <exception cref="IndexOutOfBoundsException">Index is not between 0 and 7.</exception>
		public Vector3D this[int index]
		{
			get
			{
				if ((index < 0) || (index > 7))
					throw new ArgumentOutOfRangeException("index", "Corner index [" + index.ToString() + "] is not valid.");

				// Return a copy of the original.
				return _corners[index];
			}
		}
		#endregion

		#region Methods.
		/// <summary>
		/// Function to update the corners of the box.
		/// </summary>
		///	<remarks>
		///		FROM AXIOM:
		///		If the order of these corners is important, they are as
		///		follows: The 4 points of the minimum Z face (note that
		///		because we use right-handed coordinates, the minimum Z is
		///		at the 'back' of the box) starting with the minimum point of
		///		all, then anticlockwise around this face (if you are looking
		///		onto the face from outside the box). Then the 4 points of the
		///		maximum Z face, starting with maximum point of all, then
		///		anticlockwise around this face (looking onto the face from
		///		outside the box). Like this:
		///		<pre>
		///			 1-----2
		///		    /|     /|
		///		  /  |   /  |
		///		5-----4   |
		///		|   0-|--3
		///		|  /   |  /
		///		|/     |/
		///		6-----7
		///		</pre>
		/// </remarks>
		private void UpdateCorners()
		{
			_corners[0] = _minimumExtent;
			_corners[1].X = _minimumExtent.X; _corners[1].Y = _maximumExtent.Y; _corners[1].Z = _minimumExtent.Z;
			_corners[2].X = _maximumExtent.X; _corners[2].Y = _maximumExtent.Y; _corners[2].Z = _minimumExtent.Z;
			_corners[3].X = _maximumExtent.X; _corners[3].Y = _minimumExtent.Y; _corners[3].Z = _minimumExtent.Z;            

			_corners[4] = _maximumExtent;
			_corners[5].X = _minimumExtent.X; _corners[5].Y = _maximumExtent.Y; _corners[5].Z = _maximumExtent.Z;
			_corners[6].X = _minimumExtent.X; _corners[6].Y = _minimumExtent.Y; _corners[6].Z = _maximumExtent.Z;
			_corners[7].X = _maximumExtent.X; _corners[7].Y = _minimumExtent.Y; _corners[7].Z = _maximumExtent.Z;
		}

		/// <summary>
		/// Function to set the minimum extent of the box.
		/// </summary>
		/// <remarks>This function is similar to the <seealso cref="MinimumExtent">MinimumExtent</seealso> property except that it takes explicit coordinates instead of a <see cref="Vector3D">vector</see>.</remarks>
		/// <param name="x">Horizontal position.</param>
		/// <param name="y">Vertical position.</param>
		/// <param name="z">Depth position.</param>
		public void SetMinimumExtent(float x, float y, float z)
		{
			_minimumExtent.X = x;
			_minimumExtent.Y = y;
			_minimumExtent.Z = z;
			_empty = false;
			UpdateCorners();
		}

		/// <summary>
		/// Function to set the maximum extent of the box.
		/// </summary>
		/// <remarks>This function is similar to the <seealso cref="MaximumExtent">MaximumExtent</seealso> property except that it takes explicit coordinates instead of a <see cref="Vector3D">vector</see>.</remarks>
		/// <param name="x">Horizontal position.</param>
		/// <param name="y">Vertical position.</param>
		/// <param name="z">Depth position.</param>
		public void SetMaximumExtent(float x, float y, float z)
		{
			_maximumExtent.X = x;
			_maximumExtent.Y = y;
			_maximumExtent.Z = z;
			_empty = false;
			UpdateCorners();
		}

		/// <summary>
		/// Function to scale the box by a scalar value.
		/// </summary>
		/// <remarks>Use this to shrink or expand the bounding box.</remarks>
		/// <param name="scalar">Scalar value to multiply.</param>
		public void Scale(float scalar)
		{
			if (_empty)
				return;

			Update(_minimumExtent * scalar,_maximumExtent * scalar);
		}

		/// <summary>
		/// Function to merge this box with another.
		/// </summary>
		/// <remarks>
		/// This function combines two AABBs together and updates the extent of the calling AABB.
		/// <para>
		/// The resulting bounding box may be larger than the original, representing the maximum extent between the two boxes.
		/// </para>
		/// </remarks>
		/// <param name="box">Box to merge with.</param>
		public void Merge(AABB box)
		{
			if (box.Empty)
				return;

			// If we're empty, assume the parameter box's dimensions.
			if (_empty)
			{
				Update(box.MinimumExtent,box.MaximumExtent);
				return;
			}

			Vector3D min = _minimumExtent;	
			Vector3D max = _maximumExtent;

			min.Floor(box.MinimumExtent);
			max.Ceiling(box.MaximumExtent);

			Update(min,max);
		}

		/// <summary>
		/// Function to update the bounding box dimensions.
		/// </summary>
		/// <remarks>This function allows for a quick update to the bounding box.</remarks>
		/// <param name="min">Minimum extent of the bounding box.</param>
		/// <param name="max">Maximum extent of the bounding box.</param>
		public void Update(Vector3D min,Vector3D max)
		{
			_minimumExtent = min;
			_maximumExtent = max;
			_empty = false;
			UpdateCorners();
		}

		/// <summary>
		/// Function to transform this bounding box by a <seealso cref="Matrix">matrix</seealso>.
		/// </summary>
		/// <remarks>
		/// Use this to translate/rotate a bounding box.
		/// <para>
		/// Rotating the box will not change its orientation, but merely its size to fix the extents when the objects orientation changes.
		/// </para>
		/// </remarks>
		/// <param name="mat">Matrix used to transform.</param>
		public void Transform(Matrix mat)
		{
			Vector3D min = Vector3D.Zero;		// Minimum value.
			Vector3D max = Vector3D.Zero;		// Maximum value.
			Vector3D temp = Vector3D.Zero;		// Worker value.
			int i;								// Loop.

			// Do nothing if this is an empty box.
			if (_empty)
				return;

			for (i=0;i<8;i++)
			{
				temp = mat.ProjectVector(_corners[i]);
				// Confirm extents.
				if ((i == 0) || (temp.X > max.X))
					max.X = temp.X;
				if ((i == 0) || (temp.Y > max.Y))
					max.Y = temp.Y;
				if ((i == 0) || (temp.Z > max.Z))
					max.Z = temp.Z;
				if ((i == 0) || (temp.X < min.X))
					min.X = temp.X;
				if ((i == 0) || (temp.Y < min.Y))
					min.Y = temp.Y;
				if ((i == 0) || (temp.Z < min.Z))
					min.Z = temp.Z;
			}

			Update(min,max);
		}

		/// <summary>
		/// Function to test for an intersection between a <see cref="Ray">ray</see> and this AABB.
		/// </summary>
		/// <param name="ray">Ray to test.</param>
		/// <returns>A <seealso cref="RayIntersectionQueryResult">RayIntersectionQueryResult</seealso> value containing information about the intersection.</returns>
		public RayIntersectionQueryResult Intersects(Ray ray)
		{
			return IntersectionQueries.Query(ray,this);
		}

		/// <summary>
		/// Function to test for an intersection between a <see cref="Plane">plane</see> and this AABB.
		/// </summary>
		/// <param name="plane">Plane to test.</param>
		/// <returns>A <seealso cref="PlaneIntersectionQueryResult">PlaneIntersectionQueryResult</seealso> value containing information about the intersection.</returns>
		public PlaneIntersectionQueryResult Intersects(Plane plane)
		{
			return IntersectionQueries.Query(plane, this);
		}

		/// <summary>
		/// Function to perform an intersection test on this and another AABB.
		/// </summary>
		/// <param name="aabb">AABB to test.</param>
		/// <returns>TRUE if there is an intersection, FALSE if not.</returns>
		public bool Intersects(AABB aabb)
		{
			if ((Empty) || (aabb.Empty))
				return false;

			// Test extents.
			if (_maximumExtent.X < aabb.MinimumExtent.X)
				return false;
			if (_maximumExtent.Y < aabb.MinimumExtent.Y)
				return false;
			if (_maximumExtent.Z < aabb.MinimumExtent.Z)
				return false;
			if (_minimumExtent.X > aabb.MaximumExtent.X)
				return false;
			if (_minimumExtent.Y > aabb.MaximumExtent.Y)
				return false;
			if (_minimumExtent.Z > aabb.MaximumExtent.Z)
				return false;

			return true;
		}

		/// <summary>
		/// Function to perform an intersection test on this and a bounding <see cref="SphereVolume">sphere</see>.
		/// </summary>
		/// <param name="sphere">Bounding sphere to test.</param>
		/// <returns>TRUE if there is an intersection, FALSE if not.</returns>
		public bool Intersects(SphereVolume sphere)
		{
			return IntersectionQueries.Query(sphere, this);
		}

		/// <summary>
		/// Function to perform an intersection on this and another bounding box.
		/// </summary>
		/// <remarks>
		/// Use this to determine area to of intersection between this and another bounding box.
		/// <para>
		/// Note: this is NOT the same as an <see cref="Intersects(AABB)">intersection test.</see>
		/// 	</para>
		/// </remarks>
		/// <param name="aabb">A bounding box to intersect.</param>
		/// <returns>A new bounding box representing the two intersected boxes.</returns>
		public AABB Intersection(AABB aabb)
		{
			Vector3D newMinimum = Vector3D.Zero;		// New minimum value.
			Vector3D newMaximum = Vector3D.Zero;		// New maximum value.

			if (!Intersects(aabb))
				return new AABB();

			// Combine extents.
			// Maximums.
			if ((aabb.MaximumExtent.X > _maximumExtent.X) && (aabb.MinimumExtent.X < _maximumExtent.X))
				newMaximum.X = _maximumExtent.X;
			else
				newMaximum.X = aabb.MaximumExtent.X;
			if ((aabb.MaximumExtent.Y > _maximumExtent.Y) && (aabb.MinimumExtent.Y < _maximumExtent.Y))
				newMaximum.Y = _maximumExtent.Y;
			else
				newMaximum.Y = aabb.MaximumExtent.Y;
			if ((aabb.MaximumExtent.Z > _maximumExtent.Z) && (aabb.MinimumExtent.Y < _maximumExtent.Z))
				newMaximum.Z = _maximumExtent.Z;
			else
				newMaximum.Z = aabb.MaximumExtent.Z;

			// Minimums.
			if ((aabb.MinimumExtent.X < _minimumExtent.X) && (aabb.MaximumExtent.X > _minimumExtent.X))
				newMinimum.X = _minimumExtent.X;
			else
				newMinimum.X = aabb.MinimumExtent.X;
			if ((aabb.MinimumExtent.Y < _minimumExtent.Y) && (aabb.MaximumExtent.Y > _minimumExtent.Y))
				newMinimum.Y = _minimumExtent.Y;
			else
				newMinimum.Y = aabb.MinimumExtent.Y;
			if ((aabb.MinimumExtent.Z > _minimumExtent.Z) && (aabb.MaximumExtent.Z > _minimumExtent.Z))
				newMinimum.Z = _minimumExtent.Z;
			else
				newMinimum.Z = aabb.MinimumExtent.Z;

			return new AABB(newMinimum, newMaximum);
		}
		#endregion

		#region Constructors.
		/// <summary>
		/// Constructor.
		/// </summary>
		/// <param name="min">Minimum extent of the box.</param>
		/// <param name="max">Maximum extent of the box.</param>
		public AABB(Vector3D min,Vector3D max)
		{
			_corners = new Vector3D[8];
			Update(min,max);
		}
		/// <summary>
		/// Default Constructor.
		/// </summary>
		/// <remarks>
		/// Defaults to a unitized bounding box.
		/// </remarks>
		public AABB()
		{
			_corners = new Vector3D[8];
			Update(new Vector3D(-0.5f,-0.5f,-0.5f),new Vector3D(0.5f,0.5f,0.5f));
			_empty = true;
		}
		#endregion
	}
}
