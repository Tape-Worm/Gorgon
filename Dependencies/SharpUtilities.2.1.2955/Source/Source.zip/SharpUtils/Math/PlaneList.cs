#region LGPL.
// 
// SharpUtils.
// Copyright (C) 2005 Michael Winsor
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
// 
// Created: Sunday, November 20, 2005 10:44:24 PM
// 
#endregion

using System;
using System.Collections;
using System.Collections.Generic;
using SharpUtilities.Collections;

namespace SharpUtilities.Mathematics
{
	/// <summary>
	/// Object to represent a list of planes.
	/// </summary>
	/// <remarks>
	/// There are times when you will need to send a list of planes for intersection 
	/// tests (like when doing a frustrum culling).  This class will help facilitate this.  
	/// </remarks>
	public class PlaneList 
		: DynamicArray<Plane>
	{
		#region Methods.
		/// <summary>
		/// Function to add a plane to the list.
		/// </summary>
		/// <param name="plane">Plane to add.</param>
		public void Add(Plane plane)
		{
			Items.Add(plane);
		}


		/// <summary>
		/// Function to add a plane to the list.
		/// </summary>
		/// <param name="normal">Normal for the plane.</param>
		/// <param name="deltaAngle">Angle distance from normal.</param>
		public void Add(Vector3D normal, float deltaAngle)
		{
			Plane plane = new Plane(normal, deltaAngle);	// New plane.

			Items.Add(plane);
		}

		/// <summary>
		/// Function to add a plane to the list.
		/// </summary>
		/// <param name="point">Point in space for the plane.</param>
		/// <param name="normal">Normal of the plane.</param>
		public void Add(Vector3D point, Vector3D normal)
		{
			Plane plane = new Plane(point, normal);		// New plane.

			Items.Add(plane);
		}

		/// <summary>
		/// Function to add a plane to the list.
		/// </summary>
		/// <param name="point1">Point 1.</param>
		/// <param name="point2">Point 2.</param>
		/// <param name="point3">Point 3.</param>
		public void Add(Vector3D point1, Vector3D point2, Vector3D point3)
		{
			Plane plane = new Plane(point1, point2, point3);	// New plane.

			Items.Add(plane);
		}
		#endregion
	}
}
