#region LGPL.
// 
// SharpUtils.
// Copyright (C) 2005 Michael Winsor
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
// 
// Created: Sunday, November 20, 2005 4:21:47 PM
// 
// NOTE: Some of this class contains code from Axiom (http://www.axiom3d.org/) and
// Ogre3D (http://www.ogre3d.org).
#endregion

using System;

namespace SharpUtilities.Mathematics
{
	/// <summary>
	/// Value type representing a plane.
	/// </summary>
	/// <remarks>
	/// A plane is a 2D rectangle with infinite length in one of the dimensions.
	/// Planes are often used to test for intersections and frustrum culling in 3D math.
	/// </remarks>
	public struct Plane
	{
		#region Variables.
		private static readonly Plane _unitX = new Plane(Vector3D.Zero, Vector3D.UnitX);		// Plane facing X axis.
		private static readonly Plane _unitY = new Plane(Vector3D.Zero, Vector3D.UnitY);		// Plane facing Y axis.
		private static readonly Plane _unitZ = new Plane(Vector3D.Zero, Vector3D.UnitZ);		// Plane facing Z axis.

		/// <summary>
		/// Distance from the origin.
		/// </summary>
		public float D;
		/// <summary>
		/// Normal to the plane.
		/// </summary>
		public Vector3D Normal;
		#endregion

		#region Properties.
		/// <summary>
		/// Property to return a plane with at the origin with its normal pointing along the X axis.
		/// </summary>
		public static Plane UnitX
		{
			get
			{
				return _unitX;
			}
		}

		/// <summary>
		/// Property to return a plane with at the origin with its normal pointing along the Y axis.
		/// </summary>
		public static Plane UnitY
		{
			get
			{
				return _unitY;
			}		
		}

		/// <summary>
		/// Property to return a plane with at the origin with its normal pointing along the Z axis.
		/// </summary>
		public static Plane UnitZ
		{
			get
			{
				return _unitZ;
			}
		}
		#endregion 

		#region Methods.
		/// <summary>
		/// Function to return the distance between a point and the plane.
		/// </summary>
		/// <param name="point1">Point to test.</param>
		/// <returns>Distance between point and plane.</returns>
		public float Distance(Vector3D point1)
		{
			return Normal.DotProduct(point1) + D;
		}

		/// <summary>
		/// Function to set the normal direction.
		/// </summary>
		/// <param name="x">Horizontal direction of the normal.</param>
		/// <param name="y">Vertical direction of the normal.</param>
		/// <param name="z">Depth direction of the normal.</param>
		public void SetNormal(float x, float y, float z)
		{
			Normal.X = x;
			Normal.Y = y;
			Normal.Z = z;
		}

		/// <summary>
		/// Function to set the normal direction.
		/// </summary>
		/// <param name="vector">Vector to set as the normal.</param>
		public void SetNormal(Vector3D vector)
		{
			SetNormal(vector.X, vector.Y, vector.Z);
		}

		/// <summary>
		/// Function to update the dimensions of the plane.
		/// </summary>
		/// <param name="point1">First corner.</param>
		/// <param name="point2">Second corner.</param>
		/// <param name="point3">Third corner..</param>
		public void Update(Vector3D point1, Vector3D point2, Vector3D point3)
		{
			Vector3D edge1 = point2 - point1;		// Edge 1.
			Vector3D edge2 = point3 - point1;		// Edge 2.

			Normal = edge1.CrossProduct(edge2);
			Normal.Normalize();
			D = -Normal.DotProduct(point1);
		}

		/// <summary>
		/// Function to test for an intersection with a ray.
		/// </summary>
		/// <param name="ray">Ray to test.</param>
		/// <returns>Intersection results.</returns>
		public PlaneIntersectionQueryResult Intersects(Ray ray)
		{
			return IntersectionQueries.Query(this,ray);
		}

		/// <summary>
		/// Function to test for an intersection with an AABB.
		/// </summary>
		/// <param name="box">AABB to test.</param>
		/// <returns>Intersection results.</returns>
		public PlaneIntersectionQueryResult Intersects(AABB box)
		{
			return IntersectionQueries.Query(this, box);
		}

		/// <summary>
		/// Function to test for an intersection with a sphere volume.
		/// </summary>
		/// <param name="sphere">Sphere to test.</param>
		/// <returns>TRUE if there was an intersection, FALSE if not.</returns>
		public bool Intersects(SphereVolume sphere)
		{
			return IntersectionQueries.Query(sphere, this);
		}

		/// <summary>
		/// Function to return whether a point is on, behind or in front of the plane.
		/// </summary>
		/// <param name="point">Point to test.</param>
		/// <returns>A value indicating whether the point is on, behind or in front of the plane.</returns>
		public PlaneSide WhereIs(Vector3D point)
		{
			float distance = Distance(point);	// Distance.

			if (distance < 0.0f)
				return PlaneSide.Behind;

			if (distance > 0.0f)
				return PlaneSide.Front;

			return PlaneSide.Planar;
		}

		/// <summary>
		/// Function to check if the object is the same as this plane.
		/// </summary>
		/// <param name="obj">Object to test.</param>
		/// <returns>TRUE if equal, FALSE if not.</returns>
		public override bool Equals(object obj)
		{
			if (obj is Plane)
			{
				if ((Plane)obj == this)
					return true;
				else
					return false;
			}
			else
				return false;
		}

		/// <summary>
		/// Function to return the hashcode for this object.
		/// </summary>
		/// <returns>Hashcode for the object.</returns>
		public override int GetHashCode()
		{
			return D.GetHashCode() ^ Normal.GetHashCode();
		}

		/// <summary>
		/// Function to return a string representation of the plane.
		/// </summary>
		/// <returns>A string representing the plane values.</returns>
		public override string ToString()
		{
			return string.Format("Plane:\n\tNormal: [{0}]\n\tD: {1}",Normal.ToString(),D);	
		}
		#endregion

		#region Operators.
		/// <summary>
		/// Operator to test if the planes are equal.
		/// </summary>
		/// <param name="left">Left plane to compare.</param>
		/// <param name="right">Right plane to compare.</param>
		/// <returns>TRUE if the same, FALSE if not.</returns>
		public static bool operator ==(Plane left,Plane right)
		{
			if ((left.D == right.D) && (left.Normal == right.Normal))
				return true;
			else
				return false;
		}

		/// <summary>
		/// Operator to test if the planes aren't equal.
		/// </summary>
		/// <param name="left">Left plane to compare.</param>
		/// <param name="right">Right plane to compare.</param>
		/// <returns>TRUE if not equal, FALSE if they are.</returns>
		public static bool operator !=(Plane left,Plane right)
		{
			return !(left == right);
		}
		#endregion

		#region Constructors.
		/// <summary>
		/// Constructors.
		/// </summary>
		/// <param name="point">Point in space for the plane.</param>
		/// <param name="normal">Normal of the plane.</param>
		public Plane(Vector3D point,Vector3D normal)
		{
			Normal = normal;
			// Calculate the distance.
			D = -Normal.DotProduct(point);
		}

		/// <summary>
		/// Constructor.
		/// </summary>
		/// <param name="normal">Normal to the plane.</param>
		/// <param name="originDistance">Distance from origin.</param>
		public Plane(Vector3D normal,float originDistance)
		{
			Normal = normal;
			D = originDistance;
		}
		/// <summary>
		/// Constructor.
		/// </summary>
		/// <param name="p1">Point 1.</param>
		/// <param name="p2">Point 2.</param>
		/// <param name="p3">Point 3.</param>
		public Plane(Vector3D p1,Vector3D p2,Vector3D p3)
		{
			D = 0;
			Normal = Vector3D.Zero;

			Update(p1, p2, p3);
		}
		#endregion
	}
}
