#region LGPL.
// 
// SharpUtils.
// Copyright (C) 2005 Michael Winsor
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
// 
// Created: Sunday, November 20, 2005 1:52:54 PM
// 
// NOTE: Some of this class contains code from Axiom (http://www.axiom3d.org/) and
// Ogre3D (http://www.ogre3d.org).
#endregion

using System;
using System.Drawing;

namespace SharpUtilities.Mathematics
{
	/// <summary>
	/// Value type to represent a 2 dimensional vector.
	/// </summary>
	/// <remarks>
	/// Vector mathematics are commonly used in graphical 3D applications.  And other
	/// spatial related computations.
	/// This valuetype provides us a convienient way to use vectors and their operations.
	/// </remarks>
	public struct Vector2D
	{
		#region Variables.
		// Static vector declarations to minimize object creation.
		private readonly static Vector2D _zero = new Vector2D(0,0);
		private readonly static Vector2D _unit = new Vector2D(1.0f,1.0f);
		private readonly static Vector2D _unitX = new Vector2D(1.0f,0);
		private readonly static Vector2D _unitY = new Vector2D(0,1.0f);

		/// <summary>
		/// Horizontal position of the vector.
		/// </summary>
		public float X;
		/// <summary>
		/// Vertical position of the vector.
		/// </summary>
		public float Y;
		#endregion

		#region Properties.
		/// <summary>
		/// Property to return the length of this vector.
		/// </summary>
		public float Length
		{
			get
			{
				return MathUtility.Sqrt(X * X + Y * Y);
			}
		}

		/// <summary>
		/// Property to return the length of this vector squared.
		/// </summary>
		public float LengthSquare
		{
			get
			{
				return X * X + Y * Y;
			}
		}

		/// <summary>
		/// Property to return the inverse length of this vector.
		/// </summary>
		public float InverseLength
		{
			get
			{
				float len = Length;  // Length of vector.

				// If the length is EXACTLY zero, then with zero, however this shouldn't happen.
				if (len == 0.0) 
					return 0;

				return 1.0f/len;
			}
		}

		/// <summary>
		/// Property to return a zeroed vector.
		/// </summary>
		public static Vector2D Zero
		{
			get
			{
				return _zero;
			}
		}

		/// <summary>
		/// Property to return a unit vector (1,1,1).
		/// </summary>
		public static Vector2D Unit
		{
			get
			{
				return _unit;
			}
		}
		
		/// <summary>
		/// Property to return a unit vector for the X axis (1,0,0).
		/// </summary>
		public static Vector2D UnitX
		{
			get
			{
				return _unitX;
			}
		}

		/// <summary>
		/// Property to return a unit vector for the Y axis (0,1,0).
		/// </summary>
		public static Vector2D UnitY
		{
			get
			{
				return _unitY;
			}
		}
		#endregion

		#region Methods.
		/// <summary>
		/// Function to perform a dot product between this and another vector.
		/// </summary>
		/// <param name="vector">Vector to get the dot product against.</param>
		/// <returns>The dot product.</returns>
		public float DotProduct(Vector2D vector)
		{
			double result;		// Resultant.

			result = (X * vector.X) + (Y * vector.Y);

			return (float)result; 
		}

		/// <summary>
		/// Function to normalize the vector.
		/// </summary>
		public void Normalize()
		{
			if (Length > float.Epsilon)
			{
				float invLen = InverseLength;

				X *= invLen;
				Y *= invLen;				
			}
		}

		/// <summary>
		/// Function to perform a cross product between this and another vector.
		/// </summary>
		/// <param name="vector">Vector to perform the cross product with.</param>
		/// <returns>A new vector containing the cross product.</returns>
		public Vector2D CrossProduct(Vector2D vector)
		{
			return new Vector2D(X * vector.Y - Y * vector.X,Y * vector.X - X * vector.Y);
		}

		/// <summary>
		/// Function to compare this vector to another object.
		/// </summary>
		/// <param name="obj">Object to compare.</param>
		/// <returns>TRUE if equal, FALSE if not.</returns>
		public override bool Equals(object obj)
		{
			if (obj is Vector2D)
				return (this == (Vector2D)obj);
			else
				return false;
		}

		/// <summary>
		/// Function to return the hash code for this object.
		/// </summary>
		/// <returns>The hash code for this object.</returns>
		public override int GetHashCode()
		{
			return X.GetHashCode() ^ Y.GetHashCode();
		}

		/// <summary>
		/// Function to return the textual representation of this object.
		/// </summary>
		/// <returns>A string containing the type and values of the object.</returns>
		public override string ToString()
		{
			return string.Format("2D Vector:\n\tX:{0}, Y:{1}",X,Y);
		}
		#endregion

		#region Operators.
		/// <summary>
		/// Function to perform addition upon two vectors.
		/// </summary>
		/// <param name="left">Vector to add to.</param>
		/// <param name="right">Vector to add with.</param>
		/// <returns>A new vector.</returns>
		public static Vector2D Add(Vector2D left,Vector2D right)
		{
			return new Vector2D(left.X + right.X,left.Y + right.Y);
		}

		/// <summary>
		/// Function to perform subtraction upon two vectors.
		/// </summary>
		/// <param name="left">Vector to subtract.</param>
		/// <param name="right">Vector to subtract with.</param>
		/// <returns>A new vector.</returns>
		public static Vector2D Subtract(Vector2D left,Vector2D right)
		{
			return new Vector2D(left.X - right.X,left.Y - right.Y);
		}

		/// <summary>
		/// Function to return a negated vector.
		/// </summary>
		/// <param name="left">Vector to negate.</param>
		/// <returns>A negated vector.</returns>
		public static Vector2D Negate(Vector2D left)
		{
			return new Vector2D(-left.X,-left.Y);
		}

		/// <summary>
		/// Function to divide a vector by a scalar value.
		/// </summary>
		/// <param name="left">Vector to divide.</param>
		/// <param name="scalar">Scalar value to divide by.</param>
		/// <returns>A new vector.</returns>
		public static Vector2D Divide(Vector2D left,float scalar)
		{
			if (scalar == 0.0)
				throw new DivideByZeroException();

			// Do this so we don't have to do multiple divides.
			float inverse = 1.0f / scalar;

			return new Vector2D(left.X * inverse,left.Y * inverse);
		}
		
		/// <summary>
		/// Function to divide a vector by another vector.
		/// </summary>
		/// <param name="left">Vector to divide.</param>
		/// <param name="right">Vector to divide by.</param>
		/// <returns>A new vector.</returns>
		public static Vector2D Divide(Vector2D left,Vector2D right)
		{
			if ((right.X == 0.0) || (right.Y == 0.0))
				throw new DivideByZeroException();

			return new Vector2D(left.X / right.X,left.Y / right.Y);				
		}

		/// <summary>
		/// Function to multiply two vectors together.
		/// </summary>
		/// <param name="left">Vector to multiply.</param>
		/// <param name="right">Vector to multiply by.</param>
		/// <returns>A new vector.</returns>
		public static Vector2D Multiply(Vector2D left,Vector2D right)
		{
			return new Vector2D(left.X * right.X,left.Y * right.Y);
		}

		/// <summary>
		/// Function to multiply a vector by a scalar value.
		/// </summary>
		/// <param name="left">Vector to multiply with.</param>
		/// <param name="scalar">Scalar value to multiply by.</param>
		/// <returns>A new vector.</returns>
		public static Vector2D Multiply(Vector2D left,float scalar)
		{
			return new Vector2D(left.X * scalar,left.Y * scalar);
		}

		/// <summary>
		/// Function to multiply a vector by a scalar value.
		/// </summary>
		/// <param name="scalar">Scalar value to multiply by.</param>
		/// <param name="right">Vector to multiply with.</param>
		/// <returns>A new vector.</returns>
		public static Vector2D Multiply(float scalar,Vector2D right)
		{
			return new Vector2D(right.X * scalar,right.Y * scalar);
		}

		/// <summary>
		/// Operator to perform equality tests.
		/// </summary>
		/// <param name="left">Vector to compare.</param>
		/// <param name="right">Vector to compare with.</param>
		/// <returns>TRUE if equal, FALSE if not.</returns>
		public static bool operator ==(Vector2D left,Vector2D right)
		{
			return ((left.X == right.X) && (left.Y == right.Y));
		}

		/// <summary>
		/// Operator to perform inequality tests.
		/// </summary>
		/// <param name="left">Vector to compare.</param>
		/// <param name="right">Vector to compare with.</param>
		/// <returns>TRUE if not equal, FALSE if they are.</returns>
		public static bool operator !=(Vector2D left,Vector2D right)
		{
			return !(left == right);
		}

		/// <summary>
		/// Operator to perform a test to see if the left is less than the right.
		/// </summary>
		/// <param name="left">Left vector to compare.</param>
		/// <param name="right">Right vector to compare.</param>
		/// <returns>TRUE if left is less than right, FALSE if not.</returns>
		public static bool operator <(Vector2D left,Vector2D right)
		{
			return ((left.X < right.X) && (left.Y < right.Y));
		}

		/// <summary>
		/// Operator to perform a test to see if the left is greater than the right.
		/// </summary>
		/// <param name="left">Left vector to compare.</param>
		/// <param name="right">Right vector to compare.</param>
		/// <returns>TRUE if left is greater than right, FALSE if not.</returns>
		public static bool operator >(Vector2D left,Vector2D right)
		{
			return ((left.X > right.X) && (left.Y > right.Y));
		}

		/// <summary>
		/// Operator to perform a test to see if the left is less or equal to the right.
		/// </summary>
		/// <param name="left">Left vector to compare.</param>
		/// <param name="right">Right vector to compare.</param>
		/// <returns>TRUE if left is less than right, FALSE if not.</returns>
		public static bool operator <=(Vector2D left,Vector2D right)
		{
			return ((left.X <= right.X) && (left.Y <= right.Y));
		}

		/// <summary>
		/// Operator to perform a test to see if the left is greater or equal to the right.
		/// </summary>
		/// <param name="left">Left vector to compare.</param>
		/// <param name="right">Right vector to compare.</param>
		/// <returns>TRUE if left is greater than right, FALSE if not.</returns>
		public static bool operator >=(Vector2D left,Vector2D right)
		{
			return ((left.X >= right.X) && (left.Y >= right.Y));
		}

		/// <summary>
		/// Operator to perform addition upon two vectors.
		/// </summary>
		/// <param name="left">Vector to add to.</param>
		/// <param name="right">Vector to add with.</param>
		/// <returns>A new vector.</returns>
		public static Vector2D operator +(Vector2D left,Vector2D right)
		{
			return Add(left,right);
		}
		
		/// <summary>
		/// Operator to perform subtraction upon two vectors.
		/// </summary>
		/// <param name="left">Vector to subtract.</param>
		/// <param name="right">Vector to subtract with.</param>
		/// <returns>A new vector.</returns>
		public static Vector2D operator -(Vector2D left,Vector2D right)
		{
			return Subtract(left,right);
		}

		/// <summary>
		/// Operator to negate a vector.
		/// </summary>
		/// <param name="left">Vector to negate.</param>
		/// <returns>A negated vector.</returns>
		public static Vector2D operator -(Vector2D left)
		{
			return Negate(left);
		}

		/// <summary>
		/// Operator to multiply two vectors together.
		/// </summary>
		/// <param name="left">Vector to multiply.</param>
		/// <param name="right">Vector to multiply by.</param>
		/// <returns>A new vector.</returns>
		public static Vector2D operator *(Vector2D left,Vector2D right)
		{
			return Multiply(left,right);
		}

		/// <summary>
		/// Operator to multiply a vector by a scalar value.
		/// </summary>
		/// <param name="left">Vector to multiply with.</param>
		/// <param name="scalar">Scalar value to multiply by.</param>
		/// <returns>A new vector.</returns>
		public static Vector2D operator *(Vector2D left,float scalar)
		{
			return Multiply(left,scalar);
		}

		/// <summary>
		/// Operator to multiply a vector by a scalar value.
		/// </summary>
		/// <param name="scalar">Scalar value to multiply by.</param>
		/// <param name="right">Vector to multiply with.</param>
		/// <returns>A new vector.</returns>
		public static Vector2D operator *(float scalar,Vector2D right)
		{
			return Multiply(scalar,right);
		}

		/// <summary>
		/// Operator to divide a vector by a scalar value.
		/// </summary>
		/// <param name="left">Vector to divide.</param>
		/// <param name="scalar">Scalar value to divide by.</param>
		/// <returns>A new vector.</returns>
		public static Vector2D operator /(Vector2D left,float scalar)
		{
			return Divide(left,scalar);
		}		

		/// <summary>
		/// Operator to divide a vector by another vector.
		/// </summary>
		/// <param name="left">Vector to divide.</param>
		/// <param name="right">Vector to divide by.</param>
		/// <returns>A new vector.</returns>
		public static Vector2D operator /(Vector2D left,Vector2D right)
		{
			return Divide(left,right);
		}

		/// <summary>
		/// Operator to convert a 3D vector into a 2D vector.
		/// </summary>
		/// <param name="vector">3D gorgon vector.</param>
		/// <returns>A new 2D vector.</returns>
		public static implicit operator Vector2D(Vector3D vector)
		{
			return new Vector2D(vector.X,vector.Y);
		}

		/// <summary>
		/// Operator to convert a System.Drawing.Point to a 2D vector.
		/// </summary>
		/// <param name="point">System.Drawing.Point to convert.</param>
		/// <returns>A new 2D vector.</returns>
		public static implicit operator Vector2D(Point point)
		{
			return new Vector2D(point);
		}

		/// <summary>
		/// Operator to convert a System.Drawing.PointF to a 2D vector.
		/// </summary>
		/// <param name="point">System.Drawing.PointF to convert.</param>
		/// <returns>A new 2D vector.</returns>
		public static implicit operator Vector2D(PointF point)
		{
			return new Vector2D(point);
		}

		/// <summary>
		/// Operator to convert a System.Drawing.Size to a 2D vector.
		/// </summary>
		/// <param name="point">System.Drawing.Size to convert.</param>
		/// <returns>A new 2D vector.</returns>
		public static implicit operator Vector2D(Size point)
		{
			return new Vector2D(point);
		}

		/// <summary>
		/// Operator to convert a System.Drawing.SizeF to a 2D vector.
		/// </summary>
		/// <param name="point">System.Drawing.SizeF to convert.</param>
		/// <returns>A new 2D vector.</returns>
		public static implicit operator Vector2D(SizeF point)
		{
			return new Vector2D(point);
		}

		/// <summary>
		/// Operator to convert a 2D vector to a System.Drawing.Point.
		/// </summary>
		/// <param name="vector">2D gorgon vector.</param>
		/// <returns>A new point with the values from the vector.</returns>
		public static explicit operator Point(Vector2D vector)
		{
			return new Point((int)vector.X, (int)vector.Y);
		}

		/// <summary>
		/// Operator to convert a 2D vector to a System.Drawing.PointF.
		/// </summary>
		/// <param name="vector">2D gorgon vector.</param>
		/// <returns>A new point with the values from the vector.</returns>
		public static implicit operator PointF(Vector2D vector)
		{
			return new PointF(vector.X, vector.Y);
		}

		/// <summary>
		/// Operator to convert a 2D vector to a System.Drawing.Size.
		/// </summary>
		/// <param name="vector">2D gorgon vector.</param>
		/// <returns>A new point with the values from the vector.</returns>
		public static explicit operator Size(Vector2D vector)
		{
			return new Size((int)vector.X, (int)vector.Y);
		}

		/// <summary>
		/// Operator to convert a 2D vector to a System.Drawing.SizeF.
		/// </summary>
		/// <param name="vector">2D gorgon vector.</param>
		/// <returns>A new point with the values from the vector.</returns>
		public static implicit operator SizeF(Vector2D vector)
		{
			return new SizeF(vector.X, vector.Y);
		}
		#endregion

		#region Constructor.
		/// <summary>
		/// Constructor.
		/// </summary>
		/// <param name="x">Horizontal position of the vector.</param>
		/// <param name="y">Vertical posiition of the vector.</param>
		public Vector2D(float x,float y)
		{
			X = x;
			Y = y;
		}

		/// <summary>
		/// Constructor.
		/// </summary>
		/// <param name="point">System.Drawing.PointF to initialize with.</param>
		public Vector2D(PointF point)
		{
			X = point.X;
			Y = point.Y;
		}

		/// <summary>
		/// Constructor.
		/// </summary>
		/// <param name="point">System.Drawing.Point to initialize with.</param>
		public Vector2D(Point point)
		{
			X = point.X;
			Y = point.Y;
		}

		/// <summary>
		/// Constructor.
		/// </summary>
		/// <param name="size">System.Drawing.Size to initialize with.</param>
		public Vector2D(Size size)
		{
			X = size.Width;
			Y = size.Height;
		}

		/// <summary>
		/// Constructor.
		/// </summary>
		/// <param name="size">System.Drawing.SizeF to initialize with.</param>
		public Vector2D(SizeF size)
		{
			X = size.Width;
			Y = size.Height;
		}
		#endregion
	}
}
