#region LGPL.
// 
// SharpUtils.
// Copyright (C) 2005 Michael Winsor
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
// 
// Created: Thursday, December 01, 2005 9:51:21 PM
// 
#endregion

namespace SharpUtilities.Mathematics
{
	/// <summary>
	/// Enumeration to represent which side a point is on with respect to the plane.
	/// </summary>
	public enum PlaneSide
	{
		/// <summary>No intersection.</summary>
		NoIntersection = 0,
		///<summary>In front of plane.</summary>
		Front = 1,
		///<summary>Behind the plane.</summary>
		Behind = 2,
		///<summary>On the plane.</summary>
		Planar = 3
	}

	/// <summary>
	/// Enumeration for math related error codes.
	/// </summary>
	public enum MathErrorCodes
	{
		/// <summary>
		/// Cannot divide by zero.
		/// </summary>
		DivideByZero = 0x2F000001
	}
}