#region LGPL.
// 
// SharpUtils.
// Copyright (C) 2005 Michael Winsor
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
// 
// Created: Sunday, November 20, 2005 4:56:15 PM
// 
#endregion

using System;

namespace SharpUtilities.Mathematics
{
	/// <summary>
	/// Value type containing the result of the intersection test.
	/// </summary>
	public struct RayIntersectionQueryResult
	{
		#region Variables.
		private bool _hit;				// Flag to indicate that there was an intersection.
		private float _distance;		// Distance along a ray at which the intersection occurs.
		#endregion

		#region Properties.
		/// <summary>
		/// Property to return whether or not there was an intersection.
		/// </summary>
		public bool Intersects
		{
			get
			{
				return _hit;
			}
		}

		/// <summary>
		/// Property to return the distance along a ray at which the intersection occurs.
		/// </summary>
		public float Distance
		{
			get
			{
				return _distance;
			}
		}
		#endregion

		#region Constructor.
		/// <summary>
		/// Constructor.
		/// </summary>
		/// <param name="intersects">TRUE if there's an intersection, FALSE if not.</param>
		/// <param name="distance">Distance along a ray where the intersection occurs.</param>
		public RayIntersectionQueryResult(bool intersects, float distance)
		{
			_hit = intersects;
			_distance = distance;
		}
		#endregion
	}

	/// <summary>
	/// Value type containing the result of the intersection test.
	/// </summary>
	public struct PlaneIntersectionQueryResult
	{
		#region Variables.
		private bool _hit;				// Flag to indicate that there was an intersection.
		private PlaneSide _side;		// Side of plane that intersects.
		#endregion

		#region Properties.
		/// <summary>
		/// Property to return whether or not there was an intersection.
		/// </summary>
		public bool Intersects
		{
			get
			{
				return _hit;
			}
		}

		/// <summary>
		/// Property to return the side of the plane that intersects.
		/// </summary>
		public PlaneSide Side
		{
			get
			{
				return _side;
			}
		}

		#endregion

		#region Constructor.
		/// <summary>
		/// Constructor.
		/// </summary>
		/// <param name="intersects">TRUE if there's an intersection, FALSE if not.</param>
		/// <param name="side">Side of the plane that intersects.</param>
		public PlaneIntersectionQueryResult(bool intersects, PlaneSide side)
		{
			_hit = intersects;
			_side = side;
		}
		#endregion
	}

	/// <summary>
	/// Static class to handle intersection tests.
	/// </summary>
	/// <remarks>
	/// An intersection is a test to determine if a point or volume intersects with 
	/// another point or volume.
	/// Intersections are often used in 3D math to determine occlusion, frustrum culling,
	/// and general collision detection among other things.
	/// </remarks>
	public static class IntersectionQueries
	{
		#region Methods.
		/// <summary>
		/// Function to perform an intersection test between a ray and a plane.
		/// </summary>
		/// <param name="ray">Ray to test.</param>
		/// <param name="plane">Plane to test.</param>
		/// <returns>Result of the intersection query.</returns>
		public static RayIntersectionQueryResult Query(Ray ray, Plane plane)
		{
			float angle;		// Angle between the plane normal and the ray direction.

			// Determine angle between the plane normal and the ray direction.
			angle = plane.Normal.DotProduct(ray.Direction);

			// If very close to 0, then we're parallel.
			if (MathUtility.Abs(angle) < float.Epsilon)
				return new RayIntersectionQueryResult(false, 0);
			else
			{
				float deltaAngle;		// Change in angle from the origin to the plane.
				float distance;			// Distance.

				deltaAngle = plane.Normal.DotProduct(ray.Position) + plane.D;
				distance = -(angle / deltaAngle);

				// If the distance is negative, then there's no intersection.
				return new RayIntersectionQueryResult((distance >= 0) ? true : false, distance);
			}
		}

		/// <summary>
		/// Function to perform an intersection test between a plane and a ray.
		/// </summary>
		/// <param name="plane">Plane to test.</param>
		/// <param name="ray">Ray to test.</param>		
		/// <returns>Result of the intersection query.</returns>
		public static PlaneIntersectionQueryResult Query(Plane plane, Ray ray)
		{
			RayIntersectionQueryResult result = Query(ray, plane);		// Query result.

			return new PlaneIntersectionQueryResult(result.Intersects,plane.WhereIs(ray.Position + ray.Direction * result.Distance));
		}

		/// <summary>
		/// Function to perform an intersection test between a ray and an AABB.
		/// </summary>
		/// <param name="ray">Ray to test.</param>
		/// <param name="aabb">AABB to test.</param>
		/// <returns>Result of the intersection query.</returns>
		public static RayIntersectionQueryResult Query(Ray ray, AABB aabb)
		{
			bool isHit = false;					// Flag to indicate there was an intersection.
			Vector3D hitPoint = Vector3D.Zero;	// Point of intersection.
			float distance = 0;					// Midpoint distance between box corner and ray origin.
			float lowDistance = 0;				// Lowest distance.

			// If the box is empty, then there's no intersection.
			if (aabb.Empty)
				return new RayIntersectionQueryResult(false, 0);

			// Test for inside the box.
			if ((ray.Position > aabb.MinimumExtent) && (ray.Position < aabb.MaximumExtent))
				return new RayIntersectionQueryResult(true, 0);

			// Minimum X.
			if ((ray.Position.X < aabb.MinimumExtent.X) && (ray.Direction.X > 0))
			{
				distance = (aabb.MinimumExtent.X - ray.Position.X) / ray.Direction.X;
				if (distance > 0)
				{
					hitPoint = ray.Position + ray.Direction * distance;
					if ((hitPoint.Y >= aabb.MinimumExtent.Y) && (hitPoint.Y <= aabb.MaximumExtent.Y) &&
						(hitPoint.Z >= aabb.MinimumExtent.Z) && (hitPoint.Z <= aabb.MaximumExtent.Z) &&
							((!isHit) || (distance < lowDistance)))
					{
						isHit = true;
						lowDistance = distance;
					}

				}
			}

			// Maximum X.
			if ((ray.Position.X > aabb.MaximumExtent.X) && (ray.Direction.X < 0))
			{
				distance = (aabb.MaximumExtent.X - ray.Position.X) / ray.Direction.X;
				if (distance > 0)
				{
					hitPoint = ray.Position + ray.Direction * distance;
					if ((hitPoint.Y >= aabb.MinimumExtent.Y) && (hitPoint.Y <= aabb.MaximumExtent.Y) &&
						(hitPoint.Z >= aabb.MinimumExtent.Z) && (hitPoint.Z <= aabb.MaximumExtent.Z) &&
							((!isHit) || (distance < lowDistance)))
					{
						isHit = true;
						lowDistance = distance;
					}

				}
			}

			// Minimum Y.
			if ((ray.Position.Y < aabb.MinimumExtent.Y) && (ray.Direction.Y > 0))
			{
				distance = (aabb.MinimumExtent.Y - ray.Position.Y) / ray.Direction.Y;
				if (distance > 0)
				{
					hitPoint = ray.Position + ray.Direction * distance;
					if ((hitPoint.X >= aabb.MinimumExtent.X) && (hitPoint.Y <= aabb.MaximumExtent.X) &&
						(hitPoint.Z >= aabb.MinimumExtent.Z) && (hitPoint.Z <= aabb.MaximumExtent.Z) &&
							((!isHit) || (distance < lowDistance)))
					{
						isHit = true;
						lowDistance = distance;
					}

				}
			}

			// Maximum Y.
			if ((ray.Position.Y > aabb.MaximumExtent.Y) && (ray.Direction.Y < 0))
			{
				distance = (aabb.MaximumExtent.Y - ray.Position.Y) / ray.Direction.Y;
				if (distance > 0)
				{
					hitPoint = ray.Position + ray.Direction * distance;
					if ((hitPoint.X >= aabb.MinimumExtent.X) && (hitPoint.X <= aabb.MaximumExtent.X) &&
						(hitPoint.Z >= aabb.MinimumExtent.Z) && (hitPoint.Z <= aabb.MaximumExtent.Z) &&
							((!isHit) || (distance < lowDistance)))
					{
						isHit = true;
						lowDistance = distance;
					}

				}
			}

			// Minimum Z.
			if ((ray.Position.Z < aabb.MinimumExtent.Z) && (ray.Direction.Z > 0))
			{
				distance = (aabb.MinimumExtent.Z - ray.Position.Z) / ray.Direction.Z;
				if (distance > 0)
				{
					hitPoint = ray.Position + ray.Direction * distance;
					if ((hitPoint.X >= aabb.MinimumExtent.X) && (hitPoint.Z <= aabb.MaximumExtent.X) &&
						(hitPoint.Y >= aabb.MinimumExtent.Y) && (hitPoint.Z <= aabb.MaximumExtent.Y) &&
							((!isHit) || (distance < lowDistance)))
					{
						isHit = true;
						lowDistance = distance;
					}

				}
			}

			// Maximum Z.
			if ((ray.Position.Z > aabb.MaximumExtent.Z) && (ray.Direction.Z < 0))
			{
				distance = (aabb.MaximumExtent.Z - ray.Position.Z) / ray.Direction.Z;
				if (distance > 0)
				{
					hitPoint = ray.Position + ray.Direction * distance;
					if ((hitPoint.X >= aabb.MinimumExtent.X) && (hitPoint.X <= aabb.MaximumExtent.X) &&
						(hitPoint.Y >= aabb.MinimumExtent.Y) && (hitPoint.Z <= aabb.MaximumExtent.Y) &&
							((!isHit) || (distance < lowDistance)))
					{
						isHit = true;
						lowDistance = distance;
					}
				}
			}

			return new RayIntersectionQueryResult(isHit, lowDistance);
		}

		/// <summary>
		/// Function to perform an intersection test on a plane and an AABB.
		/// </summary>
		/// <param name="plane">Plane to test.</param>
		/// <param name="aabb">AABB to test.</param>
		/// <returns>Intersection result.</returns>
		public static PlaneIntersectionQueryResult Query(Plane plane, AABB aabb)
		{
			PlaneSide previousSide = PlaneSide.NoIntersection;		// Previous side.

			if (aabb.Empty)
				return new PlaneIntersectionQueryResult(false, PlaneSide.NoIntersection);

			// Get previous side.
			previousSide = plane.WhereIs(aabb[0]);

			// Find intersection.
			for (int i = 0; i < 8; i++)
			{
				if (previousSide != plane.WhereIs(aabb[i]))
					return new PlaneIntersectionQueryResult(true, previousSide);
			}

			return new PlaneIntersectionQueryResult(true, PlaneSide.NoIntersection);
		}

		/// <summary>
		/// Function to perform an intersection test on a ray and a sphere volume.
		/// </summary>
		/// <param name="ray">Ray to test.</param>
		/// <param name="sphere">Sphere to test.</param>
		/// <param name="discardInside">TRUE to discard results from inside the sphere, FALSE to include.</param>
		/// <returns>Intersection result.</returns>
		public static RayIntersectionQueryResult Query(Ray ray, SphereVolume sphere, bool discardInside)
		{
			Vector3D origin = ray.Position - sphere.Center;							// Origin point.
			float a = ray.Direction.DotProduct(ray.Direction);						// Coefficient A.
			float b = 2 * origin.DotProduct(ray.Direction);							// Coefficient B.
			float c = origin.DotProduct(origin) - sphere.Radius * sphere.Radius;	// Coefficient C.
			float d = (b * b) - (4 * a * c);										// Determinant.
			float distance = 0;														// Distance.

			if ((origin.LengthSquare <= sphere.Radius * sphere.Radius) && (discardInside))
				return new RayIntersectionQueryResult(true, 0);

			if (d < 0)
				return new RayIntersectionQueryResult(false, 0);
			else
			{
				distance = (-b - MathUtility.Sqrt(d)) / (2.0f * a);
				if (distance < 0)
					distance = (-b + MathUtility.Sqrt(d)) / (2.0f * a);

				return new RayIntersectionQueryResult(true, distance);
			}			
		}

		/// <summary>
		/// Function to perform an intersection test on a sphere and an AABB.
		/// </summary>
		/// <param name="sphere">Sphere to test.</param>
		/// <param name="box">AABB to test.</param>
		/// <returns>TRUE if an intersection exists, FALSE if not.</returns>
		public static bool Query(SphereVolume sphere, AABB box)
		{
			if (box.Empty)
				return false;

			// Test minimums.
			if ((sphere.Center.X < box.MinimumExtent.X) && (box.MinimumExtent.X - sphere.Center.X > sphere.Radius))
				return false;

			if ((sphere.Center.Y < box.MinimumExtent.Y) && (box.MinimumExtent.Y - sphere.Center.Y > sphere.Radius))
				return false;

			if ((sphere.Center.Z < box.MinimumExtent.Z) && (box.MinimumExtent.Z - sphere.Center.Z > sphere.Radius))
				return false;

			// Test maximums.
			if ((sphere.Center.X > box.MaximumExtent.X) && (sphere.Center.X - box.MaximumExtent.X > sphere.Radius))
				return false;

			if ((sphere.Center.Y > box.MaximumExtent.Y) && (sphere.Center.Y - box.MaximumExtent.Y > sphere.Radius))
				return false;

			if ((sphere.Center.Z > box.MaximumExtent.Z) && (sphere.Center.Z - box.MaximumExtent.Z > sphere.Radius))
				return false;

			return true;
		}

		/// <summary>
		/// Function to perform an intersection test on a sphere and a plane.
		/// </summary>
		/// <param name="sphere">Sphere to test.</param>
		/// <param name="plane">Plane to test.</param>
		/// <returns>TRUE if an intersection exists, FALSE if not.</returns>
		public static bool Query(SphereVolume sphere, Plane plane)
		{
			return (MathUtility.Abs(plane.Normal.DotProduct(sphere.Center)) <= 0) ? true : false;
		}

		/// <summary>
		/// Function to perform an intersection test on a ray and a list of planes.
		/// </summary>
		/// <param name="ray">Ray to test.</param>
		/// <param name="planes">Planes to test.</param>
		/// <param name="invertNormals">TRUE to use inverse normals, FALSE to use regular.</param>
		/// <returns>Intersection results.</returns>
		public static RayIntersectionQueryResult Query(Ray ray, PlaneList planes, bool invertNormals)
		{
			bool allInside = true;					// All rays are inside.
			RayIntersectionQueryResult result;		// Result.
			RayIntersectionQueryResult testResult;	// Testing result.
			PlaneSide side;							// Side of plane intersection is on.

			// Default to failure.
			result = new RayIntersectionQueryResult(false, 0);

			side = invertNormals ? PlaneSide.Behind : PlaneSide.Front;

			// Go through plane list.
			foreach (Plane plane in planes)
			{
				if (plane.WhereIs(ray.Position) == side)
				{
					allInside = false;
					testResult = ray.Intersects(plane);
					if (testResult.Intersects)
						result = new RayIntersectionQueryResult(true,MathUtility.Max(result.Distance, testResult.Distance));
				}
			}

			// If it's all inside the volume, then there's no distance.
			if (allInside)
				result = new RayIntersectionQueryResult(true, 0);

			return result;
		}
		#endregion
	}
}
