//
// SharpUtils.
// Copyright (C) 2005 Michael Winsor
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
// Lesser General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
//
// Created: Thursday, March 24, 2005 10:01:33 AM
//

using System;
using System.Runtime.InteropServices;

namespace SharpUtilities.Native
{
	/// <summary>
	/// Memory -
	///		Class for 'unsafe' memory management.
	/// </summary>
	public static class Memory
	{
		/// <summary>
		/// Function to return the unsafe address of the passed array.
		/// </summary>
		/// <param name="data">Array to get the address of.</param>
		/// <returns>Address pointing to the array.</returns>
		public static IntPtr AddressOfArray(Array data)
		{
			return AddressOfArray(data,0);
		}

		/// <summary>
		/// Function to return the unsafe address of the passed array.
		/// </summary>
		/// <param name="data">Array to get the address of.</param>
		/// <param name="index">Index in the array to start at.</param>
		/// <returns>Address pointing to the array.</returns>
		public static IntPtr AddressOfArray(Array data,int index)
		{
			return Marshal.UnsafeAddrOfPinnedArrayElement(data,index);
		}

		/// <summary>
		/// Function to fill a memory block with a specified unsigned byte value.
		/// </summary>
		/// <param name="data">Pointer to overwrite.</param>
		/// <param name="datavalue">Value to place in the memory block.</param>
		/// <param name="offset">Offset to start writing at.</param>
		public static void WriteByte(IntPtr data,byte datavalue,int offset)
		{
			unsafe
			{
				byte *bytePtr;	// Pointer to the memory block.

				bytePtr = (byte *)data.ToPointer();
				bytePtr += offset;
				*bytePtr = datavalue;			
			}
		}

		/// <summary>
		/// Function to fill a memory block with a specified unsigned integer value.
		/// </summary>
		/// <param name="data">Pointer to overwrite.</param>
		/// <param name="datavalue">Value to place in the memory block.</param>
		/// <param name="offset">Offset to start writing at.</param>
		public static void WriteUInt(IntPtr data,uint datavalue,int offset)
		{
			unsafe
			{
				uint *uintPtr;	// Pointer to the memory block.

				uintPtr = (uint *)data.ToPointer();
				uintPtr += offset;
				*uintPtr = datavalue;
				
			}
		}

		/// <summary>
		/// Function to fill a memory block with a specified signed integer value.
		/// </summary>
		/// <param name="data">Pointer to overwrite.</param>
		/// <param name="datavalue">Value to place in the memory block.</param>
		/// <param name="offset">Offset to start writing at.</param>
		public static void WriteInt(IntPtr data,int datavalue,int offset)
		{
			unsafe
			{
				int *intPtr;	// Pointer to the memory block.

				intPtr = (int *)data.ToPointer();
				intPtr += offset;

				*intPtr = datavalue;				
			}
		}

		/// <summary>
		/// Function to fill a memory block with a specified signed short value.
		/// </summary>
		/// <param name="data">Pointer to overwrite.</param>
		/// <param name="datavalue">Value to place in the memory block.</param>
		/// <param name="offset">Offset to start writing at.</param>
		public static void WriteShort(IntPtr data,short datavalue,int offset)
		{
			unsafe
			{
				short *intPtr;	// Pointer to the memory block.

				intPtr = (short *)data.ToPointer();
				intPtr += offset;

				*intPtr = datavalue;
			}
		}

		/// <summary>
		/// Function to fill a memory block with a specified unsigned short value.
		/// </summary>
		/// <param name="data">Pointer to overwrite.</param>
		/// <param name="datavalue">Value to place in the memory block.</param>
		/// <param name="offset">Offset to start writing at.</param>
		public static void WriteUShort(IntPtr data,ushort datavalue,int offset)
		{
			unsafe
			{
				ushort *intPtr;	// Pointer to the memory block.

				intPtr = (ushort *)data.ToPointer();
				intPtr += offset;

				*intPtr = datavalue;
			}
		}

		/// <summary>
		/// Function to fill a memory block with a specified signed floating point value.
		/// </summary>
		/// <param name="data">Pointer to overwrite.</param>
		/// <param name="datavalue">Value to place in the memory block.</param>
		/// <param name="offset">Offset to start writing at.</param>
		public static void WriteFloat(IntPtr data,float datavalue,int offset)
		{
			unsafe
			{
				float *intPtr;	// Pointer to the memory block.

				intPtr = (float *)data.ToPointer();
				intPtr += offset;

				*intPtr = datavalue;
			}
		}

		/// <summary>
		/// Function to read an unsigned byte from a memory block.
		/// </summary>
		/// <param name="data">Pointer to read from.</param>
		/// <param name="offset">Offset to start reading at.</param>
		/// <returns>An unsigned byte.</returns>
		public static byte ReadByte(IntPtr data,int offset)
		{
			unsafe
			{
				byte *bytePtr;	// Pointer to the memory block.

				bytePtr = (byte *)data.ToPointer();
				bytePtr += offset;
				return *bytePtr;				
			}
		}

		/// <summary>
		/// Function to read an unsigned integer from a memory block.
		/// </summary>
		/// <param name="data">Pointer to read from.</param>
		/// <param name="offset">Offset to start reading at.</param>
		/// <returns>An unsigned integer.</returns>
		public static uint ReadUInt(IntPtr data,int offset)
		{
			unsafe
			{
				uint *uintPtr;	// Pointer to the memory block.

				uintPtr = (uint *)data.ToPointer();
				uintPtr += offset;
				return *uintPtr;				
			}
		}

		/// <summary>
		/// Function to read a signed integer from a memory block.
		/// </summary>
		/// <param name="data">Pointer to read from.</param>
		/// <param name="offset">Offset to start reading at.</param>
		/// <returns>A signed integer.</returns>
		public static int ReadInt(IntPtr data,int offset)
		{
			unsafe
			{
				int *intPtr;	// Pointer to the memory block.

				intPtr = (int *)data.ToPointer();
				intPtr += offset;
				return *intPtr;				
			}
		}

		/// <summary>
		/// Function to read a signed short from a memory block.
		/// </summary>
		/// <param name="data">Pointer to read from.</param>
		/// <param name="offset">Offset to start reading at.</param>
		/// <returns>A signed short.</returns>
		public static short ReadShort(IntPtr data,int offset)
		{
			unsafe
			{
				short *shortPtr;	// Pointer to the memory block.

				shortPtr = (short *)data.ToPointer();
				shortPtr += offset;
				return *shortPtr;				
			}
		}

		/// <summary>
		/// Function to read an unsigned short from a memory block.
		/// </summary>
		/// <param name="data">Pointer to read from.</param>
		/// <param name="offset">Offset to start reading at.</param>
		/// <returns>An unsigned short.</returns>
		public static ushort ReadUShort(IntPtr data,int offset)
		{
			unsafe
			{
				ushort *ushortPtr;	// Pointer to the memory block.

				ushortPtr = (ushort *)data.ToPointer();
				ushortPtr += offset;
				return *ushortPtr;				
			}
		}

		/// <summary>
		/// Function to read a floating point value from a memory block.
		/// </summary>
		/// <param name="data">Pointer to read from.</param>
		/// <param name="offset">Offset to start reading at.</param>
		/// <returns>A floating point value.</returns>
		public static float ReadFloat(IntPtr data,int offset)
		{
			unsafe
			{
				float *floatPtr;	// Pointer to the memory block.

				floatPtr = (float *)data.ToPointer();
				floatPtr += offset;
				return *floatPtr;				
			}
		}

		/// <summary>
		/// Function to fill a memory block with zeroes.
		/// </summary>
		/// <param name="data">Pointer to overwrite.</param>
		/// <param name="length">Number of bytes to write.</param>
		public static void Zero(IntPtr data,int length)
		{
			Zero(data,0,length);
		}

		/// <summary>
		/// Function to fill a memory block with zeroes.
		/// </summary>
		/// <param name="data">Pointer to overwrite.</param>
		/// <param name="offset">Offset to start writing at.</param>
		/// <param name="length">Number of bytes to write.</param>
		public static void Zero(IntPtr data,int offset,int length)
		{
			Memset(data,0,offset,length);
		}

		/// <summary>
		/// Function to fill a memory block with a byte value.
		/// </summary>
		/// <param name="data">Pointer to overwrite.</param>
		/// <param name="datavalue">Value to write.</param>
		/// <param name="length">Number of bytes to write.</param>
		public static void Memset(IntPtr data,byte datavalue,int length)
		{
			for (int i=0;i<length;i++)
				WriteByte(data,datavalue,i);
		}

		/// <summary>
		/// Function to fill a memory block with a byte value.
		/// </summary>
		/// <param name="data">Pointer to overwrite.</param>
		/// <param name="datavalue">Value to write.</param>
		/// <param name="offset">Offset to start writing at.</param>
		/// <param name="length">Number of bytes to write.</param>
		public static void Memset(IntPtr data,byte datavalue,int offset,int length)
		{
			for (int i=0;i<length;i++)
				WriteByte(data,datavalue,i+offset);
		}
		/// <summary>
		/// Function to copy data from one memory block to another.
		/// </summary>
		/// <param name="sourcePointer">Pointer to copy from.</param>
		/// <param name="destinationPointer">Pointer to copy into.</param>
		/// <param name="length">Number of bytes to copy.</param>
		public static void Copy(IntPtr sourcePointer,IntPtr destinationPointer,int length)
		{
			Copy(sourcePointer,destinationPointer,0,0,length);
		}

		/// <summary>
		/// Function to copy an array into a memory pointer.
		/// </summary>
		/// <param name="sourceArray">Array to copy from.</param>
		/// <param name="destinationPointer">Pointer to copy into.</param>
		/// <param name="length">Length of data to write in bytes.</param>
		public static void Copy(Array sourceArray,IntPtr destinationPointer,int length)
		{
            GCHandle handle = GCHandle.Alloc(sourceArray, GCHandleType.Pinned);
            IntPtr arrayPtr = AddressOfArray(sourceArray, 0);
			Copy(arrayPtr,destinationPointer,length);
            handle.Free();
		}

		/// <summary>
		/// Function to copy an array into a memory pointer.
		/// </summary>
		/// <param name="sourceArray">Array to copy from.</param>
		/// <param name="destinationPointer">Pointer to copy into.</param>
		/// <param name="index">Index of the array to start at.</param>
		/// <param name="length">Length of data to write in bytes.</param>
		public static void Copy(Array sourceArray,IntPtr destinationPointer,int index,int length)
		{
            GCHandle handle = GCHandle.Alloc(sourceArray, GCHandleType.Pinned);
			IntPtr arrayPtr = AddressOfArray(sourceArray,index);
			Copy(arrayPtr,destinationPointer,length);
            handle.Free();
		}

		/// <summary>
		/// Function to copy an array into a memory pointer.
		/// </summary>
		/// <param name="sourceArray">Array to copy from.</param>
		/// <param name="destinationPointer">Pointer to copy into.</param>
		/// <param name="sourceIndex">Index of the array to start at.</param>
		/// <param name="destinationOffset">Offset in destination buffer to write at.</param>
		/// <param name="length">Number of bytes to write.</param>
		public static void Copy(Array sourceArray,IntPtr destinationPointer,int sourceIndex,int destinationOffset,int length)
		{
            GCHandle handle = GCHandle.Alloc(sourceArray, GCHandleType.Pinned);
			IntPtr arrayPtr = AddressOfArray(sourceArray,sourceIndex);
			Copy(arrayPtr,destinationPointer,0,destinationOffset,sourceArray.Length);
            handle.Free();
		}


		/// <summary>
		/// Function to copy data from one memory block to another.
		/// </summary>
		/// <param name="sourcePointer">Pointer to copy from.</param>
		/// <param name="destinationPointer">Pointer to copy into.</param>
		/// <param name="sourceOffset">Position to start copying from.</param>
		/// <param name="destinationOffset">Position in destination.</param>
		/// <param name="length">Number of bytes to copy.</param>
		public static void Copy(IntPtr sourcePointer,IntPtr destinationPointer,int sourceOffset,int destinationOffset,int length)
		{
			unsafe
			{
				int i;													// Loop.
				byte *ptrSrc = (byte *)sourcePointer.ToPointer();		// Pointer to the source buffer.
				byte *ptrDest = (byte *)destinationPointer.ToPointer(); // Pointer to the destination buffer.

				for (i=0;i<length;i++)
					ptrDest[i + destinationOffset] = ptrSrc[i + sourceOffset];
			}
		}
	}
}
