#region LGPL.
// 
// SharpUtils.
// Copyright (C) 2005 Michael Winsor
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
// 
// Created: Tuesday, May 17, 2005 2:05:17 PM
// 
#endregion


using System;
using System.Drawing;
using System.Windows.Forms;
using System.Text;
using System.Runtime.InteropServices;

namespace SharpUtilities.Native.Win32
{
	#region Delegates.
	/// <summary>
	/// Callback function for the font family enumeration method.
	/// </summary>
	/// <param name="lpelfe">Info about the logical attributes of the font.</param>
	/// <param name="lpntme">Info about the physical attributes of the font.</param>
	/// <param name="FontType">Type of font being enumerated.</param>
	/// <param name="lParam">User specified parameter.</param>
	/// <returns></returns>
	public delegate int FONTENUMPROC(ref ENUMLOGFONTEX lpelfe, ref NEWTEXTMETRICEX lpntme, FontTypes FontType, IntPtr lParam);
	#endregion

	/// <summary>
	/// Static class for Native Win32 methods and corresponding structures.
	/// </summary>
	/// <remarks>
	/// This is a grouping of any API calls regularly used by SharpUtilities or its dependant applications.
	/// <para>
    /// This list is by no means complete.  The Win32 API is just massive and would probably take a lifetime to map.
	/// </para>
	/// 	<para>
	/// These calls are considered "unsafe" and thus should be used with care.  If you don't know how to use a function, or why you want it, you probably don't need to use them.
	/// </para>
	/// 	<para>
	/// Please note that a lot of the enumerators/structures have slightly different names than their Win32 counterparts.  This was done for the sake of readability.  This does NOT affect their results or their effect on the results of their related functionality.
	/// </para>
	/// </remarks>
	public static class Win32API
	{
		#region Constants.
		/// <summary>Maximum number of characters that can fit into a path.</summary>
        public const uint MAX_PATH = 260;
		/// <summary>Joystick is unplugged.</summary>
		public const int JOYERR_UNPLUGGED = 167;
		/// <summary>Joystick is already captured or timer is unavailable.</summary>
		public const int JOYERR_NOCANDO = 166;
		#endregion

		#region Methods.
		/// <summary>
		/// Function to enumerate font families.
		/// </summary>
		/// <param name="hDC">Device context.</param>
		/// <param name="lpLogFont">LOGFONT structure that contains information about the fonts to enumerate.</param>
		/// <param name="lpEnumFontProc">Callback for the enumerator.</param>
		/// <param name="lParam">Parameter to pass to the callback.</param>
		/// <param name="dw">Reserved.</param>
		/// <returns>The return value is the last value returned by the callback function. This value depends on which font families are available for the specified device.</returns>
		[DllImport("gdi32", CharSet = CharSet.Auto, CallingConvention = CallingConvention.StdCall)]
		public static extern int EnumFontFamiliesEx(IntPtr hDC, [In] ref LOGFONT lpLogFont, FONTENUMPROC lpEnumFontProc, IntPtr lParam, uint dw);

		/// <summary>
		/// Function to return the state of a specified key.
		/// </summary>
		/// <param name="nVirtKey">Key state to retrieve.</param>
		/// <returns>A bitmap containing state information about they key.</returns>
		[DllImport("user32.dll")]
		public extern static short GetKeyState(Keys nVirtKey);

		/// <summary>
		/// Function to extract an icon from a file.
		/// </summary>
		/// <param name="lpszFile">File containing the icon.</param>
		/// <param name="nIconIndex">Index of the icon.</param>
		/// <param name="phIconLarge">List of 32x32 icons.</param>
		/// <param name="phIconSmall">List of 16x16 icons.</param>
		/// <param name="nIcons">Number of icons.</param>
		/// <returns>If the nIconIndex parameter is -1, the phiconLarge parameter is NULL, and the phiconSmall parameter is NULL, then the return value is the number of icons contained in the specified file. Otherwise, the return value is the number of icons successfully extracted from the file.</returns>
		[DllImport("Shell32", CharSet = CharSet.Auto)]
		public extern static int ExtractIconEx([MarshalAs(UnmanagedType.LPTStr)] string lpszFile, int nIconIndex, IntPtr[] phIconLarge, IntPtr[] phIconSmall, int nIcons);

		/// <summary>
		/// Function to get file information from the shell.
		/// </summary>
		/// <param name="pszPath">Path to the file.</param>
		/// <param name="dwFileAttributes">File attributes.</param>
		/// <param name="psfi">GetFileInfo data.</param>
		/// <param name="cbSizeFileInfo">Size of structure.</param>
		/// <param name="uFlags">Flags to use.</param>
		/// <returns>Returns a value whose meaning depends on the uFlags parameter. If uFlags does not contain SHGFI_EXETYPE or SHGFI_SYSICONINDEX, the return value is nonzero if successful, or zero otherwise.  If uFlags contains the SHGFI_EXETYPE flag, the return value specifies the type of the executable file</returns>
		[DllImport("shell32.dll")]
		public static extern IntPtr SHGetFileInfo(string pszPath, uint dwFileAttributes, ref SHFILEINFO psfi, uint cbSizeFileInfo, uint uFlags);

		/// <summary>
		/// Function to destroy an unmanaged icon resource.
		/// </summary>
		/// <param name="handle">Handle to the icon.</param>
		/// <returns>Non zero if successful, 0 if not.</returns>
		[DllImport("user32.dll", CharSet = CharSet.Auto)]
		public static extern bool DestroyIcon(IntPtr handle);

		/// <summary>
		/// Function to capture a joystick.
		/// </summary>
		/// <param name="hwnd">Window handle to bind joystick with.</param>
		/// <param name="uJoyID">ID the joystick to release.</param>
		/// <param name="uPeriod">Polling frequency in milliseconds.</param>
		/// <param name="fChanged">TRUE to send messages only if the position changes outside of the dead zone, FALSE to always send messages.</param>
		/// <returns>0 if successful, non-zero if not.</returns>
		[DllImport("WinMM.dll")]
		public static extern int joySetCapture(IntPtr hwnd, int uJoyID, int uPeriod, bool fChanged);

		/// <summary>
		/// Function to release the capture of a joystick.
		/// </summary>
		/// <param name="uJoyID">ID the joystick to release.</param>
		/// <returns>0 if successful, non-zero if not.</returns>
		[DllImport("WinMM.dll")]
		public static extern int joyReleaseCapture(int uJoyID);

		/// <summary>
		/// Function to set the dead zone of the joystick.
		/// </summary>
		/// <param name="uJoyID">ID the joystick to query.</param>
		/// <param name="uThreshold">Threshold for the joystick.</param>
		/// <returns>0 if successful, non-zero if not.</returns>
		[DllImport("WinMM.dll")]
		public static extern int joySetThreshold(int uJoyID, int uThreshold);

		/// <summary>
		/// Function to retrieve the dead zone of the joystick.
		/// </summary>
		/// <param name="uJoyID">ID the joystick to query.</param>
		/// <param name="puThreshold">Threshold for the joystick.</param>
		/// <returns>0 if successful, non-zero if not.</returns>
		[DllImport("WinMM.dll")]
		public static extern int joyGetThreshold(int uJoyID, out int puThreshold);

		/// <summary>
		/// Function to notify the system that joystick properties have changed.
		/// </summary>
		/// <param name="reserved">Reserved, do not use.</param>
		/// <returns>0 if successful, non-zero if not.</returns>
		[DllImport("WinMM.dll")]
		public static extern int joyConfigChanged(int reserved);

		/// <summary>
		/// Function to return the number of joystick devices supported by the current driver.
		/// </summary>
		/// <returns>Number of joysticks supported, 0 if no driver is installed.</returns>
		[DllImport("WinMM.dll")]
		public static extern int joyGetNumDevs();

		/// <summary>
		/// Function to return the joystick device capabilities.
		/// </summary>
		/// <param name="uJoyID">ID of the joystick to return.  -1 will return registry key, whether a device exists or not.</param>
		/// <param name="pjc">Joystick capabilities.</param>
		/// <param name="cbjc">Size of the JOYCAPS structure in bytes.</param>
		/// <returns>0 if successful, non zero if not.</returns>
		[DllImport("WinMM.dll", CharSet=CharSet.Ansi)]
		public static extern int joyGetDevCaps(int uJoyID, ref JOYCAPS pjc, int cbjc);

		/// <summary>
		/// Function to retrieve joystick position information.
		/// </summary>
		/// <param name="uJoyID">ID the of joystick to query.</param>
		/// <param name="pji">Position information.</param>
		/// <returns>0 if successful, non zero if not.  JOYERR_UNPLUGGED if not connected.</returns>
		[DllImport("WinMM.dll", CharSet=CharSet.Ansi)]
		public static extern int joyGetPos(int uJoyID, ref JOYINFO pji);

		/// <summary>
		/// Function to retrieve joystick position information.
		/// </summary>
		/// <param name="uJoyID">ID the of joystick to query.</param>
		/// <param name="pji">Position information.</param>
		/// <returns>0 if successful, non zero if not.  JOYERR_UNPLUGGED if not connected.</returns>
		[DllImport("WinMM.dll", CharSet = CharSet.Ansi)]
		public static extern int joyGetPosEx(int uJoyID, ref JOYINFOEX pji);

		/// <summary>
		/// Function to format an error message.
		/// </summary>
		/// <param name="dwFlags">Flags for the message.</param>
		/// <param name="lpSource">Pointer to the location of the message definition. The type of this parameter depends on the settings in the dwFlags parameter. </param>
		/// <param name="dwMessageId">Specifies the 32-bit message identifier for the requested message.</param>
		/// <param name="dwLanguageId">Not supported.</param>
		/// <param name="lpBuffer">Buffer that holds the message.</param>
		/// <param name="nSize">Size of the buffer in bytes.</param>
		/// <param name="Arguments">Miscellaneous arguments for formatting.</param>
		/// <returns>Number of characters in the buffer, 0 if failure.</returns>
		[DllImport("Kernel32.dll", SetLastError = true)]
		public static extern uint FormatMessage(ErrorFormattingFlags dwFlags, IntPtr lpSource, uint dwMessageId, uint dwLanguageId, ref IntPtr lpBuffer, uint nSize, string[] Arguments);

		/// <summary>
		/// Function to return a list of input devices.
		/// </summary>
		/// <param name="pRawInputDeviceList">List of devices.</param>
		/// <param name="puiNumDevices">Number of devices.</param>
		/// <param name="cbSize">Size of RAWINPUTDEVICELIST in bytes.</param>
		/// <returns>-1 for error, otherwise number of devices in the returned array.</returns>
		[DllImport("user32.dll")]
		public static extern int GetRawInputDeviceList([Out, MarshalAs(UnmanagedType.LPArray)] RAWINPUTDEVICELIST[] pRawInputDeviceList,ref int puiNumDevices, int cbSize);

		/// <summary>
		/// Function to retrieve device information.
		/// </summary>
		/// <param name="hDevice">Handle to the device.</param>
		/// <param name="uiCommand">Command to determine what type of data to return.</param>
		/// <param name="pData">Pointer to the buffer that holds the data.</param>
		/// <param name="pcbSize">Size of the buffer in bytes (or characters in the case of DeviceName).</param>
		/// <returns>-1 for error, otherwise number of bytes in the buffer.</returns>
		[DllImport("user32.dll")]
		public static extern int GetRawInputDeviceInfo(IntPtr hDevice, RawInputCommand uiCommand, [Out] IntPtr pData, ref int pcbSize);

		/// <summary>
		/// Function to retrieve device information.
		/// </summary>
		/// <param name="hDevice">Handle to the device.</param>
		/// <param name="uiCommand">Command to determine what type of data to return.</param>
		/// <param name="pData">Pointer to the buffer that holds the data.</param>
		/// <param name="pcbSize">Size of the buffer in bytes (or characters in the case of DeviceName).</param>
		/// <returns>-1 for error, otherwise number of bytes in the buffer.</returns>
		[DllImport("user32.dll")]
		public static extern int GetRawInputDeviceInfo(IntPtr hDevice, RawInputCommand uiCommand, ref RAWINPUTDEVICEINFO pData, ref int pcbSize);
		
		/// <summary>
		/// Function to retrieve raw input data.
		/// </summary>
		/// <param name="hRawInput">Handle to the raw input.</param>
		/// <param name="uiCommand">Command to issue when retrieving data.</param>
		/// <param name="pData">Raw input data.</param>
		/// <param name="pcbSize">Number of bytes in the array.</param>
		/// <param name="cbSizeHeader">Size of the header.</param>
		/// <returns>0 if successful if pData is null, otherwise number of bytes if pData is not null.</returns>
		[DllImport("user32.dll")]
		public static extern int GetRawInputData(IntPtr hRawInput, RawInputCommand uiCommand, out RAWINPUT pData, ref int pcbSize, int cbSizeHeader);

		/// <summary>
		/// Function to retrieve raw input data.
		/// </summary>
		/// <param name="hRawInput">Handle to the raw input.</param>
		/// <param name="uiCommand">Command to issue when retrieving data.</param>
		/// <param name="pData">Raw input data.</param>
		/// <param name="pcbSize">Number of bytes in the array.</param>
		/// <param name="cbSizeHeader">Size of the header.</param>
		/// <returns>0 if successful if pData is null, otherwise number of bytes if pData is not null.</returns>
		[DllImport("user32.dll")]
		public static extern int GetRawInputData(IntPtr hRawInput, RawInputCommand uiCommand, out RAWINPUTx64 pData, ref int pcbSize, int cbSizeHeader);

		/// <summary>
		/// Function to retrieve raw input data.
		/// </summary>
		/// <param name="hRawInput">Handle to the raw input.</param>
		/// <param name="uiCommand">Command to issue when retrieving data.</param>
		/// <param name="pData">Raw input data.</param>
		/// <param name="pcbSize">Number of bytes in the array.</param>
		/// <param name="cbSizeHeader">Size of the header.</param>
		/// <returns>0 if successful if pData is null, otherwise number of bytes if pData is not null.</returns>
		[DllImport("user32.dll")]
		public static extern int GetRawInputData(IntPtr hRawInput, RawInputCommand uiCommand, byte[] pData, ref int pcbSize, int cbSizeHeader);

		/// <summary>
		/// Function to register a raw input device.
		/// </summary>
		/// <param name="pRawInputDevices">Array of raw input devices.</param>
		/// <param name="uiNumDevices">Number of devices.</param>
		/// <param name="cbSize">Size of the RAWINPUTDEVICE structure.</param>
		/// <returns>TRUE if successful, FALSE if not.</returns>
		[DllImport("user32.dll")]
		public static extern bool RegisterRawInputDevices([MarshalAs(UnmanagedType.LPArray, SizeParamIndex=0)] RAWINPUTDEVICE[] pRawInputDevices, int uiNumDevices, int cbSize);

		/// <summary>
		/// Function to register a raw input device.
		/// </summary>
		/// <param name="devices">Array of device information.</param>
		/// <returns>TRUE if successful, FALSE if not.</returns>
		public static bool RegisterRawInputDevices(RAWINPUTDEVICE[] devices)
		{
			return RegisterRawInputDevices(devices, devices.Length, Marshal.SizeOf(typeof(RAWINPUTDEVICE)));
		}

		/// <summary>
		/// Function to register a raw input device.
		/// </summary>
		/// <param name="device">Device information.</param>
		/// <returns>TRUE if successful, FALSE if not.</returns>
		public static bool RegisterRawInputDevices(RAWINPUTDEVICE device)
		{
			RAWINPUTDEVICE[] devices = new RAWINPUTDEVICE[1];		// Raw input devices.

			devices[0] = device;
			return RegisterRawInputDevices(devices, 1, Marshal.SizeOf(typeof(RAWINPUTDEVICE)));
		}

		/// <summary>
		/// Function to set the text color for the specified device context to the specified color. 
		/// </summary>
		/// <param name="hdc">Handle to the device context.</param>
		/// <param name="crColor">Specifies the color of the text.</param>
		/// <returns>If the function succeeds, the return value is a color reference for the previous text color.  If the function fails, the return value is CLR_INVALID.</returns>
		[DllImport("gdi32.dll")]
		public static extern uint SetTextColor(IntPtr hdc, int crColor);

		/// <summary>
		/// Function to create a logical brush that has the specified solid color
		/// </summary>
		/// <param name="crColor">Color of the brush.</param>
		/// <returns>Handle to the brush, NULL if failed.</returns>
		[DllImport("gdi32.dll")]
		public static extern IntPtr CreateSolidBrush(uint crColor);

		/// <summary>
		/// Function that writes a character string at the specified location, using the currently selected font, background color, and text color.
		/// </summary>
		/// <param name="hdc">Handle to the device context.</param>
		/// <param name="nXStart">Specifies the x-coordinate, in logical coordinates, of the reference point that the system uses to align the string.</param>
		/// <param name="nYStart">Specifies the y-coordinate, in logical coordinates, of the reference point that the system uses to align the string.</param>
		/// <param name="lpString">The string to be drawn.</param>
		/// <param name="cbString">Specifies the length of the string.</param>
		/// <returns>If the function succeeds, the return value is nonzero.  If the function fails, the return value is zero.</returns>
		[DllImport("gdi32.dll")]
		public static extern bool TextOut(IntPtr hdc, int nXStart, int nYStart, string lpString, int cbString);

		/// <summary>
		/// Function that creates a memory device context (DC) compatible with the specified device. 
		/// </summary>
		/// <param name="hdc">Handle to an existing DC. If this handle is NULL, the function creates a memory DC compatible with the application's current screen.</param>
		/// <returns>If the function succeeds, the return value is the handle to a memory DC.  If the function fails, the return value is NULL. </returns>
		[DllImport("gdi32.dll")]
		public static extern IntPtr CreateCompatibleDC(IntPtr hdc);

		/// <summary>
		/// The MulDiv function multiplies two 32-bit values and then divides the 64-bit result by a third 32-bit value. The return value is rounded up or down to the nearest integer.
		/// </summary>
		/// <param name="nNumber">Multiplicand.</param>
		/// <param name="nNumerator">Multiplier.</param>
		/// <param name="nDenominator">Number by which the result of the multiplication (nNumber * nNumerator) is to be divided.</param>
		/// <returns>If the function succeeds, the return value is the result of the multiplication and division. If either an overflow occurred or nDenominator was 0, the return value is �1.</returns>
		[DllImport("kernel32.dll")]
		public static extern int MulDiv(int nNumber, int nNumerator, int nDenominator);

		/// <summary>
		/// Function to create a font.
		/// </summary>
		/// <param name="nHeight">Height of the font.</param>
		/// <param name="nWidth">Width of the font.</param>
		/// <param name="nEscapement">Specifies the angle, in tenths of degrees, between the escapement vector and the x-axis of the device. The escapement vector is parallel to the base line of a row of text.</param>
		/// <param name="nOrientation">Specifies the angle, in tenths of degrees, between each character's base line and the x-axis of the device.</param>
		/// <param name="fnWeight">Specifies the weight of the font in the range 0 through 1000. For example, 400 is normal and 700 is bold. If this value is zero, a default weight is used.</param>
		/// <param name="fdwItalic">Specifies an italic font if set to TRUE.</param>
		/// <param name="fdwUnderline">Specifies an underlined font if set to TRUE.</param>
		/// <param name="fdwStrikeOut">Specifies a strikeout font if set to TRUE.</param>
		/// <param name="fdwCharSet">Specifies the character set.</param>
		/// <param name="fdwOutputPrecision">Specifies the output precision. The output precision defines how closely the output must match the requested font's height, width, character orientation, escapement, pitch, and font type.</param>
		/// <param name="fdwClipPrecision">Specifies the clipping precision. The clipping precision defines how to clip characters that are partially outside the clipping region.</param>
		/// <param name="fdwQuality">Specifies the output quality. The output quality defines how carefully GDI must attempt to match the logical-font attributes to those of an actual physical font.</param>
		/// <param name="fdwPitchAndFamily">Specifies the pitch and family of the font. The two low-order bits specify the pitch of the font.</param>
		/// <param name="lpszFace">Name of the font face.</param>
		/// <returns>Handle to a font object.</returns>
		[DllImport("gdi32.dll")]
		public static extern IntPtr CreateFont(int nHeight, int nWidth, int nEscapement, int nOrientation, FontWeight fnWeight, bool fdwItalic, bool fdwUnderline, bool fdwStrikeOut, FontCharacterSet fdwCharSet, FontOutputPrecision fdwOutputPrecision, FontClippingPrecision fdwClipPrecision, FontQuality fdwQuality, FontPitchAndFamily fdwPitchAndFamily, string lpszFace);

		/// <summary>
		/// Function to retrieve character widths.
		/// </summary>
		/// <param name="hdc">Device context.</param>
		/// <param name="uFirstChar">First character.</param>
		/// <param name="uLastChar">Last character.</param>
		/// <param name="lpabc">Array of ABC widths.</param>
		/// <returns>TRUE if successful, FALSE if not.</returns>
		[DllImport("gdi32.dll", CharSet = CharSet.Auto)]
		public static extern bool GetCharABCWidths(IntPtr hdc, uint uFirstChar, uint uLastChar, [Out] ABC[] lpabc);

		/// <summary>
		/// Function to retrieve character widths.
		/// </summary>
		/// <param name="hdc">Device context.</param>
		/// <param name="uFirstChar">First character.</param>
		/// <param name="uLastChar">Last character.</param>
		/// <param name="lpabc">Array of ABC widths.</param>
		/// <returns>TRUE if successful, FALSE if not.</returns>
		[DllImport("gdi32.dll", CharSet = CharSet.Auto)]
		public static extern bool GetCharABCWidthsFloat(IntPtr hdc, uint uFirstChar, uint uLastChar, [Out] ABCFloat[] lpabc);

		/// <summary>
		/// Function to set the visibility of the mouse cursor.
		/// </summary>
		/// <param name="bShow">TRUE to show, FALSE to hide.</param>
		/// <returns>-1 if no mouse is installed, 0 or greater for the number of times this function has been called with TRUE.</returns>
		[DllImport("User32.dll")]		
		public static extern int ShowCursor(bool bShow);

		/// <summary>
		/// Function to clip the mouse cursor position.
		/// </summary>
		/// <param name="lpRect">Rectangle to constrain the cursor.</param>
		/// <returns>TRUE if successful, FALSE if not.</returns>
		[DllImport("user32.dll")]
		[Obsolete("Use System.Windows.Forms.Cursor.Clip instead.")]
		public static extern bool ClipCursor(ref RECT lpRect);

		/// <summary>
		/// Function to clip the mouse cursor position.
		/// </summary>
		/// <param name="rectangle">Rectangle to constrain the cursor.</param>
		/// <returns>TRUE if successful, FALSE if not.</returns>
		[Obsolete("Use System.Windows.Forms.Cursor.Clip instead.")]
		public static bool ClipCursor(Rectangle rectangle)
		{
			RECT rect = (RECT)rectangle; // Bounding rectangle.

			return ClipCursor(ref rect);
		}

		/// <summary>
		/// Function to retrieve the mouse cursor position.
		/// </summary>
		/// <param name="lpPoint">Point that will contain the cursor position.</param>
		/// <returns>TRUE if successful, FALSE if not.</returns>
		[DllImport("user32.dll")]
		[Obsolete("Use System.Windows.Forms.Cursor.Position instead.")]
		public static extern bool GetCursorPos(out POINT lpPoint);

		/// <summary>
		/// Function to set the mouse cursor position.
		/// </summary>
		/// <param name="X">Horizontal position.</param>
		/// <param name="Y">Vertical position.</param>
		/// <returns>TRUE if successful, FALSE if not.</returns>
		[DllImport("user32.dll")]
		[Obsolete("Use System.Windows.Forms.Cursor.Position instead.")]
		public static extern bool SetCursorPos(int X, int Y);

		/// <summary>
		/// Function to set the mouse cursor position.
		/// </summary>
		/// <param name="position">Position of the cursor.</param>
		/// <returns></returns>
		[Obsolete("Use System.Windows.Forms.Cursor.Position instead.")]
		public static bool SetCursorPos(Point position)
		{
			return SetCursorPos(position.X, position.Y);
		}

        /// <summary>
        /// Function to register a window class.
        /// </summary>
        /// <param name="lpwcx">Window class information.</param>
        /// <returns>An identifier for the window class, 0 for failure.</returns>
        [DllImport("user32.dll")]
        [return: MarshalAs(UnmanagedType.U2)]
        public static extern short RegisterClassEx([In] ref WNDCLASSEX lpwcx);

        /// <summary>
        /// Function to unregister a window class.
        /// </summary>
        /// <param name="lpClassName">Name of the window class to remove.</param>
        /// <param name="hInstance">Owning instance of the class.</param>
        /// <returns>TRUE for success, FALSE for failure.</returns>
        [DllImport("user32.dll")]
        public static extern bool UnregisterClass(string lpClassName, IntPtr hInstance);
        
        /// <summary>
        /// Function to create a window.
        /// </summary>
        /// <param name="dwExStyle">Extended style attributes.</param>
        /// <param name="lpClassName">Class name of the window.</param>
        /// <param name="lpWindowName">Caption for the window.</param>
        /// <param name="dwStyle">Style attributes.</param>
        /// <param name="x">Horizontal position.</param>
        /// <param name="y">Vertical position.</param>
        /// <param name="nWidth">Width of the window.</param>
        /// <param name="nHeight">Height of the window.</param>
        /// <param name="hWndParent">Parent window handle.</param>
        /// <param name="hMenu">Menu handle.</param>
        /// <param name="hInstance">Owning instance of the window.</param>
        /// <param name="lpParam">Parameters to pass upon window creation.</param>
        /// <returns>A window handle for the new window, IntPtr.Zero for failure.</returns>
        [DllImport("user32.dll")]
        public static extern IntPtr CreateWindowEx(WindowStylesEx dwExStyle, string lpClassName, string lpWindowName, WindowStyles dwStyle, int x, int y, int nWidth, int nHeight, IntPtr hWndParent, IntPtr hMenu, IntPtr hInstance, IntPtr lpParam);

        /// <summary>
        /// Function to destroy a window.
        /// </summary>
        /// <param name="hWnd">Handle to the window to destroy.</param>
        /// <returns>TRUE for success, FALSE for failure.</returns>
        [DllImport("user32.dll")]
        public static extern bool DestroyWindow(IntPtr hWnd);

		/// <summary>
		/// Function to register a hotkey with the system.
		/// </summary>
		/// <param name="hWnd">Window handle that will receive the hotkey notification.</param>
		/// <param name="id">ID of the hot key.</param>
		/// <param name="modifiers">Modifiers that need to be pressed with the hot key.</param>
		/// <param name="virtualkeyCode">Key code for the hot key.</param>
		/// <returns>TRUE if successful, FALSE if not.</returns>
		[DllImport("User32")]
		public static extern bool RegisterHotKey(IntPtr hWnd, int id, HotkeyModifierFlags modifiers, uint virtualkeyCode);

		/// <summary>
		/// Function to unregister the hot key.
		/// </summary>
		/// <param name="hWnd">Window handle that is associated with the hot key.</param>
		/// <param name="id">ID of the hot key.</param>
		/// <returns>TRUE if successful, FALSE if not.</returns>
		[DllImport("User32")]
		public static extern bool UnregisterHotKey(IntPtr hWnd, int id);

		/// <summary>
		/// Function to add a string to the global atom table.
		/// </summary>
		/// <param name="atomName">String to add to the table.</param>
		/// <returns>Handle to the ATOM, zero if failed.</returns>
		[DllImport("Kernel32")]
		public static extern short GlobalAddAtom(string atomName);

		/// <summary>
		/// Function to remove an atom.
		/// </summary>
		/// <param name="atom">Atom handle to delete.</param>
		/// <returns>Zero if successful, if failed the atom handle is returned.</returns>
		[DllImport("Kernel32")]
		public static extern short GlobalDeleteAtom(short atom);

		/// <summary>
		/// Function to retrieve the command line arguments given a path.
		/// </summary>
		/// <param name="path">Path to be searched.</param>
		/// <returns>Arguments from the path.</returns>
		[DllImport("Shlwapi.dll")]
		public static extern string PathGetArgs(string path);

		/// <summary>
		/// Function to truncate a path to fit within a certain number of characters by replacing path components with ellipses.
		/// </summary>
		/// <param name="pszOut">Altered string.</param>
		/// <param name="pszSrc">String that contains the path to alter.</param>
		/// <param name="cchMax">Maximum number of characters for the altered string.</param>
		/// <param name="dwFlags">Reserved.</param>
		/// <returns>TRUE if successful, FALSE if not.</returns>
		[DllImport("Shlwapi.dll")]
		public static extern int PathCompactPathEx(StringBuilder pszOut, StringBuilder pszSrc, uint cchMax, uint dwFlags);

		/// <summary>
		/// Function to perform a bit block transfer.
		/// </summary>
		/// <param name="hdcDst">Device context handle of the destination.</param>
		/// <param name="xDst">Horizontal position on the destination to place the data.</param>
		/// <param name="yDst">Vertical position on the destination to place the data.</param>
		/// <param name="cx">Width of the data.</param>
		/// <param name="cy">Height of the data.</param>
		/// <param name="hdcSrc">Device context handle of the destination.</param>
		/// <param name="xSrc">Horizontal position on the source to retrieve the data from.</param>
		/// <param name="ySrc">Vertical position on the source to retrieve the data from.</param>
		/// <param name="ulRop">Raster operation. See <see cref="BinaryRasterOps">BinaryRasterOps</see> and <see cref="TernaryRasterOps">TernaryRasterOps</see>.</param>
		/// <returns>TRUE for success, FALSE if failed.</returns>
		[DllImport("gdi32.dll")]
		public static extern bool BitBlt(IntPtr hdcDst, int xDst, int yDst, int cx, int cy, IntPtr hdcSrc, int xSrc, int ySrc, TernaryRasterOps ulRop);

        /// <summary>
        /// Function to delete an object handle.
        /// </summary>
        /// <param name="hObject">Handle to the object to delete.</param>
        /// <returns>TRUE for success, FALSE for failure.</returns>
        [DllImport("gdi32.dll")]
        public static extern bool DeleteObject(IntPtr hObject);

		/// <summary>
		/// Function to perform a stretched bit block transfer.
		/// </summary>
		/// <param name="hdcDst">Device context handle of the destination.</param>
		/// <param name="xDst">Horizontal position on the destination to place the data.</param>
		/// <param name="yDst">Vertical position on the destination to place the data.</param>
		/// <param name="cx">Width of the destination data.</param>
		/// <param name="cy">Height of the destination data.</param>
		/// <param name="hdcSrc">Device context handle of the destination.</param>
		/// <param name="xSrc">Horizontal position on the source to retrieve the data from.</param>
		/// <param name="ySrc">Vertical position on the source to retrieve the data from.</param>
		/// <param name="cxSrc">Width of the source data.</param>
		/// <param name="cySrc">Height of the source data.</param>
		/// <param name="ulRop">Raster operation. See <see cref="BinaryRasterOps">BinaryRasterOps</see> and <see cref="TernaryRasterOps">TernaryRasterOps</see>.</param>
		/// <returns>TRUE for success, FALSE if failed.</returns>
		[DllImport("gdi32.dll")]
		public static extern bool StretchBlt(IntPtr hdcDst, int xDst, int yDst, int cx, int cy, IntPtr hdcSrc, int xSrc, int ySrc, int cxSrc, int cySrc, uint ulRop);

		/// <summary>
		/// Function to create a device context from a device name.
		/// </summary>
		/// <param name="lpszDriver">Name of the driver to use.</param>
		/// <param name="lpszDevice">Device name.</param>
		/// <param name="lpszOutput">Must be IntPtr.Zero.</param>
		/// <param name="lpInitData">Device initialization data, can be IntPtr.Zero (and must be if the lpszDriver is "DISPLAY".</param>
		/// <returns>Device context handle.  IntPtr.Zero if failed.</returns>
		[DllImport("gdi32.dll")]
		public static extern IntPtr CreateDC(string lpszDriver, string lpszDevice, string lpszOutput, IntPtr lpInitData);

        /// <summary>
        /// Function to create a device context from a device name.
        /// </summary>
        /// <param name="lpszDriver">Name of the driver to use.</param>
        /// <param name="lpszDevice">Device name.</param>
        /// <param name="lpszOutput">Must be IntPtr.Zero.</param>
        /// <param name="lpInitData">Device initialization data.</param>
        /// <returns>Device context handle.  IntPtr.Zero if failed.</returns>
        [DllImport("gdi32.dll")]
        public static extern IntPtr CreateDC(string lpszDriver, string lpszDevice, string lpszOutput, ref DEVMODE lpInitData);

		/// <summary>
		/// Function to delete a device context handle created with <seealso cref="CreateDC(string,string,string,IntPtr)">CreateDC</seealso>.
		/// </summary>
		/// <param name="hdc">Device context handle to delete.</param>
		/// <returns>TRUE for success, FALSE for failure.</returns>
		[DllImport("gdi32.dll")]
		public static extern bool DeleteDC(IntPtr hdc);

		/// <summary>
		/// Function to retrieve the full path and file name of the module associated with the specified window handle
		/// </summary>
		/// <param name="hWnd">Window handle to query.</param>
		/// <param name="lpString">Filename of the module.</param>
		/// <param name="nMaxCount">Number of characters in the filename.</param>
		/// <returns>Number of characters actually copied.</returns>
		[DllImport("user32.dll")]
		public static extern int GetWindowModuleFileName(IntPtr hWnd, StringBuilder lpString, int nMaxCount);

		/// <summary>
		/// Function to set the position and attributes of a window.
		/// </summary>
		/// <param name="hWnd">Window to manipulate.</param>
		/// <param name="hWndInsertAfter">Window in the Z-Order to insert after, or one of <see cref="SetWindowPositionHandles">SetWindowPositionHandles</see>.</param>
		/// <param name="X">New horizontal position.</param>
		/// <param name="Y">New vertical position.</param>
		/// <param name="cx">New width of the window.</param>
		/// <param name="cy">New height of the window.</param>
		/// <param name="uFlags">A combination of <see cref="SetWindowPositionFlags">SetWindowPositionFlags</see>.</param>
		/// <returns>Non-zero for success, zero for failure.</returns>
		[DllImport("user32.dll")]
		public static extern int SetWindowPos(IntPtr hWnd, IntPtr hWndInsertAfter, int X, int Y, int cx, int cy, SetWindowPositionFlags uFlags);

		/// <summary>
		/// Function to retrieve window placement information.
		/// </summary>
		/// <param name="window">Window handle to get info for.</param>
		/// <param name="position">Position information.</param>
		/// <returns>TRUE for success, FALSE for failure.</returns>
		[DllImport("user32.dll")]
		public static extern bool GetWindowPlacement(IntPtr window, ref WINDOWPLACEMENT position);

		/// <summary>
		/// Function to define a new window message that is guaranteed to be unique throughout the system.
		/// </summary>
		/// <param name="message">Message to be registered.</param>
		/// <returns>Message identifier in the range of 0xC000 to 0xFFFF if successful, zero if not.</returns>
		[DllImport("User32.dll")]
		public static extern int RegisterWindowMessage(string message);

		/// <summary>
		/// Function to enumerate windows.
		/// </summary>
		/// <param name="callback">Window enumeration callback.</param>
		/// <param name="lParam">Extra parameters.</param>
		[DllImport("User32.dll")]
		public static extern void EnumWindows(EnumWindowsCallback callback, Int32 lParam);

		/// <summary>
		/// Function to determine if a window is visible or not.
		/// </summary>
		/// <param name="hWnd">Handle of window to check.</param>
		/// <returns>TRUE if visible, FALSE if not.</returns>
		[DllImport("User32.dll")]
		public static extern bool IsWindowVisible(IntPtr hWnd);

		/// <summary>
		/// Function to return the parent of this window.
		/// </summary>
		/// <param name="hWnd">Child window to retrieve the parent handle for.</param>
		/// <returns>Window handle of the parent, IntPtr.Zero if failed or has no owner.</returns>
		[DllImport("User32.dll")]
		public static extern IntPtr GetParent(IntPtr hWnd);

		/// <summary>
		/// Function to get the class name of the window.
		/// </summary>
		/// <param name="hWnd">Window handle from which to retrieve the class name.</param>
		/// <param name="lpClassName">String buffer to hold the classname.</param>
		/// <param name="nMaxCount">Buffer length.</param>
		/// <returns>Number of characters copied if successful, zero for failure.</returns>
		[DllImport("User32.dll")]
		public static extern int GetClassName(IntPtr hWnd, StringBuilder lpClassName, int nMaxCount);

		/// <summary>
		/// Function to get the caption of the window.
		/// </summary>
		/// <param name="hWnd">Window handle from which to retrieve the caption.</param>
		/// <param name="lpString">String buffer to hold the caption.</param>
		/// <param name="nMaxCount">Buffer length.</param>
		/// <returns>Number of characters copied if successful, zero for failure.</returns>
		[DllImport("User32.dll")]
		public static extern int GetWindowText(IntPtr hWnd, StringBuilder lpString, int nMaxCount);

		/// <summary>
		/// Function to get the window information for a window.
		/// </summary>
		/// <param name="hWnd">Window handle from which to get the styles.</param>
		/// <param name="index">Fields in the window structure to retrieve the data from.</param>
		/// <returns>Data for the window field.</returns>
		[DllImport("User32.dll")]
		public static extern int GetWindowLong(IntPtr hWnd, WindowLongFields index);

		/// <summary>
		/// Function to send a message to the system with a specified timeout.
		/// </summary>
		/// <param name="hWnd">Window handle that will receive the message, or NULL for the system.</param>
		/// <param name="uMsg">Message to send.</param>
		/// <param name="wParam">1st set of parameters.</param>
		/// <param name="lParam">2nd set of parameters.</param>
		/// <param name="fuFlags">One or more flags from <see cref="SendMessageTimeoutFlags">SendMessageTimeoutFlags</see>.</param>
		/// <param name="uTimeout">Duration in milliseconds to wait.</param>
		/// <param name="lpdwResult">Result of the message.</param>
		/// <returns>Nonzero if successful, zero if failed.</returns>
		[DllImport("User32.dll")]
		public static extern int SendMessageTimeout(IntPtr hWnd, WindowMessages uMsg, int wParam, int lParam, SendMessageTimeoutFlags fuFlags, int uTimeout, out int lpdwResult);

		/// <summary>
		/// Function to get an item from the window class.
		/// </summary>
		/// <param name="hWnd">Window handle associated with the class.</param>
		/// <param name="index">Field in the window class declaration.</param>
		/// <returns>Requested value for the field, zero if failed.</returns>
		[DllImport("User32.dll")]
		public static extern int GetClassLong(IntPtr hWnd, ClassLongFields index);

		/// <summary>
		/// Function to retrieve the ID of the thread for the window, and the process ID.
		/// </summary>
		/// <param name="hWnd">Window handle created by the thread.</param>
		/// <param name="processId">Process ID associated with the thread.</param>
		/// <returns>The thread ID.</returns>
		[DllImport("User32.dll")]
		public static extern int GetWindowThreadProcessId(IntPtr hWnd, out int processId);

		/// <summary>
		/// Function to send a message to a window.
		/// </summary>
		/// <param name="hWnd">Window handle that receives the message.</param>
		/// <param name="uMsg">Message to send.</param>
		/// <param name="wParam">1st set of parameters.</param>
		/// <param name="lParam">2nd set of parameters.</param>
		/// <returns>Depends on the message being sent.</returns>
		[DllImport("User32.dll")]
		public static extern int SendMessage(IntPtr hWnd, WindowMessages uMsg, IntPtr wParam, IntPtr lParam);


		/// <summary>
		/// Function to post a message to a window.
		/// </summary>
		/// <param name="hWnd">Window handle that receives the message.</param>
		/// <param name="uMsg">Message to send.</param>
		/// <param name="wParam">1st set of parameters.</param>
		/// <param name="lParam">2nd set of parameters.</param>
		/// <returns>Depends on the message being sent.</returns>
		[DllImport("User32.dll")]
		public static extern int PostMessage(IntPtr hWnd, WindowMessages uMsg, IntPtr wParam, IntPtr lParam);

		/// <summary>
		/// Function to switch to a window.
		/// </summary>
		/// <param name="hWnd">Handle of the window to switch to.</param>
		/// <param name="altTabActivated">TRUE to indicate that this window is being switched by ALT+TAB, FALSE if not.</param>
		[DllImport("User32.dll")]
		public static extern void SwitchToThisWindow(IntPtr hWnd, bool altTabActivated);

		/// <summary>
		/// Function to asynchronously show a window.
		/// </summary>
		/// <param name="hWnd">Window handle to show.</param>
		/// <param name="command">Show window command.</param>
		/// <returns>If previously visible, returns non-zero, zero if the window was invisible.</returns>
		[DllImport("User32.dll")]
		public static extern int ShowWindowAsync(IntPtr hWnd, ShowWindowFlags command);

		/// <summary>
		/// Function to retrieve the handle of the desktop window.
		/// </summary>
		/// <returns>Handle to the desktop window, IntPtr.Zero if failure.</returns>
		[DllImport("user32.dll")]
		public static extern IntPtr GetDesktopWindow();

		/// <summary>
		/// Function to retrieve the handle of the foreground window.
		/// </summary>
		/// <returns>Handle to the foreground window, IntPtr.Zero if failure.</returns>
		[DllImport("user32.dll")]
		public static extern IntPtr GetForegroundWindow();

		/// <summary>
		/// Function to bring the specified window to the foreground.
		/// </summary>
		/// <param name="window">Handle to the window to bring forward.</param>
		/// <returns>TRUE for success, FALSE for failure.</returns>
		[DllImport("user32.dll")]
		public static extern bool BringWindowToTop(IntPtr window);

		/// <summary>
		/// Function to get window information.
		/// </summary>
		/// <param name="hwnd">Window handle to get information from.</param>
		/// <param name="info"><see cref="WINDOWINFO">Information</see> value type.</param>
		/// <returns>TRUE for success, FALSE for failure.</returns>
		[DllImport("user32.dll")]
		public static extern bool GetWindowInfo(IntPtr hwnd, ref WINDOWINFO info);

		/// <summary>
		/// Function to retrieve a device context handle (HDC) for a window.
		/// </summary>
		/// <param name="hwnd">Window handle that owns the device context handle.</param>
		/// <returns>The device context handle, IntPtr.Zero for failure.</returns>
		[DllImport("user32.dll")]
		public static extern IntPtr GetWindowDC(IntPtr hwnd);

		/// <summary>
		/// Function to retrieve a device context handle (HDC).
		/// </summary>
		/// <param name="hwnd">Window handle that owns the device context handle.  Use IntPtr.Zero to retrieve the desktop DC.</param>
		/// <returns>The device context handle, IntPtr.Zero for failure.</returns>
		[DllImport("user32.dll")]
		public static extern IntPtr GetDC(IntPtr hwnd);

		/// <summary>
		/// Function to release a device context handle.
		/// </summary>
		/// <param name="hwnd">Window that owns the handle.</param>
		/// <param name="hdc">Handle to release</param>
		/// <returns>1 if the handle was released, 0 if not.</returns>
		[DllImport("user32.dll")]
		public static extern Int32 ReleaseDC(IntPtr hwnd, IntPtr hdc);

		/// <summary>
		/// Function to return window boundaries.
		/// </summary>
		/// <param name="hwnd">Window handle to retrieve the dimensions for.</param>
		/// <param name="rectangle">Boundaries of the entire window.</param>
		/// <returns>TRUE for success, FALSE for failure.</returns>
		[DllImport("user32.dll")]
		public static extern bool GetWindowRect(IntPtr hwnd, ref RECT rectangle);

		/// <summary>
		/// Function to return client window boundaries.
		/// </summary>
		/// <param name="hwnd">Window handle to retrieve the client dimensions for.</param>
		/// <param name="rectangle">Boundaries of the client area.</param>
		/// <returns>TRUE for success, FALSE for failure.</returns>
		[DllImport("user32.dll")]
		public static extern bool GetClientRect(IntPtr hwnd, ref RECT rectangle);

		/// <summary>
		/// Function to return a window handle from a point.
		/// </summary>
		/// <param name="pt">Point to test.</param>
		/// <returns>The window handle that intersects the point, IntPtr.Zero for no window.</returns>
		[DllImport("user32.dll")]
		public static extern IntPtr WindowFromPoint(POINT pt);

		/// <summary>
		/// Function to capture the mouse.
		/// </summary>
		/// <param name="hWnd">Window handle that will own the mouse.</param>
		/// <returns>Previous owner of the mouse, IntPtr.Zero if there was no owner.</returns>
		[DllImport("user32.dll")]
		public static extern IntPtr SetCapture(IntPtr hWnd);

		/// <summary>
		/// Function to release the mouse from capture.
		/// </summary>
		/// <returns>TRUE if successful, FALSE if not.</returns>
		[DllImport("user32.dll")]
		public static extern bool ReleaseCapture();

		/// <summary>
		/// Function to select an object into the specified device context.
		/// </summary>
		/// <param name="hDc">Device context that will retrieve the object handle.</param>
		/// <param name="hObject">Handle to the object.</param>
		/// <returns>Previous object that was selected, IntPtr.Zero if no such object.</returns>
		[DllImport("Gdi32.dll")]
		public static extern IntPtr SelectObject(IntPtr hDc, IntPtr hObject);

		/// <summary>
		/// Function to return the handle to a stock set of objects.
		/// </summary>
		/// <param name="nObject">Stock object to retrieve, one of <see cref="BrushStyles">BrushStyles</see> or <see cref="PenStyles">PenStyles</see> or <see cref="FontStyles">FontStyles</see>.</param>
		/// <returns>Handle to the stock object, IntPtr.Zero for failure.</returns>
		[DllImport("Gdi32.dll")]
		public static extern IntPtr GetStockObject(int nObject);

		/// <summary>
		/// Function to invalidate a windows client area.
		/// </summary>
		/// <param name="hWnd">Window to invalidate.</param>
		/// <param name="lpRect">Area in the client area to invalidate.</param>
		/// <param name="bErase">TRUE to erase the contents, FALSE to leave them.</param>
		/// <returns>TRUE if successful, FALSE if not</returns>
		[DllImport("user32.dll")]
		public static extern bool InvalidateRect(IntPtr hWnd, IntPtr lpRect, bool bErase);

		/// <summary>
		/// Function to refresh a window.
		/// </summary>
		/// <param name="hWnd">Handle of the window to update.</param>
		/// <returns>TRUE if successful, FALSE if not</returns>
		[DllImport("user32.dll")]
		public static extern bool UpdateWindow(IntPtr hWnd);

		/// <summary>
		/// Function to redraw a window.
		/// </summary>
		/// <param name="hWnd">Handle to window to redraw.</param>
		/// <param name="lprcUpdate">List of rectangles for the area to redraw.  If IntPtr.Zero, then the region is used.</param>
		/// <param name="hrgnUpdate">Region to redraw, if both the region and the rectangles are equal to IntPtr.Zero then the entire client area is redrawn.</param>
		/// <param name="flags">One or more of the <see cref="RedrawWindowFlags">RedrawWindowFlags</see>.</param>
		/// <returns>TRUE if successful, FALSE if not.</returns>
		[DllImport("user32.dll")]
		public static extern bool RedrawWindow(IntPtr hWnd, IntPtr lprcUpdate, IntPtr hrgnUpdate, RedrawWindowFlags flags);

		/// <summary>
		/// Function to set a windows hook.
		/// </summary>
		/// <param name="hookType">Type of hook.</param>
		/// <param name="hookProc">Callback function for the hook.</param>
		/// <param name="hInstance">Instance ID of the application.</param>
		/// <param name="nThreadId">Thread ID of the application.</param>
		/// <returns>Handle to the hook if successful, IntPtr.Zero (NULL) for failure.</returns>
		[DllImport("user32.dll")]
		public static extern IntPtr SetWindowsHookEx(EventHookTypes hookType, HookCallback hookProc, IntPtr hInstance, int nThreadId);

		/// <summary>
		/// Function to remove a windows hook.
		/// </summary>
		/// <param name="hookHandle">Handle to the hook.</param>
		/// <returns>Non zero if successful, zero if failure.</returns>
		[DllImport("user32.dll")]
		public static extern int UnhookWindowsHookEx(IntPtr hookHandle);

		/// <summary>
		/// Function to call the next hook.
		/// </summary>
		/// <param name="hookHandle">Handle of the hook to call.</param>
		/// <param name="nCode">Code for the hook.</param>
		/// <param name="wParam">1st set of parameters.</param>
		/// <param name="lParam">2nd set of parameters.</param>
		/// <returns>Dependant on the hook type.  Consult the MSDN for more detail.</returns>
		[DllImport("user32.dll")]
		public static extern int CallNextHookEx(IntPtr hookHandle, int nCode, IntPtr wParam, IntPtr lParam);

		/// <summary>
		/// Function to register a hook with a window.
		/// </summary>
		/// <param name="hWnd">Window handle to register hook with.</param>
		/// <returns>TRUE if successful, FALSE if not.</returns>
		[DllImport("user32.dll")]
		public static extern bool RegisterShellHookWindow(IntPtr hWnd);

		/// <summary>
		/// Function to remove a hook from a window.
		/// </summary>
		/// <param name="hWnd">Window to remove the hook from.</param>
		/// <returns>TRUE if successful, FALSE if not.</returns>
		[DllImport("user32.dll")]
		public static extern bool DeregisterShellHookWindow(IntPtr hWnd);


		/// <summary>
		/// Function to return the last error.
		/// </summary>
		/// <returns>An integer containing the last error code.</returns>
		[DllImport("kernel32.dll", EntryPoint = "GetLastError", SetLastError = true, ExactSpelling = true, CallingConvention = CallingConvention.StdCall)]
		public static extern Int32 GetLastError();

		/// <summary>
		/// Function to create a 16 bit value from two bytes.
		/// </summary>
		/// <param name="low">Low byte.</param>
		/// <param name="high">High byte.</param>
		/// <returns>A 16 bit value containing the two bytes.</returns>
		public static short MakeWORD(byte low, byte high)
		{
			return ((short)(((byte)(low & 0xff)) | ((short)((byte)(high & 0xff))) << 8));
		}

		/// <summary>
		/// Function to return the low end byte from a 16 bit value.
		/// </summary>
		/// <param name="wordValue">16 bit value.</param>
		/// <returns>The low byte of the 16 bit value.</returns>
		public static byte LowBYTE(short wordValue)
		{
			return ((byte)(wordValue & 0xff));
		}

		/// <summary>
		/// Function to return the high end byte from a 16 bit value.
		/// </summary>
		/// <param name="wordValue">16 bit value.</param>
		/// <returns>The high byte of the 16 bit value.</returns>
		public static byte HighBYTE(short wordValue)
		{
			return ((byte)(wordValue >> 8));
		}

		/// <summary>
		/// Function to create a 32 bit value from two bytes.
		/// </summary>
		/// <param name="low">Low 16 bit value.</param>
		/// <param name="high">High 16 bit value.</param>
		/// <returns>A 32 bit value containing the two 16 bit values.</returns>
		public static int MakeDWORD(short low, short high)
		{
			return (((int)(low & 0xffff)) | (((int)(high & 0xffff)) << 16));
		}

		/// <summary>
		/// Function to return the high end 16 bit value from a 32 bit value.
		/// </summary>
		/// <param name="intValue">32 bit value.</param>
		/// <returns>The high 16 bit value of the 32 bit value.</returns>
		public static short HighWORD(int intValue)
		{
			return ((short)(intValue >> 16));
		}

		/// <summary>
		/// Function to return the low end 16 bit value from a 32 bit value.
		/// </summary>
		/// <param name="intValue">32 bit value.</param>
		/// <returns>The low 16 bit value of the 32 bit value.</returns>
		public static short LowWORD(int intValue)
		{
			return ((short)(intValue & 0xffff));
		}

		/// <summary>
		/// Function to return the computer name.
		/// </summary>
		/// <remarks>See the MSDN documentation for a detailed description.</remarks>
		/// <param name="NameType">Formatting for the computer name.</param>
		/// <param name="lpBuffer">Buffer for the computer name.</param>
		/// <param name="lpnSize">Length of the computer name.</param>
		/// <returns>TRUE for success, FALSE if failed.</returns>
        [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Auto)]
        public static extern bool GetComputerNameEx(ComputerNameFormat NameType, [Out] StringBuilder lpBuffer, ref uint lpnSize);

		/// <summary>
		/// Function to return the windows login name.
		/// </summary>
		/// <remarks>See the MSDN documentation for a detailed description.</remarks>
		/// <param name="nameFormat">Formatting for the username.</param>
		/// <param name="userName">Buffer for the username.</param>
		/// <param name="userNameSize">Length of the username.</param>
		/// <returns>Zero if failure, non-zero for success.</returns>
        [DllImport("secur32.dll", CharSet = CharSet.Auto)]
        public static extern int GetUserNameEx(ExtendedNameFormat nameFormat, [Out] StringBuilder userName, ref uint userNameSize);

		/// <summary>
		/// Function to process window messages.
		/// </summary>
		/// <remarks>See the MSDN documentation for a detailed description.</remarks>
		/// <param name="msg">Message block to retrieve.</param>
		/// <param name="hwnd">Window to retrieve messages from, FALSE for all.</param>
		/// <param name="wFilterMin">Minimum message.</param>
		/// <param name="wFilterMax">Maximum message.</param>
		/// <param name="flags">Flags for the function.</param>
		/// <returns>TRUE if messages are ready for processing, FALSE if not.</returns>
		[System.Security.SuppressUnmanagedCodeSecurity, DllImport("User32.dll", CharSet=CharSet.Auto)]
		public static extern bool PeekMessage(out MSG msg, IntPtr hwnd, int wFilterMin, int wFilterMax, PeekMessageFlags flags);

		/// <summary>
		/// Function to translate windows messages.
		/// </summary>
		/// <param name="msg">Message to translate.</param>
		/// <returns>TRUE if successful, FALSE if not.</returns>
		[DllImport("user32.dll")]
		public static extern bool TranslateMessage([In] ref MSG msg);

		/// <summary>
		/// Function to dispatch windows messages.
		/// </summary>
		/// <param name="msg">Message to dispatch.</param>
		/// <returns>TRUE if successful, FALSE if not.</returns>
		[DllImport("user32.dll")]
		public static extern IntPtr DispatchMessage([In] ref MSG msg);

		/// <summary>
		/// Function to return the frequency of the high precision timer.
		/// </summary>
		/// <remarks>See the MSDN documentation for a detailed description.</remarks>
		/// <param name="PerformanceFrequency">Frequency of timer.</param>
		/// <returns>TRUE if system supports high precision timing, FALSE if not.</returns>
		[System.Security.SuppressUnmanagedCodeSecurity, DllImport("kernel32", CharSet=CharSet.Auto)]
		public static extern bool QueryPerformanceFrequency(ref long PerformanceFrequency);

		/// <summary>
		/// Function to return the time from a high resolution timer.
		/// </summary>
		/// <remarks>See the MSDN documentation for a detailed description.</remarks>
		/// <param name="PerformanceCount">Time from the timer.</param>
		/// <returns>TRUE if system supports high precision timing, FALSE if not.</returns>
		[System.Security.SuppressUnmanagedCodeSecurity, DllImport("kernel32",CharSet=CharSet.Auto)]
		public static extern bool QueryPerformanceCounter(ref long PerformanceCount);

		/// <summary>
		/// Function to return time from a medium precision timer.
		/// </summary>
		/// <remarks>
		/// See the MSDN documentation for a detailed description.
		/// <para>
		/// This timer is of lower precision than the high precision timers, do not use unless
		/// your system does not support high resolution timers.
		/// </para>
		/// </remarks>
		/// <returns>Time in milliseconds.</returns>
		[System.Security.SuppressUnmanagedCodeSecurity, DllImport("winmm.dll",CharSet=CharSet.Auto)]
		public static extern int timeGetTime();

		/// <summary>
		/// Function to start a timing session.
		/// </summary>
		/// <param name="uPeriod">Minimum resolution in milliseconds.</param>
		/// <returns>0 if successful, non 0 if not.</returns>
		[System.Security.SuppressUnmanagedCodeSecurity, DllImport("winmm.dll",CharSet=CharSet.Auto)]
		public static extern int timeBeginPeriod(uint uPeriod);

		/// <summary>
		/// Function to end a timing session.
		/// </summary>
		/// <param name="uPeriod">Minimum resolution in milliseconds.</param>
		/// <returns>0 if successful, non 0 if not.</returns>
		[System.Security.SuppressUnmanagedCodeSecurity, DllImport("winmm.dll", CharSet = CharSet.Auto)]
		public static extern int timeEndPeriod(uint uPeriod);

		/// <summary>
		/// Function to return the number of milliseconds since system start.
		/// </summary>
		/// <remarks>See the MSDN documentation for a detailed description.</remarks>
		/// <returns>Milliseconds since system start.</returns>
		[System.Security.SuppressUnmanagedCodeSecurity, DllImport("kernel32",CharSet=CharSet.Auto)]
		public static extern uint GetTickCount();

		/// <summary>
		/// Function to return a standard handle for consoles.
		/// </summary>
		/// <remarks>See the MSDN documentation for a detailed description.</remarks>
		/// <param name="nStdHandle">One of the standard handle types.</param>
		/// <returns>A new handle for the specified handle type.</returns>
		[System.Security.SuppressUnmanagedCodeSecurity, DllImport("kernel32.dll")]
		public static extern IntPtr GetStdHandle(StandardHandles nStdHandle);

		/// <summary>
		/// Function to flush a console buffer.
		/// </summary>
		/// <remarks>See the MSDN documentation for a detailed description.</remarks>
		/// <param name="hConsoleInput">Handle to the buffer to flush.</param>
		/// <returns>TRUE if successful, FALSE if not.</returns>
		[System.Security.SuppressUnmanagedCodeSecurity, DllImport("kernel32.dll")]
		public static extern bool FlushConsoleInputBuffer(IntPtr hConsoleInput);

		/// <summary>
		/// Function to set the buffer size of a console window.
		/// </summary>
		/// <remarks>See the MSDN documentation for a detailed description.</remarks>
		/// <param name="hConsoleOutput">Handle to the console.</param>
		/// <param name="dwSize">Size of the buffer.</param>
		/// <returns>TRUE if successful, FALSE if not.</returns>
		[System.Security.SuppressUnmanagedCodeSecurity, DllImport("kernel32.dll")]
		public static extern bool SetConsoleScreenBufferSize(IntPtr hConsoleOutput, COORD dwSize);

		/// <summary>
		/// Function to read the buffer contents from a console.
		/// </summary>
		/// <remarks>See the MSDN documentation for a detailed description.</remarks>
		/// <param name="hConsoleOutput">Handle of console to read.</param>
		/// <param name="lpBuffer">Buffer to use.</param>
		/// <param name="dwBufferSize">Size of the buffer.</param>
		/// <param name="dwBufferCoord">Buffer coordinates to start writing at.</param>
		/// <param name="lpReadRegion">Region to read.</param>
		/// <returns>TRUE if successful, FALSE if not.</returns>
		[System.Security.SuppressUnmanagedCodeSecurity, DllImport("kernel32.dll")]
		public static extern bool ReadConsoleOutput(IntPtr hConsoleOutput, [Out] CHAR_INFO [] lpBuffer, COORD dwBufferSize, COORD dwBufferCoord, ref SMALL_RECT lpReadRegion);

		/// <summary>
		/// Function to get information about the current console buffer.
		/// </summary>
		/// <remarks>See the MSDN documentation for a detailed description.</remarks>
		/// <param name="hConsoleOutput">Handle of console to read.</param>
		/// <param name="lpConsoleScreenBufferInfo">Structure containing information about the buffer.</param>
		/// <returns>TRUE if successful, FALSE if not.</returns>
		[System.Security.SuppressUnmanagedCodeSecurity, DllImport("kernel32.dll")]
		public static extern bool GetConsoleScreenBufferInfo(IntPtr hConsoleOutput, out CONSOLE_SCREEN_BUFFER_INFO lpConsoleScreenBufferInfo);

		/// <summary>
		/// Function to set the console window information.
		/// </summary>
		/// <remarks>See the MSDN documentation for a detailed description.</remarks>
		/// <param name="hConsoleOutput">Handle of console.</param>
		/// <param name="bAbsolute">TRUE if using absolute coordinates, FALSE if not.</param>
		/// <param name="lpConsoleWindow">Dimensions of the window.</param>
		/// <returns>TRUE if successful, FALSE if not.</returns>
		[System.Security.SuppressUnmanagedCodeSecurity, DllImport("kernel32.dll")]
		public static extern bool SetConsoleWindowInfo(IntPtr hConsoleOutput, bool bAbsolute,[In] ref SMALL_RECT lpConsoleWindow);

		/// <summary>
		/// Function to set a the attributes for a console window.
		/// </summary>
		/// <remarks>See the MSDN documentation for a detailed description.</remarks>
		/// <param name="hConsoleOutput">Handle of console.</param>
		/// <param name="wAttributes">Attributes to set.</param>
		/// <returns>TRUE if successful, FALSE if not.</returns>
		[System.Security.SuppressUnmanagedCodeSecurity, DllImport("kernel32.dll")]
		public static extern bool SetConsoleTextAttribute(IntPtr hConsoleOutput,ConsoleAttributes wAttributes);

		/// <summary>
		/// Function to set the mode for a console.
		/// </summary>
		/// <remarks>See the MSDN documentation for a detailed description.</remarks>
		/// <param name="hConsoleHandle">Handle of console.</param>
		/// <param name="dwMode">Mode flags.</param>
		/// <returns>TRUE if successful, FALSE if not.</returns>
		[System.Security.SuppressUnmanagedCodeSecurity, DllImport("kernel32.dll")]
		public static extern bool SetConsoleMode(IntPtr hConsoleHandle, ConsoleModeFlags dwMode);

		/// <summary>
		/// Function to retrieve the caption for the console window.
		/// </summary>
		/// <remarks>See the MSDN documentation for a detailed description.</remarks>
		/// <param name="lpConsoleTitle">Stringbuilder holding the caption.</param>
		/// <param name="nSize">Size of the buffer.</param>
		/// <returns>Length in characters, 0 if failed.</returns>
		[System.Security.SuppressUnmanagedCodeSecurity, DllImport("kernel32.dll")]
		public static extern uint GetConsoleTitle([Out] StringBuilder lpConsoleTitle, uint nSize);

		/// <summary>
		/// Function to retrieve the current console mode.
		/// </summary>
		/// <remarks>See the MSDN documentation for a detailed description.</remarks>
		/// <param name="hConsoleHandle">Handle of console.</param>
		/// <param name="lpMode">Mode flags.</param>
		/// <returns>TRUE if successful, FALSE if not.</returns>
		[System.Security.SuppressUnmanagedCodeSecurity, DllImport("kernel32.dll")]
		public static extern bool GetConsoleMode(IntPtr hConsoleHandle, out ConsoleModeFlags lpMode);

		/// <summary>
		/// Function to set the console caption.
		/// </summary>
		/// <remarks>See the MSDN documentation for a detailed description.</remarks>
		/// <param name="lpConsoleTitle">New caption for the console window.</param>
		/// <returns>TRUE if successful, FALSE if not.</returns>
		[System.Security.SuppressUnmanagedCodeSecurity, DllImport("kernel32.dll")]
		public static extern bool SetConsoleTitle(string lpConsoleTitle);

		/// <summary>
		/// Function to retrieve console cursor information.
		/// </summary>
		/// <remarks>See the MSDN documentation for a detailed description.</remarks>
		/// <param name="hConsoleOutput">Handle of console.</param>
		/// <param name="lpConsoleCursorInfo">Structure for cursor information.</param>
		/// <returns>TRUE if successful, FALSE if not.</returns>
		[System.Security.SuppressUnmanagedCodeSecurity, DllImport("kernel32.dll")]
		public static extern bool GetConsoleCursorInfo(IntPtr hConsoleOutput, out CONSOLE_CURSOR_INFO lpConsoleCursorInfo);

		/// <summary>
		/// Function to set the cursor information for the console.
		/// </summary>
		/// <remarks>See the MSDN documentation for a detailed description.</remarks>
		/// <param name="hConsoleOutput">Handle of console.</param>
		/// <param name="lpConsoleCursorInfo">Structure for cursor information.</param>
		/// <returns>TRUE if successful, FALSE if not.</returns>
		[System.Security.SuppressUnmanagedCodeSecurity, DllImport("kernel32.dll")]
		public static extern bool SetConsoleCursorInfo(IntPtr hConsoleOutput, [In] ref CONSOLE_CURSOR_INFO lpConsoleCursorInfo);


		/// <summary>
		/// Function to set the cursor position for the console.
		/// </summary>
		/// <remarks>See the MSDN documentation for a detailed description.</remarks>
		/// <param name="hConsoleOutput">Handle of console.</param>
		/// <param name="dwCursorPosition">Cursor position.</param>
		/// <returns>TRUE if successful, FALSE if not.</returns>
		[System.Security.SuppressUnmanagedCodeSecurity, DllImport("kernel32.dll")]
		public static extern bool SetConsoleCursorPosition(IntPtr hConsoleOutput, COORD dwCursorPosition);

		/// <summary>
		/// Function to fill the console buffer with the specified attribute.
		/// </summary>
		/// <remarks>See the MSDN documentation for a detailed description.</remarks>
		/// <param name="hConsoleOutput">Handle of console.</param>
		/// <param name="wAttribute">Attribute to write.</param>
		/// <param name="nLength">Number of characters to write.</param>
		/// <param name="dwWriteCoord">Position to start writing at.</param>
		/// <param name="lpNumberOfAttrsWritten">Number of characters actually written.</param>
		/// <returns>TRUE if successful, FALSE if not.</returns>
		[System.Security.SuppressUnmanagedCodeSecurity, DllImport("kernel32.dll")]
		public static extern bool FillConsoleOutputAttribute(IntPtr hConsoleOutput, ConsoleAttributes wAttribute, uint nLength, COORD dwWriteCoord, out uint lpNumberOfAttrsWritten);

		/// <summary>
		/// Function to fill the console buffer with the specified character.
		/// </summary>
		/// <remarks>See the MSDN documentation for a detailed description.</remarks>
		/// <param name="hConsoleOutput">Handle of console.</param>
		/// <param name="cCharacter">Character to write.</param>
		/// <param name="nLength">Number of characters to write.</param>
		/// <param name="dwWriteCoord">Position to start writing at.</param>
		/// <param name="lpNumberOfCharsWritten">Number of characters actually written.</param>
		/// <returns>TRUE if successful, FALSE if not.</returns>
		[System.Security.SuppressUnmanagedCodeSecurity, DllImport("kernel32.dll")]
		public static extern bool FillConsoleOutputCharacter(IntPtr hConsoleOutput, char cCharacter, uint nLength, COORD dwWriteCoord, out uint lpNumberOfCharsWritten);

		/// <summary>
		/// Function to return the number of console events.
		/// </summary>
		/// <remarks>See the MSDN documentation for a detailed description.</remarks>
		/// <param name="hConsoleInput">Handle of console.</param>
		/// <param name="lpcNumberOfEvents">Number of events present.</param>
		/// <returns>TRUE if successful, FALSE if not.</returns>
		[System.Security.SuppressUnmanagedCodeSecurity, DllImport("kernel32.dll")]
		public static extern bool GetNumberOfConsoleInputEvents(IntPtr hConsoleInput,out uint lpcNumberOfEvents);

		/// <summary>
		/// Function to return console input events.
		/// </summary>
		/// <remarks>See the MSDN documentation for a detailed description.</remarks>
		/// <param name="hConsoleInput">Handle of console.</param>
		/// <param name="lpBuffer">Buffer to read event data into.</param>
		/// <param name="nLength">Number of events to read.</param>
		/// <param name="lpNumberOfEventsRead">Number of events read.</param>
		/// <returns>TRUE if successful, FALSE if not.</returns>
		[System.Security.SuppressUnmanagedCodeSecurity, DllImport("kernel32.dll")]
		public static extern bool ReadConsoleInput(IntPtr hConsoleInput, [Out] INPUT_RECORD [] lpBuffer, uint nLength, out uint lpNumberOfEventsRead);

		/// <summary>
		/// Function to set an event handler for the console.
		/// </summary>
		/// <remarks>See the MSDN documentation for a detailed description.</remarks>
		/// <param name="HandlerRoutine">Handler event.</param>
		/// <param name="Add">TRUE to add, FALSE to remove.</param>
		/// <returns>TRUE if successful, FALSE if not.</returns>
		[DllImport("kernel32.dll")]
		public static extern bool SetConsoleCtrlHandler(ConsoleCtrlDelegate HandlerRoutine,bool Add);

		/// <summary>
		/// Function to set the codepage for the console.
		/// </summary>
		/// <remarks>See the MSDN documentation for a detailed description.</remarks>
		/// <param name="wCodePageID">Code page ID.</param>
		/// <returns>TRUE if successful, FALSE if not.</returns>
		[DllImport("kernel32.dll")]
		public static extern bool SetConsoleOutputCP(uint wCodePageID);

		/// <summary>
		/// Function to set the codepage for the input console.
		/// </summary>
		/// <remarks>See the MSDN documentation for a detailed description.</remarks>
		/// <param name="wCodePageID">Code page ID.</param>
		/// <returns>TRUE if successful, FALSE if not.</returns>
		[DllImport("kernel32.dll")]
		public static extern bool SetConsoleCP(uint wCodePageID);

		/// <summary>
		/// Function to read input from the console.
		/// </summary>
		/// <remarks>See the MSDN documentation for a detailed description.</remarks>
		/// <param name="hConsoleInput">Handle of console.</param>
		/// <param name="lpBuffer">Buffer to use.</param>
		/// <param name="nNumberOfCharsToRead">Number of characters to read.</param>
		/// <param name="lpNumberOfCharsRead">Number of characters read.</param>
		/// <param name="lpReserved">Reserved.</param>
		/// <returns>TRUE if successful, FALSE if not.</returns>
		[DllImport("kernel32.dll")]
		public static extern bool ReadConsole(IntPtr hConsoleInput, [Out] StringBuilder lpBuffer, uint nNumberOfCharsToRead, out uint lpNumberOfCharsRead, IntPtr lpReserved);

		/// <summary>
		/// Function to write a buffer to the console.
		/// </summary>
		/// <remarks>See the MSDN documentation for a detailed description.</remarks>
		/// <param name="hConsoleOutput">Handle of console.</param>
		/// <param name="lpBuffer">Buffer to use.</param>
		/// <param name="dwBufferSize">Size of the buffer.</param>
		/// <param name="dwBufferCoord">Position within buffer to read from.</param>
		/// <param name="lpWriteRegion">Window region to write to.</param>
		/// <returns>TRUE if successful, FALSE if not.</returns>
		[DllImport("kernel32.dll")]
		public static extern bool WriteConsoleOutput(IntPtr hConsoleOutput, CHAR_INFO []lpBuffer, COORD dwBufferSize, COORD dwBufferCoord, ref SMALL_RECT lpWriteRegion);

		/// <summary>
		/// Function to disable or enable drawing in the specified window.
		/// </summary>
		/// <param name="HWND">Window handle to lock.  Pass NULL to unlock.</param>
		/// <returns>Non-zero if successful, zero if successful.</returns>
		[DllImport("User32")]
		public static extern int LockWindowUpdate(IntPtr HWND);

		/// <summary>
		/// Function to copy a file from the source to the destination.
		/// </summary>
		/// <param name="source">Source file to copy.</param>
		/// <param name="destination">Destination for the file.</param>
		/// <param name="failIfExists">TRUE to cause the function to fail if the file exists, FALSE to ignore.</param>
		/// <returns>TRUE if successful, FALSE if not.</returns>
		[DllImport("Kernel32")]
		public static extern bool CopyFile(string source, string destination, bool failIfExists);

		/// <summary>
		/// Function to get system metrics.
		/// </summary>
		/// <param name="nIndex">System metric to retrieve.</param>
		/// <returns>Value for the metric.</returns>
		[DllImport("user32.dll")]
		public static extern int GetSystemMetrics(SystemMetrics nIndex);
		#endregion
	}
}

