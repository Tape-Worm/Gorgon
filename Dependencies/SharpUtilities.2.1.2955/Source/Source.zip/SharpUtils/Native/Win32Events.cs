#region LGPL.
// 
// SharpUtils.
// Copyright (C) 2005 Michael Winsor
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
// 
// Created: Friday, December 02, 2005 5:09:06 PM
// 
#endregion

using System;

namespace SharpUtilities.Native.Win32
{
    /// <summary>
    /// Event arguments for event hooks.
    /// </summary>
    public class EventHookEventArgs : EventArgs
    {
        #region Variables.
        private int _code;              // Event hook code.
        private IntPtr _wParam;         // 1st set of event parameters.
        private IntPtr _lParam;         // 2nd set of event parameters.
        #endregion

        #region Properties.
        /// <summary>
        /// Read only property to return the hook event code.
        /// </summary>
        public int Code
        {
            get
            {
                return _code;
            }
        }

        /// <summary>
        /// Read only property to return the 1st set of parameter data.
        /// </summary>
        public IntPtr wParam
        {
            get
            {
                return _wParam;
            }
        }

        /// <summary>
        /// Read only property to return the 2nd set of parameter data.
        /// </summary>
        public IntPtr lParam
        {
            get
            {
                return _lParam;
            }
        }
        #endregion

        #region Constructor.
        /// <summary>
        /// Constructor.
        /// </summary>
        /// <param name="code">Code for the hook.</param>
        /// <param name="wParam">Parameters 1.</param>
        /// <param name="lParam">Parameters 2.</param>
        public EventHookEventArgs(int code, IntPtr wParam, IntPtr lParam)
        {
            _code = code;
            _wParam = wParam;
            _lParam = lParam;
        }
        #endregion
    }

    /// <summary>
    /// Event definition for the console system event controller.
    /// </summary>
    /// <remarks>Events of this type are called when a system event is trapped in the <seealso cref="SharpUtilities.Console.ConsoleApplication">ConsoleApplication</seealso>.</remarks>
    public delegate Boolean ConsoleCtrlDelegate(ControlEventTypes CtrlType);

    /// <summary>
    /// Event definition for the event hook.
    /// </summary>
    public delegate void HookEventHandler(object sender, EventHookEventArgs e);

    /// <summary>
    /// Event definition for the hook callback procedure.
    /// </summary>
    /// <param name="nCode">Code returned by the hook.</param>
    /// <param name="wParam">1st set of parameters returned by the hook.</param>
    /// <param name="lParam">2nd set of parameters returned by the hook.</param>
    /// <returns>Less than 0 to call next hook, 0 or greater means the procedure did not process the message.</returns>
    public delegate int HookCallback(int nCode, IntPtr wParam, IntPtr lParam);

	/// <summary>
	/// Event definition for the window enumeration callback.
	/// </summary>
	/// <param name="hWnd">Window handle.</param>
	/// <param name="lParam">Parameters.</param>
	/// <returns>TRUE to continue enumeration, FALSE to stop.</returns>
	public delegate bool EnumWindowsCallback(IntPtr hWnd, Int32 lParam);

    /// <summary>
    /// Event definition for the window procedure callback.
    /// </summary>
    /// <param name="hWnd">Handle of the window receiving the message.</param>
    /// <param name="msg">Message being sent.</param>
    /// <param name="wParam">1st set of parameters.</param>
    /// <param name="lParam">2nd set of parameters.</param>
    /// <returns>Depends on message.</returns>
    public delegate IntPtr WndProcCallback(IntPtr hWnd, uint msg, uint wParam, int lParam);
}
