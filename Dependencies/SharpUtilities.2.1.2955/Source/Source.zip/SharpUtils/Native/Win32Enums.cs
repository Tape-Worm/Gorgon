#region LGPL.
// 
// SharpUtils.
// Copyright (C) 2005 Michael Winsor
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
// 
// Created: Tuesday, November 29, 2005 1:14:54 AM
// 
#endregion

using System;

namespace SharpUtilities.Native.Win32
{
	#region Enumerations
	/// <summary>
	/// Enumeration for font code-page character sets.
	/// </summary>
	public enum FontCharacterSet : byte
	{
		/// <summary>
		/// 
		/// </summary>
		ANSI = 0,
		/// <summary>
		/// 
		/// </summary>
		Default = 1,
		/// <summary>
		/// 
		/// </summary>
		Symbol = 2,
		/// <summary>
		/// 
		/// </summary>
		ShiftJIS = 128,
		/// <summary>
		/// 
		/// </summary>
		Hangeul = 129,
		/// <summary>
		/// 
		/// </summary>
		Hangul = 129,
		/// <summary>
		/// 
		/// </summary>
		GB2312 = 134,
		/// <summary>
		/// 
		/// </summary>
		ChineseBig5 = 136,
		/// <summary>
		/// 
		/// </summary>
		OEM = 255,
		/// <summary>
		/// 
		/// </summary>
		Johab = 130,
		/// <summary>
		/// 
		/// </summary>
		Hebrew = 177,
		/// <summary>
		/// 
		/// </summary>
		Arabic = 178,
		/// <summary>
		/// 
		/// </summary>
		Greek = 161,
		/// <summary>
		/// 
		/// </summary>
		Turkish = 162,
		/// <summary>
		/// 
		/// </summary>
		Vietnamese = 163,
		/// <summary>
		/// 
		/// </summary>
		Thai = 222,
		/// <summary>
		/// 
		/// </summary>
		EastEurope = 238,
		/// <summary>
		/// 
		/// </summary>
		Russian = 204,
		/// <summary>
		/// 
		/// </summary>
		Mac = 77,
		/// <summary>
		/// 
		/// </summary>
		Baltic = 186,
	}

	/// <summary>
	/// Enumeration for font output precision.
	/// </summary>
	public enum FontPrecision : byte
	{
		/// <summary>
		/// 
		/// </summary>		
		Default = 0,
		/// <summary>
		/// 
		/// </summary>
		String = 1,
		/// <summary>
		/// 
		/// </summary>
		Character = 2,
		/// <summary>
		/// 
		/// </summary>
		Stroke = 3,
		/// <summary>
		/// 
		/// </summary>
		TrueType = 4,
		/// <summary>
		/// 
		/// </summary>
		Device = 5,
		/// <summary>
		/// 
		/// </summary>
		Raster = 6,
		/// <summary>
		/// 
		/// </summary>
		TrueTypeOnly = 7,
		/// <summary>
		/// 
		/// </summary>
		Outline = 8,
		/// <summary>
		/// 
		/// </summary>
		ScreenOutline = 9,
		/// <summary>
		/// 
		/// </summary>
		PostScriptOnly = 10
	}

	/// <summary>
	/// Enumeration for font pitches/families.
	/// </summary>
	[Flags]
	public enum FontPitchAndFamily : byte
	{
		/// <summary>
		/// 
		/// </summary>
		Default = 0,
		/// <summary>
		/// 
		/// </summary>
		Fixed = 1,
		/// <summary>
		/// 
		/// </summary>
		Variable = 2,
		/// <summary>
		/// 
		/// </summary>
		DontCare = (0 << 4),
		/// <summary>
		/// 
		/// </summary>
		Roman = (1 << 4),
		/// <summary>
		/// 
		/// </summary>
		Swiss = (2 << 4),
		/// <summary>
		/// 
		/// </summary>
		Modern = (3 << 4),
		/// <summary>
		/// 
		/// </summary>
		Script = (4 << 4),
		/// <summary>
		/// 
		/// </summary>
		Decorative = (5 << 4)
	}

	/// <summary>
	/// Enumeration for font types.
	/// </summary>
	[Flags()]
	public enum FontTypes
	{
		/// <summary>
		/// Raster font.
		/// </summary>
		Raster = 1,
		/// <summary>
		/// Device font.
		/// </summary>
		Device = 2,
		/// <summary>
		/// Truetype font.
		/// </summary>
		TrueType = 4
	}

	/// <summary>
	/// Enumeration for messages sent by the joystick if captured.
	/// </summary>
	public enum JoystickMessages
	{
		/// <summary></summary>
		Joystick1Moved = 0x3A0,
		/// <summary></summary>
		Joystick2Moved = 0x3A1,
		/// <summary></summary>
		Joystick1ZMoved = 0x3A2,
		/// <summary></summary>
		Joystick2ZMoved = 0x3A3,
		/// <summary></summary>
		Joystick1ButtonDown = 0x3B5,
		/// <summary></summary>
		Joystick2ButtonDown = 0x3B6,
		/// <summary></summary>
		Joystick1ButtonUp = 0x3B7,
		/// <summary></summary>
		Joystick2ButtonUp =0x3B8
	}

	/// <summary>
	/// Enumeration containing joystick POV directions.
	/// </summary>
	public enum JoystickPOVDirections
	{
		/// <summary>Hat is pulled back.</summary>
		Back = 18000,
		/// <summary>Hat is centered.</summary>
		Centered = -1,
		/// <summary>Hat is pushed forward.</summary>
		Forward = 0,
		/// <summary>Hat is pushed left.</summary>
		Left = 27000,
		/// <summary>Hat is pushed right.</summary>
		Right = 9000
	}

	/// <summary>
	/// Enumeration containing the joystick information flags.
	/// </summary>
	[Flags()]
	public enum JoystickInfoFlags
	{
		/// <summary></summary>
		All = (ReturnX | ReturnY | ReturnZ | ReturnRudder | ReturnAxis5 | ReturnAxis6 | ReturnPOV | ReturnButtons),
		/// <summary></summary>
		ReturnX = 0x00000001,
		/// <summary></summary>
		ReturnY = 0x00000002,
		/// <summary></summary>
		ReturnZ = 0x00000004,
		/// <summary></summary>
		ReturnRudder = 0x00000008,
		/// <summary></summary>
		ReturnAxis5 = 0x00000010,
		/// <summary></summary>
		ReturnAxis6 = 0x00000020,
		/// <summary></summary>
		ReturnPOV = 0x00000040,
		/// <summary></summary>
		ReturnButtons = 0x00000080,
		/// <summary></summary>
		ReturnRawData = 0x00000100,
		/// <summary></summary>
		ReturnPOVContinuousDegreeBearings = 0x00000200,
		/// <summary></summary>
		ReturnCentered = 0x00000400,
		/// <summary></summary>
		UseDeadzone = 0x00000800,
		/// <summary></summary>
		CalibrationReadAlways = 0x00010000,
		/// <summary></summary>
		CalibrationReadXYOnly = 0x00020000,
		/// <summary></summary>
		CalibrationRead3 = 0x00040000,
		/// <summary></summary>
		CalibrationRead4 = 0x00080000,
		/// <summary></summary>
		CalibrationReadXOnly = 0x00100000,
		/// <summary></summary>
		CalibrationReadYOnly = 0x00200000,
		/// <summary></summary>
		CalibrationRead5 = 0x00400000,
		/// <summary></summary>
		CalibrationRead6 = 0x00800000,
		/// <summary></summary>
		CalibrationReadZOnly = 0x01000000,
		/// <summary></summary>
		CalibrationReadRudderOnly = 0x02000000,
		/// <summary></summary>
		CalibrationReadAxis5Only = 0x04000000,
		/// <summary></summary>
		CalibrationReadaxis6Only = 0x08000000
	}

	/// <summary>
	/// Enumeration for joystick buttons.
	/// </summary>
	public enum JoystickButtons
		: uint
	{
		/// <summary></summary>
		Button1 = 0x0001,
		/// <summary></summary>
		Button2 = 0x0002,
		/// <summary></summary>
		Button3 = 0x0003,
		/// <summary></summary>
		Button4 = 0x0004,
		/// <summary></summary>
		Button1Changed = 0x0100,
		/// <summary></summary>
		Button2Changed = 0x0200,
		/// <summary></summary>
		Button3Changed = 0x0400,
		/// <summary></summary>
		Button4Changed = 0x0800,
		/// <summary></summary>
		Button5 = 0x00000010,
		/// <summary></summary>
		Button6 = 0x00000020,
		/// <summary></summary>
		Button7 = 0x00000040,
		/// <summary></summary>
		Button8 = 0x00000080,
		/// <summary></summary>
		Button9 = 0x00000100,
		/// <summary></summary>
		Button10 = 0x00000200,
		/// <summary></summary>
		Button11 = 0x00000400,
		/// <summary></summary>
		Button12 = 0x00000800,
		/// <summary></summary>
		Button13 = 0x00001000,
		/// <summary></summary>
		Button14 = 0x00002000,
		/// <summary></summary>
		Button15 = 0x00004000,
		/// <summary></summary>
		Button16 = 0x00008000,
		/// <summary></summary>
		Button17 = 0x00010000,
		/// <summary></summary>
		Button18 = 0x00020000,
		/// <summary></summary>
		Button19 = 0x00040000,
		/// <summary></summary>
		Button20 = 0x00080000,
		/// <summary></summary>
		Button21 = 0x00100000,
		/// <summary></summary>
		Button22 = 0x00200000,
		/// <summary></summary>
		Button23 = 0x00400000,
		/// <summary></summary>
		Button24 = 0x00800000,
		/// <summary></summary>
		Button25 = 0x01000000,
		/// <summary></summary>
		Button26 = 0x02000000,
		/// <summary></summary>
		Button27 = 0x04000000,
		/// <summary></summary>
		Button28 = 0x08000000,
		/// <summary></summary>
		Button29 = 0x10000000,
		/// <summary></summary>
		Button30 = 0x20000000,
		/// <summary></summary>
		Button31 = 0x40000000,
		/// <summary></summary>
		Button32 = 0x80000000
	}

	/// <summary>
	/// Enumeration for joystick capabilities.
	/// </summary>
	[Flags()]
	public enum JoystickCapabilities
	{
		/// <summary>Has a Z axis.</summary>
		HasZ = 0x0001,
		/// <summary>Has a rudder axis.</summary>
		HasRudder = 0x0002,
		/// <summary>Has a 5th axis.</summary>
		HasU = 0x0004,
		/// <summary>Has a 6th axis.</summary>
		HasV = 0x0008,
		/// <summary>Has a POV hat.</summary>
		HasPOV = 0x0010,
		/// <summary>Has a 4 direction POV hat.</summary>
		POV4Directions = 0x0020,
		/// <summary>Has a continuous degree bearing POV hat.</summary>
		POVContinuousDegreeBearings = 0x0040
	}

	/// <summary>
	/// Enumeration containing HID usage page flags.
	/// </summary>
	public enum HIDUsagePage
		: ushort
	{
		/// <summary>Unknown usage page.</summary>
		Undefined = 0x00,
		/// <summary>Generic desktop controls.</summary>
		Generic = 0x01,
		/// <summary>Simulation controls.</summary>
		Simulation = 0x02,
		/// <summary>Virtual reality controls.</summary>
		VR = 0x03,
		/// <summary>Sports controls.</summary>
		Sport = 0x04,
		/// <summary>Games controls.</summary>
		Game = 0x05,
		/// <summary>Keyboard controls.</summary>
		Keyboard = 0x07,
		/// <summary>LED controls.</summary>
		LED = 0x08,
		/// <summary>Button.</summary>
		Button = 0x09,
		/// <summary>Ordinal.</summary>
		Ordinal = 0x0A,
		/// <summary>Telephony.</summary>
		Telephony = 0x0B,
		/// <summary>Consumer.</summary>
		Consumer = 0x0C,
		/// <summary>Digitizer.</summary>
		Digitizer = 0x0D,
		/// <summary>Physical interface device.</summary>
		PID = 0x0F,
		/// <summary>Unicode.</summary>
		Unicode = 0x10,
		/// <summary>Alphanumeric display.</summary>
		AlphaNumeric = 0x14,
		/// <summary>Medical instruments.</summary>
		Medical = 0x40,
		/// <summary>Monitor page 0.</summary>
		MonitorPage0 = 0x80,
		/// <summary>Monitor page 1.</summary>
		MonitorPage1 = 0x81,
		/// <summary>Monitor page 2.</summary>
		MonitorPage2 = 0x82,
		/// <summary>Monitor page 3.</summary>
		MonitorPage3 = 0x83,
		/// <summary>Power page 0.</summary>
		PowerPage0 = 0x84,
		/// <summary>Power page 1.</summary>
		PowerPage1 = 0x85,
		/// <summary>Power page 2.</summary>
		PowerPage2 = 0x86,
		/// <summary>Power page 3.</summary>
		PowerPage3 = 0x87,
		/// <summary>Bar code scanner.</summary>
		BarCode = 0x8C,
		/// <summary>Scale page.</summary>
		Scale = 0x8D,
		/// <summary>Magnetic strip reading devices.</summary>
		MSR = 0x8E
	}

	/// <summary>
	/// Constants for HID usage flags.
	/// </summary>
	public static class HIDUsage
	{
		/// <summary></summary>
		public const ushort Pointer = 0x01;
		/// <summary></summary>
		public const ushort Mouse = 0x02;
		/// <summary></summary>
		public const ushort Joystick = 0x04;
		/// <summary></summary>
		public const ushort Gamepad = 0x05;
		/// <summary></summary>
		public const ushort Keyboard = 0x06;
		/// <summary></summary>
		public const ushort Keypad = 0x07;
		/// <summary></summary>
		public const ushort SystemControl = 0x80;
		/// <summary></summary>
		public const ushort X = 0x30;
		/// <summary></summary>
		public const ushort Y = 0x31;
		/// <summary></summary>
		public const ushort Z = 0x32;
		/// <summary></summary>
		public const ushort RelativeX = 0x33;
		/// <summary></summary>		
		public const ushort RelativeY = 0x34;
		/// <summary></summary>
		public const ushort RelativeZ = 0x35;
		/// <summary></summary>
		public const ushort Slider = 0x36;
		/// <summary></summary>
		public const ushort Dial = 0x37;
		/// <summary></summary>
		public const ushort Wheel = 0x38;
		/// <summary></summary>
		public const ushort HatSwitch = 0x39;
		/// <summary></summary>
		public const ushort CountedBuffer = 0x3A;
		/// <summary></summary>
		public const ushort ByteCount = 0x3B;
		/// <summary></summary>
		public const ushort MotionWakeup = 0x3C;
		/// <summary></summary>
		public const ushort VX = 0x40;
		/// <summary></summary>
		public const ushort VY = 0x41;
		/// <summary></summary>
		public const ushort VZ = 0x42;
		/// <summary></summary>
		public const ushort VBRX = 0x43;
		/// <summary></summary>
		public const ushort VBRY = 0x44;
		/// <summary></summary>
		public const ushort VBRZ = 0x45;
		/// <summary></summary>
		public const ushort VNO = 0x46;
		/// <summary></summary>
		public const ushort SystemControlPower = 0x81;
		/// <summary></summary>
		public const ushort SystemControlSleep = 0x82;
		/// <summary></summary>
		public const ushort SystemControlWake = 0x83;
		/// <summary></summary>
		public const ushort SystemControlContextMenu = 0x84;
		/// <summary></summary>
		public const ushort SystemControlMainMenu = 0x85;
		/// <summary></summary>
		public const ushort SystemControlApplicationMenu = 0x86;
		/// <summary></summary>
		public const ushort SystemControlHelpMenu = 0x87;
		/// <summary></summary>
		public const ushort SystemControlMenuExit = 0x88;
		/// <summary></summary>
		public const ushort SystemControlMenuSelect = 0x89;
		/// <summary></summary>
		public const ushort SystemControlMenuRight = 0x8A;
		/// <summary></summary>
		public const ushort SystemControlMenuLeft = 0x8B;
		/// <summary></summary>
		public const ushort SystemControlMenuUp = 0x8C;
		/// <summary></summary>
		public const ushort SystemControlMenuDown = 0x8D;
		/// <summary></summary>
		public const ushort KeyboardNoEvent = 0x00;
		/// <summary></summary>
		public const ushort KeyboardRollover = 0x01;
		/// <summary></summary>
		public const ushort KeyboardPostFail = 0x02;
		/// <summary></summary>
		public const ushort KeyboardUndefined = 0x03;
		/// <summary></summary>
		public const ushort KeyboardaA = 0x04;
		/// <summary></summary>
		public const ushort KeyboardzZ = 0x1D;
		/// <summary></summary>
		public const ushort Keyboard1 = 0x1E;
		/// <summary></summary>
		public const ushort Keyboard0 = 0x27;
		/// <summary></summary>
		public const ushort KeyboardLeftControl = 0xE0;
		/// <summary></summary>
		public const ushort KeyboardLeftShift = 0xE1;
		/// <summary></summary>
		public const ushort KeyboardLeftALT = 0xE2;
		/// <summary></summary>
		public const ushort KeyboardLeftGUI = 0xE3;
		/// <summary></summary>
		public const ushort KeyboardRightControl = 0xE4;
		/// <summary></summary>
		public const ushort KeyboardRightShift = 0xE5;
		/// <summary></summary>
		public const ushort KeyboardRightALT = 0xE6;
		/// <summary></summary>
		public const ushort KeyboardRightGUI = 0xE7;
		/// <summary></summary>
		public const ushort KeyboardScrollLock = 0x47;
		/// <summary></summary>
		public const ushort KeyboardNumLock = 0x53;
		/// <summary></summary>
		public const ushort KeyboardCapsLock = 0x39;
		/// <summary></summary>
		public const ushort KeyboardF1 = 0x3A;
		/// <summary></summary>
		public const ushort KeyboardF12 = 0x45;
		/// <summary></summary>
		public const ushort KeyboardReturn = 0x28;
		/// <summary></summary>
		public const ushort KeyboardEscape = 0x29;
		/// <summary></summary>
		public const ushort KeyboardDelete = 0x2A;
		/// <summary></summary>
		public const ushort KeyboardPrintScreen = 0x46;
		/// <summary></summary>
		public const ushort LEDNumLock = 0x01;
		/// <summary></summary>
		public const ushort LEDCapsLock = 0x02;
		/// <summary></summary>
		public const ushort LEDScrollLock = 0x03;
		/// <summary></summary>
		public const ushort LEDCompose = 0x04;
		/// <summary></summary>
		public const ushort LEDKana = 0x05;
		/// <summary></summary>
		public const ushort LEDPower = 0x06;
		/// <summary></summary>
		public const ushort LEDShift = 0x07;
		/// <summary></summary>
		public const ushort LEDDoNotDisturb = 0x08;
		/// <summary></summary>
		public const ushort LEDMute = 0x09;
		/// <summary></summary>
		public const ushort LEDToneEnable = 0x0A;
		/// <summary></summary>
		public const ushort LEDHighCutFilter = 0x0B;
		/// <summary></summary>
		public const ushort LEDLowCutFilter = 0x0C;
		/// <summary></summary>
		public const ushort LEDEqualizerEnable = 0x0D;
		/// <summary></summary>
		public const ushort LEDSoundFieldOn = 0x0E;
		/// <summary></summary>
		public const ushort LEDSurroundFieldOn = 0x0F;
		/// <summary></summary>
		public const ushort LEDRepeat = 0x10;
		/// <summary></summary>
		public const ushort LEDStereo = 0x11;
		/// <summary></summary>
		public const ushort LEDSamplingRateDirect = 0x12;
		/// <summary></summary>
		public const ushort LEDSpinning = 0x13;
		/// <summary></summary>
		public const ushort LEDCAV = 0x14;
		/// <summary></summary>
		public const ushort LEDCLV = 0x15;
		/// <summary></summary>
		public const ushort LEDRecordingFormatDet = 0x16;
		/// <summary></summary>
		public const ushort LEDOffHook = 0x17;
		/// <summary></summary>
		public const ushort LEDRing = 0x18;
		/// <summary></summary>
		public const ushort LEDMessageWaiting = 0x19;
		/// <summary></summary>
		public const ushort LEDDataMode = 0x1A;
		/// <summary></summary>
		public const ushort LEDBatteryOperation = 0x1B;
		/// <summary></summary>
		public const ushort LEDBatteryOK = 0x1C;
		/// <summary></summary>
		public const ushort LEDBatteryLow = 0x1D;
		/// <summary></summary>
		public const ushort LEDSpeaker = 0x1E;
		/// <summary></summary>
		public const ushort LEDHeadset = 0x1F;
		/// <summary></summary>
		public const ushort LEDHold = 0x20;
		/// <summary></summary>
		public const ushort LEDMicrophone = 0x21;
		/// <summary></summary>
		public const ushort LEDCoverage = 0x22;
		/// <summary></summary>
		public const ushort LEDNightMode = 0x23;
		/// <summary></summary>
		public const ushort LEDSendCalls = 0x24;
		/// <summary></summary>
		public const ushort LEDCallPickup = 0x25;
		/// <summary></summary>
		public const ushort LEDConference = 0x26;
		/// <summary></summary>
		public const ushort LEDStandBy = 0x27;
		/// <summary></summary>
		public const ushort LEDCameraOn = 0x28;
		/// <summary></summary>
		public const ushort LEDCameraOff = 0x29;
		/// <summary></summary>		
		public const ushort LEDOnLine = 0x2A;
		/// <summary></summary>
		public const ushort LEDOffLine = 0x2B;
		/// <summary></summary>
		public const ushort LEDBusy = 0x2C;
		/// <summary></summary>
		public const ushort LEDReady = 0x2D;
		/// <summary></summary>
		public const ushort LEDPaperOut = 0x2E;
		/// <summary></summary>
		public const ushort LEDPaperJam = 0x2F;
		/// <summary></summary>
		public const ushort LEDRemote = 0x30;
		/// <summary></summary>
		public const ushort LEDForward = 0x31;
		/// <summary></summary>
		public const ushort LEDReverse = 0x32;
		/// <summary></summary>
		public const ushort LEDStop = 0x33;
		/// <summary></summary>
		public const ushort LEDRewind = 0x34;
		/// <summary></summary>
		public const ushort LEDFastForward = 0x35;
		/// <summary></summary>
		public const ushort LEDPlay = 0x36;
		/// <summary></summary>
		public const ushort LEDPause = 0x37;
		/// <summary></summary>
		public const ushort LEDRecord = 0x38;
		/// <summary></summary>
		public const ushort LEDError = 0x39;
		/// <summary></summary>
		public const ushort LEDSelectedIndicator = 0x3A;
		/// <summary></summary>
		public const ushort LEDInUseIndicator = 0x3B;
		/// <summary></summary>
		public const ushort LEDMultiModeIndicator = 0x3C;
		/// <summary></summary>
		public const ushort LEDIndicatorOn = 0x3D;
		/// <summary></summary>
		public const ushort LEDIndicatorFlash = 0x3E;
		/// <summary></summary>
		public const ushort LEDIndicatorSlowBlink = 0x3F;
		/// <summary></summary>
		public const ushort LEDIndicatorFastBlink = 0x40;
		/// <summary></summary>
		public const ushort LEDIndicatorOff = 0x41;
		/// <summary></summary>
		public const ushort LEDFlashOnTime = 0x42;
		/// <summary></summary>
		public const ushort LEDSlowBlinkOnTime = 0x43;
		/// <summary></summary>
		public const ushort LEDSlowBlinkOffTime = 0x44;
		/// <summary></summary>
		public const ushort LEDFastBlinkOnTime = 0x45;
		/// <summary></summary>
		public const ushort LEDFastBlinkOffTime = 0x46;
		/// <summary></summary>
		public const ushort LEDIndicatorColor = 0x47;
		/// <summary></summary>
		public const ushort LEDRed = 0x48;
		/// <summary></summary>
		public const ushort LEDGreen = 0x49;
		/// <summary></summary>
		public const ushort LEDAmber = 0x4A;
		/// <summary></summary>
		public const ushort LEDGenericIndicator = 0x3B;
		/// <summary></summary>
		public const ushort TelephonyPhone = 0x01;
		/// <summary></summary>
		public const ushort TelephonyAnsweringMachine = 0x02;
		/// <summary></summary>
		public const ushort TelephonyMessageControls = 0x03;
		/// <summary></summary>
		public const ushort TelephonyHandset = 0x04;
		/// <summary></summary>
		public const ushort TelephonyHeadset = 0x05;
		/// <summary></summary>
		public const ushort TelephonyKeypad = 0x06;
		/// <summary></summary>
		public const ushort TelephonyProgrammableButton = 0x07;
		/// <summary></summary>
		public const ushort SimulationRudder = 0xBA;
		/// <summary></summary>
		public const ushort SimulationThrottle = 0xBB;
	}

	/// <summary>
	/// Enumeration containing the flags for error message formatting.
	/// </summary>
	[Flags()]
	public enum ErrorFormattingFlags
	{
		/// <summary></summary>
		AllocateBuffer = 0x00000100,
		/// <summary></summary>
		IgnoreInserts = 0x00000200,
		/// <summary></summary>
		FromString = 0x00000400,
		/// <summary></summary>
		FromHModule = 0x00000800,
		/// <summary></summary>
		FromSystem = 0x00001000,
		/// <summary></summary>
		ArgumentArray = 0x00002000
	}


	/// <summary>
	/// Enumeration containing flags for a raw input device.
	/// </summary>
	[Flags()]
	public enum RawInputDeviceFlags
	{
		/// <summary>No flags.</summary>
		None = 0,
		/// <summary>If set, this removes the top level collection from the inclusion list. This tells the operating system to stop reading from a device which matches the top level collection.</summary>
		Remove = 0x00000001,
		/// <summary>If set, this specifies the top level collections to exclude when reading a complete usage page. This flag only affects a TLC whose usage page is already specified with PageOnly.</summary>
		Exclude = 0x00000010,
		/// <summary>If set, this specifies all devices whose top level collection is from the specified usUsagePage. Note that Usage must be zero. To exclude a particular top level collection, use Exclude.</summary>
		PageOnly = 0x00000020,
		/// <summary>If set, this prevents any devices specified by UsagePage or Usage from generating legacy messages. This is only for the mouse and keyboard.</summary>
		NoLegacy = 0x00000030,
		/// <summary>If set, this enables the caller to receive the input even when the caller is not in the foreground. Note that WindowHandle must be specified.</summary>
		InputSink = 0x00000100,
		/// <summary>If set, the mouse button click does not activate the other window.</summary>
		CaptureMouse = 0x00000200,
		/// <summary>If set, the application-defined keyboard device hotkeys are not handled. However, the system hotkeys; for example, ALT+TAB and CTRL+ALT+DEL, are still handled. By default, all keyboard hotkeys are handled. NoHotKeys can be specified even if NoLegacy is not specified and WindowHandle is NULL.</summary>
		NoHotKeys = 0x00000200,
		/// <summary>If set, application keys are handled.  NoLegacy must be specified.  Keyboard only.</summary>
		AppKeys = 0x00000400
	}

	/// <summary>
	/// Enumeration containing the type device the raw input is coming from.
	/// </summary>
	public enum RawInputType
	{
		/// <summary>
		/// Mouse input.
		/// </summary>
		Mouse = 0,
		/// <summary>
		/// Keyboard input.
		/// </summary>
		Keyboard = 1,
		/// <summary>
		/// Another device that is not the keyboard or the mouse.
		/// </summary>
		HID = 2
	}

	/// <summary>
	/// Enumeration containing the flags for raw mouse data.
	/// </summary>
	[Flags()]
	public enum RawMouseFlags
		: ushort
	{
		/// <summary>Relative to the last position.</summary>
		MoveRelative = 0,
		/// <summary>Absolute positioning.</summary>
		MoveAbsolute = 1,
		/// <summary>Coordinate data is mapped to a virtual desktop.</summary>
		VirtualDesktop = 2,
		/// <summary>Attributes for the mouse have changed.</summary>
		AttributesChanged = 4
	}

	/// <summary>
	/// Enumeration containing the button data for raw mouse input.
	/// </summary>
	[Flags()]
	public enum RawMouseButtons
		: ushort
	{
		/// <summary>No button.</summary>
		None = 0,
		/// <summary>Left (button 1) down.</summary>
		LeftDown = 0x0001,
		/// <summary>Left (button 1) up.</summary>
		LeftUp = 0x0002,
		/// <summary>Right (button 2) down.</summary>
		RightDown = 0x0004,
		/// <summary>Right (button 2) up.</summary>
		RightUp = 0x0008,
		/// <summary>Middle (button 3) down.</summary>
		MiddleDown = 0x0010,
		/// <summary>Middle (button 3) up.</summary>
		MiddleUp = 0x0020,
		/// <summary>Button 4 down.</summary>
		Button4Down = 0x0040,
		/// <summary>Button 4 up.</summary>
		Button4Up = 0x0080,
		/// <summary>Button 5 down.</summary>
		Button5Down = 0x0100,
		/// <summary>Button 5 up.</summary>
		Button5Up = 0x0200,
		/// <summary>Mouse wheel moved.</summary>
		MouseWheel = 0x0400
	}

	/// <summary>
	/// Enumeration containing flags for raw keyboard input.
	/// </summary>
	[Flags()]
	public enum RawKeyboardFlags
		: ushort
	{
		/// <summary></summary>
		KeyMake = 0,
		/// <summary></summary>
		KeyBreak = 1,
		/// <summary></summary>
		KeyE0 = 2,
		/// <summary></summary>
		KeyE1 = 4,
		/// <summary></summary>
		TerminalServerSetLED = 8,
		/// <summary></summary>
		TerminalServerShadow = 0x10
	}

	/// <summary>
	/// Enumeration contanining the command types to issue.
	/// </summary>
	public enum RawInputCommand
	{
		/// <summary>
		/// Get input data.
		/// </summary>
		Input = 0x10000003,
		/// <summary>
		/// Get header data.
		/// </summary>
		Header = 0x10000005,
		/// <summary>
		/// Previously parsed data.
		/// </summary>
		PreparsedData = 0x20000005,
		/// <summary>
		/// Only return the device name, return value means number of characters, not bytes.
		/// </summary>
		DeviceName = 0x20000007,
		/// <summary>
		/// Return RAWINPUTDEVICEINFO data.
		/// </summary>
		DeviceInfo =0x2000000B
	}

	/// <summary>
	/// Enumeration for virtual keys.
	/// </summary>
	public enum VirtualKeys
		: ushort
	{
		/// <summary>Key: None</summary>
		None = 0x0000,
		/// <summary>Key: LButton</summary>
		LButton = 0x0001,
		/// <summary>Key: RButton</summary>
		RButton = 0x0002,
		/// <summary>Key: Cancel</summary>
		Cancel = 0x0003,
		/// <summary>Key: MButton</summary>
		MButton = 0x0004,
		/// <summary>Key: XButton1</summary>
		XButton1 = 0x0005,
		/// <summary>Key: XButton2</summary>
		XButton2 = 0x0006,
		/// <summary>Key: Back</summary>
		Back = 0x0008,
		/// <summary>Key: Tab</summary>
		Tab = 0x0009,
		/// <summary>Key: LineFeed</summary>
		LineFeed = 0x000A,
		/// <summary>Key: Clear</summary>
		Clear = 0x000C,
		/// <summary>Key: Enter</summary>
		Enter = 0x000D,
		/// <summary>Key: Return</summary>
		Return = 0x000D,
		/// <summary>Key: ShiftKey</summary>
		ShiftKey = 0x0010,
		/// <summary>Key: ControlKey</summary>
		ControlKey = 0x0011,
		/// <summary>Key: Menu</summary>
		Menu = 0x0012,
		/// <summary>Key: Pause</summary>
		Pause = 0x0013,
		/// <summary>Key: CapsLock</summary>
		CapsLock = 0x0014,
		/// <summary>Key: Capital</summary>
		Capital = 0x0014,
		/// <summary>Key: HangulMode</summary>
		HangulMode = 0x0015,
		/// <summary>Key: HanguelMode</summary>
		HanguelMode = 0x0015,
		/// <summary>Key: KanaMode</summary>
		KanaMode = 0x0015,
		/// <summary>Key: JunjaMode</summary>
		JunjaMode = 0x0017,
		/// <summary>Key: FinalMode</summary>
		FinalMode = 0x0018,
		/// <summary>Key: KanjiMode</summary>
		KanjiMode = 0x0019,
		/// <summary>Key: HanjaMode</summary>
		HanjaMode = 0x0019,
		/// <summary>Key: Escape</summary>
		Escape = 0x001B,
		/// <summary>Key: IMEConvert</summary>
		IMEConvert = 0x001C,
		/// <summary>Key: IMENonconvert</summary>
		IMENonconvert = 0x001D,
		/// <summary>Key: IMEAccept</summary>
		IMEAccept = 0x001E,
		/// <summary>Key: IMEAceept</summary>
		IMEAceept = 0x001E,
		/// <summary>Key: IMEModeChange</summary>
		IMEModeChange = 0x001F,
		/// <summary>Key: Space</summary>
		Space = 0x0020,
		/// <summary>Key: Prior</summary>
		Prior = 0x0021,
		/// <summary>Key: PageUp</summary>
		PageUp = 0x0021,
		/// <summary>Key: PageDown</summary>
		PageDown = 0x0022,
		/// <summary>Key: Next</summary>
		Next = 0x0022,
		/// <summary>Key: End</summary>
		End = 0x0023,
		/// <summary>Key: Home</summary>
		Home = 0x0024,
		/// <summary>Key: Left</summary>
		Left = 0x0025,
		/// <summary>Key: Up</summary>
		Up = 0x0026,
		/// <summary>Key: Right</summary>
		Right = 0x0027,
		/// <summary>Key: Down</summary>
		Down = 0x0028,
		/// <summary>Key: Select</summary>
		Select = 0x0029,
		/// <summary>Key: Print</summary>
		Print = 0x002A,
		/// <summary>Key: Execute</summary>
		Execute = 0x002B,
		/// <summary>Key: Snapshot</summary>
		Snapshot = 0x002C,
		/// <summary>Key: PrintScreen</summary>
		PrintScreen = 0x002C,
		/// <summary>Key: Insert</summary>
		Insert = 0x002D,
		/// <summary>Key: Delete</summary>
		Delete = 0x002E,
		/// <summary>Key: Help</summary>
		Help = 0x002F,
		/// <summary>Key: D0</summary>
		D0 = 0x0030,
		/// <summary>Key: D1</summary>
		D1 = 0x0031,
		/// <summary>Key: D2</summary>
		D2 = 0x0032,
		/// <summary>Key: D3</summary>
		D3 = 0x0033,
		/// <summary>Key: D4</summary>
		D4 = 0x0034,
		/// <summary>Key: D5</summary>
		D5 = 0x0035,
		/// <summary>Key: D6</summary>
		D6 = 0x0036,
		/// <summary>Key: D7</summary>
		D7 = 0x0037,
		/// <summary>Key: D8</summary>
		D8 = 0x0038,
		/// <summary>Key: D9</summary>
		D9 = 0x0039,
		/// <summary>Key: A</summary>
		A = 0x0041,
		/// <summary>Key: B</summary>
		B = 0x0042,
		/// <summary>Key: C</summary>
		C = 0x0043,
		/// <summary>Key: D</summary>
		D = 0x0044,
		/// <summary>Key: E</summary>
		E = 0x0045,
		/// <summary>Key: F</summary>
		F = 0x0046,
		/// <summary>Key: G</summary>
		G = 0x0047,
		/// <summary>Key: H</summary>
		H = 0x0048,
		/// <summary>Key: I</summary>
		I = 0x0049,
		/// <summary>Key: J</summary>
		J = 0x004A,
		/// <summary>Key: K</summary>
		K = 0x004B,
		/// <summary>Key: L</summary>
		L = 0x004C,
		/// <summary>Key: M</summary>
		M = 0x004D,
		/// <summary>Key: N</summary>
		N = 0x004E,
		/// <summary>Key: O</summary>
		O = 0x004F,
		/// <summary>Key: P</summary>
		P = 0x0050,
		/// <summary>Key: Q</summary>
		Q = 0x0051,
		/// <summary>Key: R</summary>
		R = 0x0052,
		/// <summary>Key: S</summary>
		S = 0x0053,
		/// <summary>Key: T</summary>
		T = 0x0054,
		/// <summary>Key: U</summary>
		U = 0x0055,
		/// <summary>Key: V</summary>
		V = 0x0056,
		/// <summary>Key: W</summary>
		W = 0x0057,
		/// <summary>Key: X</summary>
		X = 0x0058,
		/// <summary>Key: Y</summary>
		Y = 0x0059,
		/// <summary>Key: Z</summary>
		Z = 0x005A,
		/// <summary>Key: LWin</summary>
		LWin = 0x005B,
		/// <summary>Key: RWin</summary>
		RWin = 0x005C,
		/// <summary>Key: Apps</summary>
		Apps = 0x005D,
		/// <summary>Key: Sleep</summary>
		Sleep = 0x005F,
		/// <summary>Key: NumPad0</summary>
		NumPad0 = 0x0060,
		/// <summary>Key: NumPad1</summary>
		NumPad1 = 0x0061,
		/// <summary>Key: NumPad2</summary>
		NumPad2 = 0x0062,
		/// <summary>Key: NumPad3</summary>
		NumPad3 = 0x0063,
		/// <summary>Key: NumPad4</summary>
		NumPad4 = 0x0064,
		/// <summary>Key: NumPad5</summary>
		NumPad5 = 0x0065,
		/// <summary>Key: NumPad6</summary>
		NumPad6 = 0x0066,
		/// <summary>Key: NumPad7</summary>
		NumPad7 = 0x0067,
		/// <summary>Key: NumPad8</summary>
		NumPad8 = 0x0068,
		/// <summary>Key: NumPad9</summary>
		NumPad9 = 0x0069,
		/// <summary>Key: Multiply</summary>
		Multiply = 0x006A,
		/// <summary>Key: Add</summary>
		Add = 0x006B,
		/// <summary>Key: Separator</summary>
		Separator = 0x006C,
		/// <summary>Key: Subtract</summary>
		Subtract = 0x006D,
		/// <summary>Key: Decimal</summary>
		Decimal = 0x006E,
		/// <summary>Key: Divide</summary>
		Divide = 0x006F,
		/// <summary>Key: F1</summary>
		F1 = 0x0070,
		/// <summary>Key: F2</summary>
		F2 = 0x0071,
		/// <summary>Key: F3</summary>
		F3 = 0x0072,
		/// <summary>Key: F4</summary>
		F4 = 0x0073,
		/// <summary>Key: F5</summary>
		F5 = 0x0074,
		/// <summary>Key: F6</summary>
		F6 = 0x0075,
		/// <summary>Key: F7</summary>
		F7 = 0x0076,
		/// <summary>Key: F8</summary>
		F8 = 0x0077,
		/// <summary>Key: F9</summary>
		F9 = 0x0078,
		/// <summary>Key: F10</summary>
		F10 = 0x0079,
		/// <summary>Key: F11</summary>
		F11 = 0x007A,
		/// <summary>Key: F12</summary>
		F12 = 0x007B,
		/// <summary>Key: F13</summary>
		F13 = 0x007C,
		/// <summary>Key: F14</summary>
		F14 = 0x007D,
		/// <summary>Key: F15</summary>
		F15 = 0x007E,
		/// <summary>Key: F16</summary>
		F16 = 0x007F,
		/// <summary>Key: F17</summary>
		F17 = 0x0080,
		/// <summary>Key: F18</summary>
		F18 = 0x0081,
		/// <summary>Key: F19</summary>
		F19 = 0x0082,
		/// <summary>Key: F20</summary>
		F20 = 0x0083,
		/// <summary>Key: F21</summary>
		F21 = 0x0084,
		/// <summary>Key: F22</summary>
		F22 = 0x0085,
		/// <summary>Key: F23</summary>
		F23 = 0x0086,
		/// <summary>Key: F24</summary>
		F24 = 0x0087,
		/// <summary>Key: NumLock</summary>
		NumLock = 0x0090,
		/// <summary>Key: Scroll</summary>
		Scroll = 0x0091,
		/// <summary>Key: LShiftKey</summary>
		LShiftKey = 0x00A0,
		/// <summary>Key: RShiftKey</summary>
		RShiftKey = 0x00A1,
		/// <summary>Key: LControlKey</summary>
		LControlKey = 0x00A2,
		/// <summary>Key: RControlKey</summary>
		RControlKey = 0x00A3,
		/// <summary>Key: LMenu</summary>
		LMenu = 0x00A4,
		/// <summary>Key: RMenu</summary>
		RMenu = 0x00A5,
		/// <summary>Key: BrowserBack</summary>
		BrowserBack = 0x00A6,
		/// <summary>Key: BrowserForward</summary>
		BrowserForward = 0x00A7,
		/// <summary>Key: BrowserRefresh</summary>
		BrowserRefresh = 0x00A8,
		/// <summary>Key: BrowserStop</summary>
		BrowserStop = 0x00A9,
		/// <summary>Key: BrowserSearch</summary>
		BrowserSearch = 0x00AA,
		/// <summary>Key: BrowserFavorites</summary>
		BrowserFavorites = 0x00AB,
		/// <summary>Key: BrowserHome</summary>
		BrowserHome = 0x00AC,
		/// <summary>Key: VolumeMute</summary>
		VolumeMute = 0x00AD,
		/// <summary>Key: VolumeDown</summary>
		VolumeDown = 0x00AE,
		/// <summary>Key: VolumeUp</summary>
		VolumeUp = 0x00AF,
		/// <summary>Key: MediaNextTrack</summary>
		MediaNextTrack = 0x00B0,
		/// <summary>Key: MediaPreviousTrack</summary>
		MediaPreviousTrack = 0x00B1,
		/// <summary>Key: MediaStop</summary>
		MediaStop = 0x00B2,
		/// <summary>Key: MediaPlayPause</summary>
		MediaPlayPause = 0x00B3,
		/// <summary>Key: LaunchMail</summary>
		LaunchMail = 0x00B4,
		/// <summary>Key: SelectMedia</summary>
		SelectMedia = 0x00B5,
		/// <summary>Key: LaunchApplication1</summary>
		LaunchApplication1 = 0x00B6,
		/// <summary>Key: LaunchApplication2</summary>
		LaunchApplication2 = 0x00B7,
		/// <summary>Key: OemSemicolon</summary>
		OemSemicolon = 0x00BA,
		/// <summary>Key: Oem1</summary>
		Oem1 = 0x00BA,
		/// <summary>Key: Oemplus</summary>
		Oemplus = 0x00BB,
		/// <summary>Key: Oemcomma</summary>
		Oemcomma = 0x00BC,
		/// <summary>Key: OemMinus</summary>
		OemMinus = 0x00BD,
		/// <summary>Key: OemPeriod</summary>
		OemPeriod = 0x00BE,
		/// <summary>Key: Oem2</summary>
		Oem2 = 0x00BF,
		/// <summary>Key: OemQuestion</summary>
		OemQuestion = 0x00BF,
		/// <summary>Key: Oem3</summary>
		Oem3 = 0x00C0,
		/// <summary>Key: Oemtilde</summary>
		Oemtilde = 0x00C0,
		/// <summary>Key: Oem4</summary>
		Oem4 = 0x00DB,
		/// <summary>Key: OemOpenBrackets</summary>
		OemOpenBrackets = 0x00DB,
		/// <summary>Key: OemPipe</summary>
		OemPipe = 0x00DC,
		/// <summary>Key: Oem5</summary>
		Oem5 = 0x00DC,
		/// <summary>Key: OemCloseBrackets</summary>
		OemCloseBrackets = 0x00DD,
		/// <summary>Key: Oem6</summary>
		Oem6 = 0x00DD,
		/// <summary>Key: OemQuotes</summary>
		OemQuotes = 0x00DE,
		/// <summary>Key: Oem7</summary>
		Oem7 = 0x00DE,
		/// <summary>Key: Oem8</summary>
		Oem8 = 0x00DF,
		/// <summary>Key: Oem102</summary>
		Oem102 = 0x00E2,
		/// <summary>Key: OemBackslash</summary>
		OemBackslash = 0x00E2,
		/// <summary>Key: ProcessKey</summary>
		ProcessKey = 0x00E5,
		/// <summary>Key: Packet</summary>
		Packet = 0x00E7,
		/// <summary>Key: Attn</summary>
		Attn = 0x00F6,
		/// <summary>Key: Crsel</summary>
		Crsel = 0x00F7,
		/// <summary>Key: Exsel</summary>
		Exsel = 0x00F8,
		/// <summary>Key: EraseEof</summary>
		EraseEof = 0x00F9,
		/// <summary>Key: Play</summary>
		Play = 0x00FA,
		/// <summary>Key: Zoom</summary>
		Zoom = 0x00FB,
		/// <summary>Key: NoName</summary>
		NoName = 0x00FC,
		/// <summary>Key: Pa1</summary>
		Pa1 = 0x00FD,
		/// <summary>Key: OemClear</summary>
		OemClear = 0x00FE,
		/// <summary>Key: KeyCode</summary>
		KeyCode = 0xFFFF,
		/// <summary>Key: Shift</summary>
		Shift = 0x0000,
		/// <summary>Key: Control</summary>
		Control = 0x0000,
		/// <summary>Key: Alt</summary>
		Alt = 0x0000,
		/// <summary>Key: Modifiers</summary>
		Modifiers = 0x0000
	}

	/// <summary>
	/// Enumeration for font weights.
	/// </summary>
	public enum FontWeight
	{
		/// <summary>
		/// </summary>
		DontCare = 0,
		/// <summary>
		/// 
		/// </summary>
		Thin = 100,
		/// <summary>
		/// 
		/// </summary>
		ExtraLight = 200,
		/// <summary>
		/// 
		/// </summary>
		Light = 300,
		/// <summary>
		/// 
		/// </summary>
		Normal = 400,
		/// <summary>
		/// 
		/// </summary>
		Medium = 500,
		/// <summary>
		/// 
		/// </summary>
		SemiBold = 600,
		/// <summary>
		/// 
		/// </summary>
		Bold = 700,
		/// <summary>
		/// 
		/// </summary>
		ExtraBold = 800,
		/// <summary>
		/// 
		/// </summary>
		Heavy = 900
	}

	/// <summary>
	/// Enumeration for font output precision.
	/// </summary>
	public enum FontOutputPrecision
	{
		/// <summary>
		/// 
		/// </summary>
		Default = 0,
		/// <summary>
		/// 
		/// </summary>
		String = 1,
		/// <summary>
		/// 
		/// </summary>
		Character = 2,
		/// <summary>
		/// 
		/// </summary>
		Stroke = 3,
		/// <summary>
		/// 
		/// </summary>
		TrueType = 4,
		/// <summary>
		/// 
		/// </summary>
		Device = 5,
		/// <summary>
		/// 
		/// </summary>
		Raster = 6,
		/// <summary>
		/// 
		/// </summary>
		TrueTypeOnly = 7,
		/// <summary>
		/// 
		/// </summary>
		Outline = 8,
		/// <summary>
		/// 
		/// </summary>
		ScreenOutline = 9,
		/// <summary>
		/// 
		/// </summary>
		PostscriptOnly = 10
	}

	/// <summary>
	/// Enumeration for clipping precision.
	/// </summary>
	public enum FontClippingPrecision
		: byte
	{
		/// <summary>
		/// 
		/// </summary>
		Default = 0,
		/// <summary>
		/// 
		/// </summary>
		Character = 1,
		/// <summary>
		/// 
		/// </summary>
		Stroke = 2,
		/// <summary>
		/// 
		/// </summary>
		Mask = 0xF,
		/// <summary>
		/// 
		/// </summary>
		LeftHandAngles = 1 << 4,
		/// <summary>
		/// 
		/// </summary>
		TrueTypeAlways = 2 << 4,
		/// <summary>
		/// 
		/// </summary>
		DisableFontAssociation = 4 << 4,
		/// <summary>
		/// 
		/// </summary>
		Embedded = 8 << 4
	}

	/// <summary>
	/// Enumeration for font quality.
	/// </summary>
	public enum FontQuality
		: byte
	{
		/// <summary>
		/// 
		/// </summary>
		Default = 0,
		/// <summary>
		/// 
		/// </summary>
		Draft = 1,
		/// <summary>
		/// 
		/// </summary>
		Proof = 2,
		/// <summary>
		/// 
		/// </summary>
		NonAntialiased = 3,
		/// <summary>
		/// 
		/// </summary>
		AntiAliased = 4,
		/// <summary>
		/// 
		/// </summary>
		ClearType = 5,
		/// <summary>
		/// 
		/// </summary>
		ClearTypeNatural = 6
	}

	/// <summary>
	/// Enumeration for system metrics.
	/// </summary>
	public enum SystemMetrics
	{
		/// <summary>
		/// Screen width.
		/// </summary>		
		ScreenWidth = 0,
		/// <summary>
		/// Screen height.
		/// </summary>
		ScreenHeight = 1,
		/// <summary>
		/// Width in pixels of the arrow bitmap on the vertical scrollbar.
		/// </summary>
		VerticalScrollbarArrowWidth = 2,
		/// <summary>
		/// Height of a horizontal scroll bar, in pixels.
		/// </summary>
		HorizontalScrollbarHeight = 3,
		/// <summary>
		/// Height, in pixels, of a normal caption area.
		/// </summary>
		CaptionHeight = 4,
		/// <summary>
		/// Width, in pixels, of a window border. This is equivalent to the SM_CXEDGE value for windows with the 3-D look.
		/// </summary>
		BorderWidth = 5,
		/// <summary>
		/// Height, in pixels, of a window border. This is equivalent to the SM_CXEDGE value for windows with the 3-D look.
		/// </summary>
		BorderHeight = 6,
		/// <summary>
		/// Same as FixedFrameThicknessWidth.
		/// </summary>
		DialogFrameThicknessWidth = 7,
		/// <summary>
		/// Same as FixedFrameThicknessHeight.
		/// </summary>
		DialogFrameThicknessHeight = 8,
		/// <summary>
		/// Height of the thumb box in a vertical scroll bar, in pixels.
		/// </summary>
		VerticalThumbBoxHeight = 9,
		/// <summary>
		/// Width of the thumb box in a horizontal scroll bar, in pixels.
		/// </summary>
		HorizontalThumbBoxWidth = 10,
		/// <summary>
		/// Default width of an icon, in pixels. 
		/// </summary>
		DefaultIconWidth = 11,
		/// <summary>
		/// Default height of an icon, in pixels.
		/// </summary>
		DefaultIconHeight = 12,
		/// <summary>
		/// Width of a cursor, in pixels. The system cannot create cursors of other sizes.
		/// </summary>
		CursorWidth = 13,
		/// <summary>
		/// Height of a cursor, in pixels. The system cannot create cursors of other sizes.
		/// </summary>
		CursorHeight = 14,
		/// <summary>
		/// Height of a single-line menu bar, in pixels.
		/// </summary>
		SingleLineMenuHeight = 15,
		/// <summary>
		/// Width of the client area for a full-screen window on the primary display monitor, in pixels. 
		/// </summary>
		FullScreenWidth = 16,
		/// <summary>
		/// Height of the client area for a full-screen window on the primary display monitor, in pixels. 
		/// </summary>
		FullScreenHeight = 17,
		/// <summary>
		/// For double byte character set versions of the system, this is the height of the Kanji window at the bottom of the screen, in pixels.
		/// </summary>
		KanjiWindowHeight = 18,
		/// <summary>
		/// Nonzero if a mouse is installed; zero otherwise. This value is rarely zero, because of support for virtual mice and because some systems detect the presence of the port instead of the presence of a mouse.
		/// </summary>
		MousePresent = 19,
		/// <summary>
		/// Width of a vertical scroll bar, in pixels.
		/// </summary>
		VerticalScrollbarWidth = 20,
		/// <summary>
		/// Width of the arrow bitmap on a horizontal scroll bar, in pixels.
		/// </summary>
		HorizontalScrollbarArrowWidth = 21,
		/// <summary>
		/// Nonzero if the debug version of User.exe is installed; zero otherwise.
		/// </summary>
		DebugUser = 22,
		/// <summary>
		/// Nonzero if the meanings of the left and right mouse buttons are swapped; zero otherwise.
		/// </summary>
		MouseButtonsSwapped = 23,
		/// <summary>
		/// Minimum width of a window, in pixels.
		/// </summary>
		MinimumWindowWidth = 28,
		/// <summary>
		/// Minimum height of a window, in pixels.
		/// </summary>
		MinimumWindowHeight = 29,
		/// <summary>
		/// Width of a button in a window's caption or title bar, in pixels.
		/// </summary>
		CaptionButtonWidth = 30,
		/// <summary>
		/// Height of a button in a window's caption or title bar, in pixels.
		/// </summary>
		CaptionButtonHeight = 31,
		/// <summary>
		/// Thickness of the sizing border around the perimeter of a window that can be resized, in pixels. 
		/// </summary>
		WindowBorderThicknessWidth = 32,
		/// <summary>
		/// Thickness of the sizing border around the perimeter of a window that can be resized, in pixels.
		/// </summary>
		WindowBorderThicknessHeight = 33,
		/// <summary>
		/// Minimum tracking width of a window, in pixels. The user cannot drag the window frame to a size smaller than these dimensions. 
		/// </summary>
		MinimumTrackingWidth = 34,
		/// <summary>
		/// Minimum tracking height of a window, in pixels. The user cannot drag the window frame to a size smaller than these dimensions. 
		/// </summary>
		MinimumTrackingHeight = 35,
		/// <summary>
		/// Width of the rectangle around the location of a first click in a double-click sequence, in pixels. 
		/// </summary>
		DoubleClickRegionWidth = 36,
		/// <summary>
		/// Height of the rectangle around the location of a first click in a double-click sequence, in pixels. 
		/// </summary>
		DoubleClickRegionHeight = 37,
		/// <summary>
		/// Width of a grid cell for items in large icon view, in pixels
		/// </summary>
		IconHorizontalSpacing = 38,
		/// <summary>
		/// Height of a grid cell for items in large icon view, in pixels
		/// </summary>		
		IconVerticalSpacing = 39,
		/// <summary>
		/// Nonzero if drop-down menus are right-aligned with the corresponding menu-bar item; zero if the menus are left-aligned.
		/// </summary>
		MenuDropAlignment = 40,
		/// <summary>
		/// Nonzero if the Microsoft Windows for Pen computing extensions are installed; zero otherwise.
		/// </summary>
		PenWindows = 41,
		/// <summary>
		/// Nonzero if User32.dll supports DBCS; zero otherwise. 
		/// </summary>
		DBCSEnabled = 42,
		/// <summary>
		/// Number of buttons on mouse, or zero if no mouse is installed.
		/// </summary>
		MouseButtonCount = 43,
		/// <summary>
		/// Same as DialogFrameThicknessWidth.
		/// </summary>
		FixedFrameWidth = DialogFrameThicknessWidth,
		/// <summary>
		/// Same as DialogFrameThicknessHeight.
		/// </summary>
		FixedFrameHeight = DialogFrameThicknessHeight,
		/// <summary>
		/// Same as WindowBorderThicknessWidth.
		/// </summary>
		SizingBorderWidth = WindowBorderThicknessWidth,
		/// <summary>
		/// Same as WindowBorderThicknessHeight.
		/// </summary>
		SizingBorderHeight = WindowBorderThicknessHeight,
		/// <summary>
		/// Nonzero if security is present; zero otherwise.
		/// </summary>
		SecurityPresent = 44,
		/// <summary>
		/// Width of a 3-D border, in pixels.
		/// </summary>
		EdgeWidth = 45,
		/// <summary>
		/// Height of a 3-D border, in pixels.
		/// </summary>
		EdgeHeight = 46,
		/// <summary>
		/// Width of a grid cell for a minimized window, in pixels.
		/// </summary>
		MinimizedSpacingWidth = 47,
		/// <summary>
		/// Height of a grid cell for a minimized window, in pixels.
		/// </summary>
		MinimizedSpacingHeight = 48,
		/// <summary>
		/// Default width of a small icon.
		/// </summary>
		SmallIconWidth = 49,
		/// <summary>
		/// Default height of a small icon.
		/// </summary>
		SmallIconHeight = 50,
		/// <summary>
		/// Height of a small caption, in pixels.
		/// </summary>
		SmallCaptionHeight = 51,
		/// <summary>
		/// Width of small caption buttons, in pixels.
		/// </summary>
		SmallCaptionButtonsWidth = 52,
		/// <summary>
		/// Height of small caption buttons, in pixels.
		/// </summary>
		SmallCaptionButtonsHeight = 53,
		/// <summary>
		/// Width of menu bar buttons, such as the child window close button used in the multiple document interface, in pixels.
		/// </summary>
		MenuBarButtonWidth = 54,
		/// <summary>
		/// Height of menu bar buttons, such as the child window close button used in the multiple document interface, in pixels.
		/// </summary>
		MenuBarButtonHeight = 55,
		/// <summary>
		/// Flags specifying how the system arranged minimized windows.
		/// </summary>
		ArrangementFlags = 56,
		/// <summary>
		/// Width of a minimized window, in pixels.
		/// </summary>
		MinimizedWindowWidth = 57,
		/// <summary>
		/// Height of a minimized window, in pixels.
		/// </summary>
		MinimizedWindowHeight = 58,
		/// <summary>
		/// Default maximum width of a window that has a caption and sizing borders, in pixels. 
		/// </summary>
		MaximumTrackingWidth = 59,
		/// <summary>
		/// Default maximum height of a window that has a caption and sizing borders, in pixels. 
		/// </summary>
		MaximumTrackingHeight = 60,
		/// <summary>
		/// Default width, in pixels, of a maximized top-level window on the primary display monitor.
		/// </summary>
		MaximizedTopLevelWidth = 61,
		/// <summary>
		/// Default height, in pixels, of a maximized top-level window on the primary display monitor.
		/// </summary>
		MaximizedTopLevelHeight = 62,
		/// <summary>
		/// Least significant bit is set if a network is present; otherwise, it is cleared. The other bits are reserved for future use.
		/// </summary>
		NetworkPresent = 63,
		/// <summary>
		/// Value that specifies how the system was started: 
		///	0 Normal boot 
		///	1 Fail-safe boot 
		///	2 Fail-safe with network boot 
		///	Fail-safe boot (also called SafeBoot, Safe Mode, or Clean Boot) bypasses the user's startup files.
		/// </summary>
		CleanBoot = 67,
		/// <summary>
		/// Width of a rectangle centered on a drag point to allow for limited movement of the mouse pointer before a drag operation begins, in pixels. It allows the user to click and release the mouse button easily without unintentionally starting a drag operation.
		/// </summary>
		DragRectangleWidth = 68,
		/// <summary>
		/// Height of a rectangle centered on a drag point to allow for limited movement of the mouse pointer before a drag operation begins, in pixels. It allows the user to click and release the mouse button easily without unintentionally starting a drag operation.
		/// </summary>
		DragRectangleHeight = 69,
		/// <summary>
		/// Nonzero if the user requires an application to present information visually in situations where it would otherwise present the information only in audible form; zero otherwise. 
		/// </summary>
		ShowSounds = 70,
		/// <summary>
		/// Width of the default menu check-mark bitmap, in pixels.
		/// </summary>
		MenuCheckMarkBitmapWidth = 71,
		/// <summary>
		/// Height of the default menu check-mark bitmap, in pixels.
		/// </summary>
		MenuCheckMarkBitmapHeight = 72,
		/// <summary>
		/// Nonzero if the computer has a low-end (slow) processor; zero otherwise.
		/// </summary>
		SlowMachine = 73,
		/// <summary>
		/// Nonzero if the system is enabled for Hebrew and Arabic languages, zero if not.
		/// </summary>
		MiddleEastEnabled = 74,
		/// <summary>
		/// Nonzero if a mouse with a wheel is installed; zero otherwise. 
		/// </summary>
		MouseWheelPresent = 75,
		/// <summary>
		/// Coordinates for the left side of the virtual screen. The virtual screen is the bounding rectangle of all display monitors. 
		/// </summary>
		VirtualScreenLeft = 76,
		/// <summary>
		/// Coordinates for the top side of the virtual screen. The virtual screen is the bounding rectangle of all display monitors. 
		/// </summary>
		VirtualScreenTop = 77,
		/// <summary>
		/// Width of the virtual screen, in pixels. The virtual screen is the bounding rectangle of all display monitors.
		/// </summary>
		VirtualScreenWidth = 78,
		/// <summary>
		/// Height of the virtual screen, in pixels. The virtual screen is the bounding rectangle of all display monitors.
		/// </summary>
		VirtualScreenHeight = 79,
		/// <summary>
		/// Number of display monitors on the desktop.
		/// </summary>
		MonitorCount = 80,
		/// <summary>
		/// Nonzero if all the display monitors have the same color format, zero otherwise. Note that two displays can have the same bit depth, but different color formats. 
		/// </summary>
		SameDisplayFormat = 81,
		/// <summary>
		/// Nonzero if Input Method Manager/Input Method Editor features are enabled; zero otherwise. 
		/// </summary>
		InputMethodManagedEnabled = 82,
		/// <summary>
		/// Width of the left and right edges of the focus rectangle drawn by DrawFocusRect. This value is in pixels. 
		/// </summary>
		FocusBorderWidth = 83,
		/// <summary>
		/// Height of the left and right edges of the focus rectangle drawn by DrawFocusRect. This value is in pixels. 
		/// </summary>
		FocusBorderHeight = 84,
		/// <summary>
		/// Nonzero if the current operating system is the Windows XP Tablet PC edition, zero if not.
		/// </summary>
		TabletPC = 86,
		/// <summary>
		/// Nonzero if the current operating system is the Windows XP, Media Center Edition, zero if not.
		/// </summary>
		MediaCenter = 87,
		/// <summary>
		/// This system metric is used in a Terminal Services environment. If the calling process is associated with a Terminal Services client session, the return value is nonzero. If the calling process is associated with the Terminal Server console session, the return value is zero. 
		/// </summary>
		RemoteSession = 0x1000,
		/// <summary>
		/// Nonzero if the current session is shutting down; zero otherwise. 
		/// </summary>
		ShuttingDown = 0x2000,
		/// <summary>
		/// This system metric is used in a Terminal Services environment. Its value is nonzero if the current session is remotely controlled; zero otherwise. 
		/// </summary>
		RemoteControl = 0x2001
	}
	
	/// <summary>
    /// Available event hooks.
    /// </summary>
	/// <remarks>See the MSDN documentation for more detail.</remarks>
    public enum EventHookTypes : int
    {
        /// <summary>Journal record.</summary>
        JournalRecord = 0,
        /// <summary>Journal playback.</summary>
        JournalPlayback = 1,
        /// <summary>Keyboard event.</summary>
        Keyboard = 2,
        /// <summary>Get message.</summary>
        GetMessage = 3,
        /// <summary>Window callback.</summary>
        CallWindowProc = 4,
        /// <summary>Computer based training.</summary>
        ComputerBasedTraining = 5,
        /// <summary>System message filter.</summary>
        SystemMessageFilter = 6,
        /// <summary>Mouse event.</summary>
        Mouse = 7,
        /// <summary>Hardware.</summary>
        Hardware = 8,
        /// <summary>Debug.</summary>
        Debug = 9,
        /// <summary>Shell.</summary>
        Shell = 10,
        /// <summary>Foreground idle.</summary>
        ForegroundIdle = 11,
        /// <summary>Return from window callback procedure.</summary>
        CallWindowProcReturn = 12,
        /// <summary>Keyboard pre-event monitor.</summary>
        PreviewKeyboard = 13,
        /// <summary>Mouse pre-event monitor.</summary>
        PreviewMouse = 14
    }
    
    /// <summary>
	/// Control event types.
	/// </summary>
	/// <remarks>See the MSDN documentation for more detail.</remarks>
	public enum ControlEventTypes : uint
	{
		/// <summary>Ctrl-C was pressed.</summary>
		CtrlC = 0,
		/// <summary>Break pressed.</summary>
		Break,
		/// <summary>Window closed.</summary>
		WindowClosed,
		/// <summary>Logoff.</summary>
		Logoff = 5,
		/// <summary>Shutdown.</summary>
		ShutDown
	}

	/// <summary>
	/// Flags for shifted keys with console events.
	/// </summary>
	/// <remarks>See the MSDN documentation for more detail.</remarks>
	public enum ConsoleControlFlags : uint
	{
		/// <summary>Right ALT key pressed.</summary>
		RightAltPressed = 1,
		/// <summary>Left ALT key pressed.</summary>
		LeftAltPressed = 2,
		/// <summary>Right CTRL key pressed.</summary>
		RightCtrlPressed = 4,
		/// <summary>Left CTRL key pressed.</summary>
		LeftCtrlPressed = 8,
		/// <summary>Shift key pressed.</summary>
		ShiftPressed = 16
	}

	/// <summary>
	/// Console event types.
	/// </summary>
	/// <remarks>See the MSDN documentation for more detail.</remarks>
	public enum ConsoleEventTypes : ushort
	{
		/// <summary>Key event record present.</summary>
		KeyEvent = 0x0001,
		/// <summary>Mouse event record present.</summary>
		MouseEvent = 0x0002,
		/// <summary>Buffer size event record present.</summary>
		BufferSizeEvent = 0x0004,
		/// <summary>Menu event record present.</summary>
		MenuEvent = 0x0008,
		/// <summary>Focus event record present.</summary>
		FocusEvent = 0x0010
	}

	/// <summary>
	/// Flags for the mouse event for the console.
	/// </summary>
	/// <remarks>See the MSDN documentation for more detail.</remarks>
	public enum ConsoleMouseEventFlags : uint
	{
		/// <summary>Mouse has been moved.</summary>
		Moved = 1,
		/// <summary>Mouse button double clicked.</summary>
		DoubleClick = 2,
		/// <summary>Mouse wheel moved.</summary>
		Wheel = 4
	}

	/// <summary>
	/// Flags for the mouse button event for the console.
	/// </summary>
	/// <remarks>See the MSDN documentation for more detail.</remarks>
	public enum ConsoleMouseButtonFlags : uint
	{
		/// <summary>Left-most button.</summary>
		Left1stButton = 1,
		/// <summary>Right-most button.</summary>
		RightButton = 2,
		/// <summary>2nd left-most button.</summary>
		Left2ndButton = 4,
		/// <summary>3rd left-most button.</summary>
		Left3rdButton = 8,
		/// <summary>4th left-most button.</summary>
		Left4thButton = 16
	}

	/// <summary>
	/// Types of messages that passed to a window.
	/// </summary>
	/// <remarks>See the MSDN documentation for more detail.</remarks>
	public enum WindowMessages
	{
		/// <summary>System command (WM_SYSCOMMAND)</summary>
		SysCommand = 0x0112,
		/// <summary>Quit command (WM_QUIT)</summary>
		Quit = 0x0012,
		/// <summary>Window has been resized. (WM_SIZE)</summary>
		Size = 0x0005,
        /// <summary>Query the drag icon. (WM_QUERYDRAGICON)</summary>
        QueryDragIcon = 0x0037,
        /// <summary>Get the window icon. (WM_GETICON)</summary>
        GetIcon = 0x007F,
        /// <summary>Set the window icon. (WM_SETICON)</summary>
        SetIcon = 0x0080,
		/// <summary></summary>
		NULL = 0,
		/// <summary></summary>
		Create = 0x0001,
		/// <summary></summary>
		Destroy = 0x0002,
		/// <summary></summary>
		Move = 0x0003,
		/// <summary></summary>
		Activate = 0x0006,
		/// <summary></summary>
		SetFocus = 0x0007,
		/// <summary></summary>
		KillFocus = 0x0008,
		/// <summary></summary>
		Enable = 0x000A,
		/// <summary></summary>
		SetRedraw = 0x000B,
		/// <summary></summary>
		SetText = 0x000C,
		/// <summary></summary>
		GetText = 0x000D,
		/// <summary></summary>
		GetTextLength = 0x000E,
		/// <summary></summary>
		Paint = 0x000F,
		/// <summary></summary>
		Close = 0x0010,
		/// <summary></summary>
		QueryEndSession = 0x0011,
		/// <summary></summary>
		QueryOpen = 0x0013,
		/// <summary></summary>
		EraseBackground = 0x0014,
		/// <summary></summary>
		SystemColorChange = 0x0015,
		/// <summary></summary>
		EndSession = 0x0016,
		/// <summary></summary>
		ShowWindow = 0x0018,
		/// <summary></summary>
		ControlColor = 0x0019,
		/// <summary></summary>
		WinINIChange = 0x001A,
		/// <summary></summary>
		SettingChange = 0x001A,
		/// <summary></summary>
		DeviceModeChange = 0x001B,
		/// <summary></summary>
		ActivateApplication = 0x001C,
		/// <summary></summary>
		FontChange = 0x001D,
		/// <summary></summary>
		TimeChange = 0x001E,
		/// <summary></summary>
		CancelMode = 0x001F,
		/// <summary></summary>
		SetCursor = 0x0020,
		/// <summary></summary>
		MouseActivate = 0x0021,
		/// <summary></summary>
		ChildActivate = 0x0022,
		/// <summary></summary>
		QueueSync = 0x0023,
		/// <summary></summary>
		GetMinMaxInformation = 0x0024,
		/// <summary></summary>
		PaintIcon = 0x0026,
		/// <summary></summary>
		IconEraseBackground = 0x0027,
		/// <summary></summary>
		NextDialogControl = 0x0028,
		/// <summary></summary>
		SpoolerStatus = 0x002A,
		/// <summary></summary>
		DrawItem = 0x002B,
		/// <summary></summary>
		MeasureItem = 0x002C,
		/// <summary></summary>
		DeleteItem = 0x002D,
		/// <summary></summary>
		VKeyToItem = 0x002E,
		/// <summary></summary>
		CharToItem = 0x002F,
		/// <summary></summary>
		SetFont = 0x0030,
		/// <summary></summary>
		GetFont = 0x0031,
		/// <summary></summary>
		SetHotKey = 0x0032,
		/// <summary></summary>
		GetHotKey = 0x0033,
		/// <summary></summary>
		CompareItem = 0x0039,
		/// <summary></summary>
		GetObject = 0x003D,
		/// <summary></summary>
		Compacting = 0x0041,
		/// <summary></summary>
		COMMNotify = 0x0044,
		/// <summary></summary>
		WindowPositionChanging = 0x0046,
		/// <summary></summary>
		WindowPositionChanged = 0x0047,
		/// <summary></summary>
		Power = 0x0048,
		/// <summary></summary>
		CopyData = 0x004A,
		/// <summary></summary>
		CancelJournal = 0x004B,
		/// <summary></summary>
		Notify = 0x004E,
		/// <summary></summary>
		InputLanguageChangeRequest = 0x0050,
		/// <summary></summary>
		InputLanguageChange = 0x0051,
		/// <summary></summary>
		TCard = 0x0052,
		/// <summary></summary>
		Help = 0x0053,
		/// <summary></summary>
		UserChanged = 0x0054,
		/// <summary></summary>
		NotifyFormat = 0x0055,
		/// <summary></summary>
		ContextMenu = 0x007B,
		/// <summary></summary>
		StyleChanging = 0x007C,
		/// <summary></summary>
		StyleChanged = 0x007D,
		/// <summary></summary>
		DisplayChange = 0x007E,
		/// <summary></summary>
		NCCreate = 0x0081,
		/// <summary></summary>
		NCDestroy = 0x0082,
		/// <summary></summary>
		NCCalcSize = 0x0083,
		/// <summary></summary>
		NCHitTest = 0x0084,
		/// <summary></summary>
		NCPaint = 0x0085,
		/// <summary></summary>
		NCActivate = 0x0086,
		/// <summary></summary>
		GetDialogCode = 0x0087,
		/// <summary></summary>
		SynchronizePaint = 0x0088,
		/// <summary></summary>
		NCMouseMove = 0x00A0,
		/// <summary></summary>
		NCLeftButtonDown = 0x00A1,
		/// <summary></summary>
		NCLeftButtonUp = 0x00A2,
		/// <summary></summary>
		NCLeftButtonDoubleClick = 0x00A3,
		/// <summary></summary>
		NCRightButtonDown = 0x00A4,
		/// <summary></summary>
		NCRightButtonUp = 0x00A5,
		/// <summary></summary>
		NCRightButtonDoubleClick = 0x00A6,
		/// <summary></summary>
		NCMiddleButtonDown = 0x00A7,
		/// <summary></summary>
		NCMiddleButtonUp = 0x00A8,
		/// <summary></summary>
		NCMiddleButtonDoubleClick = 0x00A9,
		/// <summary></summary>
		KeyDown = 0x0100,
		/// <summary></summary>
		KeyUp =0x0101,
		/// <summary></summary>
		Char = 0x0102,
		/// <summary></summary>
		DeadChar = 0x0103,
		/// <summary></summary>
		SysKeyDown = 0x0104,
		/// <summary></summary>
		SysKeyUp = 0x0105,
		/// <summary></summary>
		SysChar = 0x0106,
		/// <summary></summary>
		SysDeadChar = 0x0107,
		/// <summary></summary>
		KeyLast = 0x0180,
		/// <summary></summary>
		IMEStartComposition = 0x010D,
		/// <summary></summary>
		IMEEndComposition = 0x010E,
		/// <summary></summary>
		IMEComposition = 0x010F,
		/// <summary></summary>
		IMEKeyLast = 0x010F,
		/// <summary></summary>
		InitializeDialog = 0x0110,
		/// <summary></summary>
		Command = 0x0111,
		/// <summary></summary>
		Timer = 0x0113,
		/// <summary></summary>
		HorizontalScroll = 0x0114,
		/// <summary></summary>
		VerticalScroll = 0x0115,
		/// <summary></summary>
		InitializeMenu = 0x0116,
		/// <summary></summary>
		InitializeMenuPopup = 0x0117,
		/// <summary></summary>
		MenuSelect = 0x011F,
		/// <summary></summary>
		MenuChar = 0x0120,
		/// <summary></summary>
		EnterIdle = 0x0121,
		/// <summary></summary>
		MenuRightButtonUp = 0x0122,
		/// <summary></summary>
		MenuDrag = 0x0123,
		/// <summary></summary>
		MenuGetObject = 0x0124,
		/// <summary></summary>
		UnInitializeMenuPopup = 0x0125,
		/// <summary></summary>
		MenuCommand = 0x0126,
		/// <summary></summary>
		ControlColorMessageBox = 0x0132,
		/// <summary></summary>
		ControlColorEdit = 0x0133,
		/// <summary></summary>
		ControlColorListBox = 0x0134,
		/// <summary></summary>
		ControlColorButton = 0x0135,
		/// <summary></summary>
		ControlColorDialog = 0x0136,
		/// <summary></summary>
		ControlColorScrollbar = 0x0137,
		/// <summary></summary>
		ControlColorStatic = 0x0138,
		/// <summary></summary>
		MouseMove = 0x0200,
		/// <summary></summary>
		LeftButtonDown = 0x0201,
		/// <summary></summary>
		LeftButtonUp = 0x0202,
		/// <summary></summary>
		LeftButtonDoubleClick = 0x0203,
		/// <summary></summary>
		RightButtonDown = 0x0204,
		/// <summary></summary>
		RightButtonUp = 0x0205,
		/// <summary></summary>
		RightButtonDoubleClick = 0x0206,
		/// <summary></summary>
		MiddleButtonDown = 0x0207,
		/// <summary></summary>
		MiddleButtonUp = 0x0208,
		/// <summary></summary>
		MiddleButtonDoubleClick = 0x0209,
		/// <summary></summary>
		MouseWheel = 0x020A,
		/// <summary></summary>
		ParentNotify = 0x0210,
		/// <summary></summary>
		EnterMenuLoop = 0x0211,
		/// <summary></summary>
		ExitMenuLoop = 0x0212,
		/// <summary></summary>
		NextMenu = 0x0213,
		/// <summary></summary>
		Sizing = 0x0214,
		/// <summary></summary>
		CaptureChanged = 0x0215,
		/// <summary></summary>
		Moving = 0x0216,
		/// <summary></summary>
		DeviceChange = 0x0219,
		/// <summary></summary>
		MDICreate = 0x0220,
		/// <summary></summary>
		MDIDestroy = 0x0221,
		/// <summary></summary>
		MDIActivate = 0x0222,
		/// <summary></summary>
		MDIRestore = 0x0223,
		/// <summary></summary>
		MDINext = 0x0224,
		/// <summary></summary>
		MDIMaximize = 0x0225,
		/// <summary></summary>
		MDITile = 0x0226,
		/// <summary></summary>
		MDICacade = 0x0227,
		/// <summary></summary>
		MDIIconArrange = 0x0228,
		/// <summary></summary>
		MDIGetActive = 0x0229,
		/// <summary></summary>
		MDISetMenu = 0x0230,
		/// <summary></summary>
		EnterSizeMove = 0x0231,
		/// <summary></summary>
		ExitSizeMove = 0x0232,
		/// <summary></summary>
		DropFiles = 0x0233,
		/// <summary></summary>
		MDIRefreshMenu = 0x0234,
		/// <summary></summary>
		IMESetContext = 0x0281,
		/// <summary></summary>
		IMENotify = 0x0282,
		/// <summary></summary>
		IMEControl = 0x0283,
		/// <summary></summary>
		IMECompositionFull = 0x0284,
		/// <summary></summary>
		IMESelect = 0x0285,
		/// <summary></summary>
		IMEChar = 0x0286,
		/// <summary></summary>
		IMERequest = 0x0288,
		/// <summary></summary>
		IMEKeyDown = 0x0290,
		/// <summary></summary>
		IMEKeyUp = 0x0291,
		/// <summary></summary>
		MouseHover = 0x02A1,
		/// <summary></summary>
		MouseLeave = 0x02A3,
		/// <summary></summary>
		Cut = 0x0300,
		/// <summary></summary>
		Copy = 0x0301,
		/// <summary></summary>
		Paste = 0x0302,
		/// <summary></summary>
		Clear = 0x0303,
		/// <summary></summary>
		Undo = 0x0304,
		/// <summary></summary>
		RenderFormat = 0x0305,
		/// <summary></summary>
		RenderAllFormats = 0x0306,
		/// <summary></summary>
		DestroyClipboard = 0x0307,
		/// <summary></summary>
		DrawClipboard = 0x0308,
		/// <summary></summary>
		Paintclipboard = 0x0309,
		/// <summary></summary>
		VerticalScrollClipboard = 0x030A,
		/// <summary></summary>
		SizeClipboard = 0x030B,
		/// <summary></summary>
		AskClipboardFormatName = 0x030C,
		/// <summary></summary>
		ChangeClipboardChain = 0x030D,
		/// <summary></summary>
		HorizontalScrollClipboard = 0x030E,
		/// <summary></summary>
		QueryNewPalette = 0x030F,
		/// <summary></summary>
		PaletteIsChanging = 0x0310,
		/// <summary></summary>
		PaletteChanged = 0x0311,
		/// <summary></summary>
		HotKey = 0x0312,
		/// <summary></summary>
		Print = 0x0317,
		/// <summary></summary>
		PrintClient = 0x0318,
		/// <summary></summary>
		HandheldFirst = 0x0358,
		/// <summary></summary>
		HandheldLast = 0x035F,
		/// <summary></summary>
		AFXFirst = 0x0360,
		/// <summary></summary>
		AFXLast = 0x037F,
		/// <summary></summary>
		PenWindowFirst = 0x0380,
		/// <summary></summary>
		PenWindowLast = 0x038F,
		/// <summary></summary>
		Application = 0x8000,
		/// <summary></summary>
		User = 0x0400,
		/// <summary></summary>
		RawInput = 0x00FF
	}

    /// <summary>
    /// Flags passed to SendMessageTimeout().
    /// </summary>
	/// <remarks>See the MSDN documentation for more detail.</remarks>
    public enum SendMessageTimeoutFlags
    {
        /// <summary>Aborts the send if the thread appears to be hung.</summary>
        AbortIfHung = 0x02
    }

    /// <summary>
    /// Brush styles used with GDI applications.
    /// </summary>
	/// <remarks>See the MSDN documentation for more detail.</remarks>
    public enum BrushStyles
    {
        /// <summary>A white brush.</summary>
        White = 0,
        /// <summary>A light gray brush.</summary>
        LightGray = 1,
        /// <summary>A gray brush.</summary>
        Gray = 2,
        /// <summary>A dark gray brush.</summary>
        DarkGray = 3,
        /// <summary>A black brush.</summary>
        Black = 4,
        /// <summary>A null brush.</summary>
        Null = 5,
        /// <summary>A hollow brush (same as null).</summary>
        Hollow = 5
    }

    /// <summary>
    /// Pen styles used with GDI applications.
    /// </summary>
	/// <remarks>See the MSDN documentation for more detail.</remarks>
    public enum PenStyles
    {
        /// <summary>A white pen.</summary>
        White = 6,
        /// <summary>A black pen.</summary>
        Black = 7,
        /// <summary>A NULL pen.</summary>
        Null = 8
    }

    /// <summary>
    /// Font styles used with GDI applications.
    /// </summary>
	/// <remarks>See the MSDN documentation for more detail.</remarks>
    public enum FontStyles
    {
        /// <summary>Fixed OEM font.</summary>
        OEMFixed = 10,
        /// <summary>Fixed ANSI font.</summary>
        ANSIFixed = 11,
        /// <summary>Variable ANSI font.</summary>
        ANSIVariable = 12,
        /// <summary>System font.</summary>
        System = 13,
        /// <summary>Device font.</summary>
        Device = 14,
        /// <summary>Fixed system font.</summary>
        SystemFixed = 16
    }

    /// <summary>
    /// wParam parameters to send with window messages.
    /// </summary>
	/// <remarks>See the MSDN documentation for more detail.</remarks>
    public enum WParameters
    {
        /// <summary>Set/Get the large icon with WM_GET/SETICON.</summary>
        IconBig = 1,
        /// <summary>Set/Get the small icon with WM_GET/SETICON.</summary>
        IconSmall = 0,
    }

	/// <summary>
	/// lParam parameters to send with window messages.
	/// </summary>
	/// <remarks>See the MSDN documentation for more detail.</remarks>
	public enum LParameters
	{
		/// <summary>Parent window is being minimized.</summary>
		ParentClosing = 1,
		/// <summary>The window is being covered by another window that is maximized.</summary>
		OtherZoom = 2,
		/// <summary>Parent window is being restored.</summary>
		ParentOpening = 3,
		/// <summary>The window is being uncovered.</summary>
		OtherUnZoom = 4
	}

	/// <summary>
	/// Flags to pass to the SetWindowPosition() function.
	/// </summary>
	/// <remarks>See the MSDN documentation for more detail.</remarks>
	public enum SetWindowPositionFlags
	{
		/// <summary>Don't resize.</summary>
		NoSize = 0x0001,
		/// <summary>Don't move.</summary>
		NoMove = 0x0002,
		/// <summary>Don't change the Z order of the window.</summary>
		NoZOrder = 0x0004,
		/// <summary>Don't redraw the window.</summary>
		NoRedraw = 0x0008,
		/// <summary>Don't activate the window.</summary>
		NoActivate = 0x0010,
		/// <summary>Flag to indicate the window has changed.</summary>
		FrameChanged = 0x0020,
		/// <summary>Displays the window.</summary>
		ShowWindow = 0x0040,
		/// <summary>Hides the window.</summary>
		HideWindow = 0x0080,
		/// <summary>Erases the contents of the client area.</summary>
		NoCopyBits = 0x0100,
		/// <summary>Don't change the owner's Z order position.</summary>
		NoOwnerZOrder = 0x0200,
		/// <summary>Don't send the changing message (WM_WINDOWPOSCHANGING).</summary>
		NoSendChanging = 0x0400,
		/// <summary>Same as FrameChanged.</summary>
		DrawFrame = 0x0020,
		/// <summary>This prevents the calling thread from blocking its execution while other threads process the request.</summary>
		AsynchronousWindowPosition = 0x4000
	}

	/// <summary>
	/// Default window handles for the SetWindowPosition() function.
	/// </summary>
	/// <remarks>See the MSDN documentation for more detail.</remarks>
	public enum SetWindowPositionHandles
	{
		/// <summary></summary>
		Top = 0,
		/// <summary></summary>
		Bottom = 1,
		/// <summary></summary>
		TopMost = -1,
		/// <summary></summary>
		NoTopMost = -2
	}

	/// <summary>
	/// Types of System commands.
	/// </summary>
	/// <remarks>
	/// See the MSDN documentation for more detail.
	/// <para>
	/// These are often used with the WM_SYSCOMMAND message.
	/// </para>
	/// </remarks>
	public enum SysCommands
	{
		/// <summary>Screen saver. (SC_SCREENSAVE)</summary>
		ScreenSave = 0xF140,
		/// <summary>Monitor power saving. (SC_MONITORPOWER)</summary>
		MonitorPower = 0xF170
	}

	/// <summary>
	/// Flags for PeekMessage function.
	/// </summary>
	/// <remarks>See the MSDN documentation for more detail.</remarks>
	public enum PeekMessageFlags
	{
		/// <summary>Keep message on the message queue.</summary>
		NoRemove = 0,
		/// <summary>Remove message from the queue.</summary>
		Remove = 1,
		/// <summary>Do not yield execution to waiting threads.</summary>
		NoYield = 2
	}

	/// <summary>
	/// Types of standard handles.
	/// </summary>
	/// <remarks>See the MSDN documentation for more detail.</remarks>
	public enum StandardHandles
	{
		/// <summary>Standard input.</summary>
		Input = -10,
		/// <summary>Standard output.</summary>
		Output = -11,
		/// <summary>Standard error.</summary>
		Error = -12,
	}

	/// <summary>
	/// Types of foreground colors.
	/// </summary>
	/// <remarks>
	/// This is slightly different than the console colors listed in the MSDN documentation.
	/// <para>
	/// The <seealso cref="SharpUtilities.Console.ConsoleApplication">ConsoleApplication</seealso> object handles translation to the proper API colors.
	/// </para>
	/// </remarks>
	public enum ConsoleAttributes
	{
		/// <summary>Black.</summary>
		Black = 0,
		/// <summary>Foreground red component.</summary>
		FGRed = 0x0004,
		/// <summary>Foreground blue component.</summary>
		FGBlue = 0x0001,
		/// <summary>Foreground green component.</summary>
		FGGreen = 0x0002,
		/// <summary>Foreground intensity.</summary>
		FGIntensity = 0x0008,
		/// <summary>Background red component.</summary>
		BGRed = 0x0040,
		/// <summary>Background green component.</summary>
		BGGreen = 0x0020,
		/// <summary>Background blue component.</summary>
		BGBlue = 0x0010,
		/// <summary>Background intensity.</summary>
		BGIntensity = 0x0080
	}

	/// <summary>
	/// Flags for console modes.
	/// </summary>
	/// <remarks>See the MSDN documentation for more detail.</remarks>
	public enum ConsoleModeFlags
	{
		/// <summary>Flag to enable processed output.</summary>
		EnableProcessedOutput = 1,
		/// <summary>Flag to enable text wrapping on output.</summary>
		EnableWrapAtEOLOutput = 2,
		/// <summary>Flag to enable processed input.</summary>
		EnableProcessedInput = 1,
		/// <summary>Flag to enable line input.</summary>
		EnableLineInput = 2,
		/// <summary>Flag to enable echo of line input.</summary>
		EnableEchoInput = 4,
		/// <summary>Flag to enable window input.</summary>
		EnableWindowInput = 8,
		/// <summary>Flag to enable mouse input.</summary>
		EnableMouseInput = 0x10
	}

	/// <summary>
	/// Flags for name formatting.
	/// </summary>
	/// <remarks>See the MSDN documentation for more detail.</remarks>
	public enum ExtendedNameFormat
	{
		/// <summary>Unknown formatting.</summary>
		Unknown = 0,
		/// <summary>Fully qualified domain name.</summary>
		FullyQualifiedDN = 1,
		/// <summary>SAM compatible.</summary>
		SamCompatible = 2,
		/// <summary>Display name.</summary>
		Display = 3,
		/// <summary>Unique ID.</summary>
		UniqueId = 6,
		/// <summary>Canonical name.</summary>
		Canonical = 7,
		/// <summary>User principal name.</summary>
		UserPrincipal = 8,
		/// <summary>Canonical name extended.</summary>
		CanonicalEx = 9,
		/// <summary>Service principal name.</summary>
		ServicePrincipal = 10,
		/// <summary>DNS domain name.</summary>
		DnsDomain = 12
	}

	/// <summary>
	/// Flags for computer name formatting.
	/// </summary>
	/// <remarks>See the MSDN documentation for more detail.</remarks>
	public enum ComputerNameFormat
	{
		/// <summary>NET BIOS name.</summary>
		NetBIOS,
		/// <summary>DNS host name.</summary>
		DnsHostname,
		/// <summary>DNS domain name.</summary>
		NameDnsDomain,
		/// <summary>Fully qualified name.</summary>
		DnsFullyQualified,
		/// <summary>Physical NET BIOS name.</summary>
		PhysicalNetBIOS,
		/// <summary>Physical DNS host name.</summary>
		PhysicalDnsHostname,
		/// <summary>Physical DNS domain name.</summary>
		PhysicalDnsDomain,
		/// <summary>Physical fully qualified name.</summary>
		PhysicalDnsFullyQualified
	}

    /// <summary>
    /// Windows Shell hooks.
    /// </summary>
	/// <remarks>See the MSDN documentation for more detail.</remarks>
    public enum ShellHookMessages
    {
        /// <summary>Window created message.</summary>
        WindowCreated = 1,
        /// <summary>Window destroyed message.</summary>
        WindowDestroyed = 2,
        /// <summary>Activate shell window message.</summary>
        ActivateShellWindow = 3,
        /// <summary>Window activated message.</summary>
        WindowActivated = 4,
        /// <summary>Get minimum rectangle bounds message.</summary>
        GetMinimumRectangle = 5,
        /// <summary>Redraw message.</summary>
        Redraw = 6,
        /// <summary>Task manager message.</summary>
        TaskManager = 7,
        /// <summary>Language message.</summary>
        Language = 8,
        /// <summary>Accessibility state message.</summary>
        AccessibilityState = 11
    }

    /// <summary>
    /// Fields used in Get/SetWindowLong() functions.
    /// </summary>
	/// <remarks>See the MSDN documentation for more detail.</remarks>
    public enum WindowLongFields
    {
        /// <summary>Parent window handle.</summary>
        ParentHWND = -8,
        /// <summary>Extended window style.</summary>
        StyleEX = -20,
        /// <summary>Window style.</summary>
        Style = -16,
    }

    /// <summary>
    /// Fields used in Get/SetClassLong() functions.
    /// </summary>
	/// <remarks>See the MSDN documentation for more detail.</remarks>
    public enum ClassLongFields
    {
        /// <summary>Handle to the large window icon.</summary>
        IconHandle = -14,
        /// <summary>Handle to the small window icon.</summary>
        SmallIconHandle = -34
    }

	/// <summary>
	/// Flags for the RedrawWindow() function.
	/// </summary>
	/// <remarks>See the MSDN documentation for more detail.</remarks>
	public enum RedrawWindowFlags
	{
		/// <summary>Invalidates the window.</summary>
		Invalidate = 0x0001,
		/// <summary>Forces a WM_PAINT to be sent to the window.</summary>
		InternalPaint = 0x0002,
		/// <summary>Erases the window, must be used with Invalidate.</summary>
		Erase = 0x0004,
		/// <summary>Validates the regions.</summary>
		Validate = 0x0008,
		/// <summary>Suppresses the WM_PAINT message, except those regions that need updating.</summary>
		NoInternalPaint = 0x0010,
		/// <summary>Suppresses the WM_ERASEBKGND message.</summary>
		NoErase = 0x0020,
		/// <summary>Exclude child windows.</summary>
		NoChildren = 0x0040,
		/// <summary>Include child windows.</summary>
		AllChildren = 0x0080,
		/// <summary>Forces the window to update.</summary>
		UpdateNow = 0x0100,
		/// <summary>Forces the window to erase.</summary>
		EraseNow = 0x0200,
		/// <summary>Sends a WM_NCPAINT message to the window, must be used with Invalidate.</summary>
		Frame = 0x0400,
		/// <summary>Suppresses the WM_NCPAINT message, must be used with Invalidate.</summary>
		NoFrame = 0x0800
	}

	/// <summary>
	/// Flags for the ShowWindow command.
	/// </summary>
	/// <remarks>See the MSDN documentation for more detail.</remarks>
	public enum ShowWindowFlags
	{
		/// <summary>Hides the window.</summary>
		Hide = 0,
		/// <summary>Activates and displays the window.</summary>
		ShowNormal = 1,
		/// <summary>Same as ShowNormal.</summary>
		Normal = 1,
		/// <summary>Activates and displays the window in a minimized state.</summary>
		ShowMinimized = 2,
		/// <summary>Activates and displays the window in a maximized state.</summary>
		ShowMaximized = 3,
		/// <summary>Same as ShowMaximized.</summary>
		Maximize = 3,
		/// <summary>Shows the window, but doesn't activate it.</summary>
		ShowNoActivate = 4,
		/// <summary>Shows the window and activates it.</summary>
		Show = 5,
		/// <summary>Activates the window and minimizes it.</summary>
		Minimize = 6,
		/// <summary>Shows the window in a minimized state, but does not activate it.</summary>
		ShowMinimizedNoActivate = 7,
		/// <summary>Shows the window in a normal state, but does not activate it.</summary>
		ShowCurrentNoActivate = 8,
		/// <summary>Restores the window from a maximized or minimized state.</summary>
		Restore = 9,
		/// <summary>Show the window with the default state.</summary>
		ShowDefault = 10,
		/// <summary>Forces a window to minimize.</summary>
		ForceMinimize = 11
	}

	/// <summary>
	/// Window extended style flags.
	/// </summary>
    [Flags]
	public enum WindowStylesEx : uint
	{
        /// <summary></summary>
        DialogModalFrame = 0x00000001,
        /// <summary></summary>
        NorParentNotify = 0x00000004,
        /// <summary></summary>
        TopMost = 0x00000008,
        /// <summary></summary>
        AcceptFiles = 0x00000010,
        /// <summary></summary>
        Transparent = 0x00000020,
        /// <summary></summary>
        MDIChild = 0x00000040,
        /// <summary></summary>
        ToolWindow = 0x00000080,
        /// <summary></summary>
        WindowEdge = 0x00000100,
        /// <summary></summary>
        ClientEdge = 0x00000200,
        /// <summary></summary>
        ContextHelp = 0x00000400,
        /// <summary></summary>
        Right = 0x00001000,
        /// <summary></summary>
        Left = 0x00000000,
        /// <summary></summary>
        RightToLeftReading = 0x00002000,
        /// <summary></summary>
        LeftToRightReading = 0x00000000,
        /// <summary></summary>
        LeftScrollbar = 0x00004000,
        /// <summary></summary>
        RightScrollbar = 0x00000000,
        /// <summary></summary>
        ControlParent = 0x00010000,
        /// <summary></summary>
        StaticEdge = 0x00020000,
        /// <summary></summary>
        ApplicationWindow = 0x00040000,
        /// <summary></summary>
        OverlappedWindow = (WindowEdge | ClientEdge),
        /// <summary></summary>
        PaletteWindow = (WindowEdge | ToolWindow | TopMost),
        /// <summary></summary>
        LayeredWindow = 0x00080000,
        /// <summary></summary>
        DontInheritLayout = 0x00100000, 
        /// <summary></summary>
        LayoutRightToLeft = 0x00400000,
        /// <summary></summary>
        Composited = 0x02000000,
        /// <summary></summary>
        NoActivate = 0x08000000
	}

	/// <summary>
	/// Window style flags.
	/// </summary>
    [Flags]
	public enum WindowStyles : uint
	{
		/// <summary></summary>
		Border = 0x800000,
		/// <summary></summary>
		Caption = 0xC00000,
		/// <summary></summary>
		Child = 0x40000000,
		/// <summary></summary>
		ChildWindow = Child,
		/// <summary></summary>
		ClipChildren = 0x2000000,
		/// <summary></summary>
		ClipSiblings = 0x4000000,
		/// <summary></summary>
		Disabled = 0x8000000,
		/// <summary></summary>
		DialogFrame = 0x400000,
		/// <summary></summary>
		Group = 0x20000,
		/// <summary></summary>
		HorizontalScroll = 0x100000,
		/// <summary></summary>
		Maximize = 0x1000000,
		/// <summary></summary>
		MaximizeBox = 0x10000,
		/// <summary></summary>
		Minimize = 0x20000000,
		/// <summary></summary>
		MinimizeBox = 0x20000,
		/// <summary></summary>
		Overlapped = 0x0,
		/// <summary></summary>
		Popup = 0x80000000,
		/// <summary></summary>
		SystemMenu = 0x80000,
		/// <summary></summary>
		TabStop = 0x10000,
		/// <summary></summary>
		ThickFrame = 0x40000,
		/// <summary></summary>
		Visible = 0x10000000,
		/// <summary></summary>
		VerticalScroll = 0x200000,
		/// <summary></summary>
		Iconic = Minimize,
		/// <summary></summary>
		PopupWindow = Popup | Border | SystemMenu,
		/// <summary></summary>
		SizeBox = ThickFrame,
		/// <summary></summary>
		Tiled = Overlapped,
		/// <summary></summary>
		OverlappedWindow = (Overlapped | Caption | SystemMenu | ThickFrame | MinimizeBox | MaximizeBox)
	}

	/// <summary>
	/// Binary raster operation flags.
	/// </summary>
	public enum BinaryRasterOps
	{
		/// <summary></summary>
		Black = 1,
		/// <summary></summary>
		NotMergePen = 2,
		/// <summary></summary>
		MaskNotPen = 3,
		/// <summary></summary>
		NotCopyPen = 4,
		/// <summary></summary>
		MaskPenNot = 5,
		/// <summary></summary>
		Not = 6,
		/// <summary></summary>
		XORPen = 7,
		/// <summary></summary>
		NotMaskPen = 8,
		/// <summary></summary>
		MaskPen = 9,
		/// <summary></summary>
		NotXORPen = 10,
		/// <summary></summary>
		NOP = 11,
		/// <summary></summary>
		MergeNotPen = 12,
		/// <summary></summary>
		CopyPen = 13,
		/// <summary></summary>
		MergePenNot = 14,
		/// <summary></summary>
		MergePen = 15,
		/// <summary></summary>
		White = 16,
		/// <summary></summary>
		Last = 16
	}

	/// <summary>
	/// Ternary raster operation flags.
	/// </summary>
	public enum TernaryRasterOps
	{
		/// <summary></summary>
		SourceCopy = 0x00CC0020,
		/// <summary></summary>
		SourcePaint = 0x00EE0086,
		/// <summary></summary>
		SourceAnd = 0x008800C6,
		/// <summary></summary>
		SourceInvert = 0x00660046,
		/// <summary></summary>
		SourceErase = 0x00440328,
		/// <summary></summary>
		NotSourceCopy = 0x00330008,
		/// <summary></summary>
		NotSourceErase = 0x001100A6,
		/// <summary></summary>
		MergeCopy = 0x00C000CA,
		/// <summary></summary>
		MergePaint = 0x00BB0226,
		/// <summary></summary>
		PatternCopy = 0x00F00021,
		/// <summary></summary>
		PatternPaint = 0x00FB0A09,
		/// <summary></summary>
		PatternInvert = 0x005A0049,
		/// <summary></summary>
		DestinationInvert = 0x00550009,
		/// <summary></summary>
		Black = 0x00000042,
		/// <summary></summary>
		White = 0x00FF0062 
	}

	/// <summary>
	/// Hot key modifier flags.
	/// </summary>
	[Flags()]
	public enum HotkeyModifierFlags
	{
		/// <summary></summary>
		Alt = 0x0001,
		/// <summary></summary>
		Control = 0x0002,
		/// <summary></summary>
		Shift = 0x0004,
		/// <summary></summary>
		Windows = 0x0008
	}

	/// <summary>
	/// Shell icon size.
	/// </summary>
	public enum ShellIconSize
	{
		/// <summary>
		/// Large icon.
		/// </summary>
		Large = 0,
		/// <summary>
		/// Small icon.
		/// </summary>
		Small = 1
	}

	/// <summary>
	/// Flags for SHGetInfo.
	/// </summary>
	[Flags()]
	public enum ShellInfoFlags
	{
		/// <summary>
		/// Get icon.
		/// </summary>
		Icon = 0x000000100,
		/// <summary>
		/// Get display name.
		/// </summary>
		DisplayName = 0x000000200,
		/// <summary>
		/// Get type name.
		/// </summary>
		TypeName = 0x000000400,
		/// <summary>
		/// Get attributes.
		/// </summary>
		Attributes = 0x000000800,
		/// <summary>
		/// Get icon location.
		/// </summary>
		IconLocation = 0x000001000,
		/// <summary>
		/// Get EXE type.
		/// </summary>
		EXEType = 0x000002000,
		/// <summary>
		/// Get system icon index.
		/// </summary>
		SystemIconIndex = 0x000004000,
		/// <summary>
		/// Put a link overlay on the icon.
		/// </summary>
		LinkOverlay = 0x000008000,
		/// <summary>
		/// Show icon as selected.
		/// </summary>
		Selected = 0x000010000,
		/// <summary>
		/// Get specified attributes.
		/// </summary>
		AttributesSpecified = 0x000020000,
		/// <summary>
		/// Get large icon.
		/// </summary>
		LargeIcon = 0x000000000,
		/// <summary>
		/// Get small icon.
		/// </summary>
		SmallIcon = 0x000000001,
		/// <summary>
		/// Get open icon.
		/// </summary>
		OpenIcon = 0x000000002,
		/// <summary>
		/// Get shell icon size.
		/// </summary>
		ShellIconSize = 0x000000004,
		/// <summary>
		/// Path is a PIDL.
		/// </summary>
		PIDL = 0x000000008,
		/// <summary>
		/// Use dwFileAttribute.
		/// </summary>
		UseFileAttributes = 0x000000010,
		/// <summary>
		/// Apply overlays.
		/// </summary>
		AddOverlays = 0x000000020,
		/// <summary>
		/// Get the index of the overlay in the upper 8 bits of the IconIndex member.
		/// </summary>
		OverlayIndex = 0x000000040
	}
	#endregion
}
