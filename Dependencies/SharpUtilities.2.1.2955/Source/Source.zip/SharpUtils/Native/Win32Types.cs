#region LGPL.
// 
// SharpUtils.
// Copyright (C) 2005 Michael Winsor
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
// 
// Created: Tuesday, November 29, 2005 1:15:36 AM
// 
#endregion

using System;
using System.Drawing;
using System.Text;
using System.Runtime.InteropServices;

namespace SharpUtilities.Native.Win32
{
	#region Value types.
	
	/// <summary>
	/// Structure containing text metric data.
	/// </summary>
	[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
	public struct NEWTEXTMETRIC 
	{ 
		/// <summary>
		/// 
		/// </summary>
		public int tmHeight;
		/// <summary>
		/// 
		/// </summary>
		public int tmAscent;
		/// <summary>
		/// 
		/// </summary>
		public int tmDescent;
		/// <summary>
		/// 
		/// </summary>
		public int tmInternalLeading;
		/// <summary>
		/// 
		/// </summary>
		public int tmExternalLeading;
		/// <summary>
		/// 
		/// </summary>
		public int tmAveCharWidth;
		/// <summary>
		/// 
		/// </summary>
		public int tmMaxCharWidth;
		/// <summary>
		/// 
		/// </summary>
		public int tmWeight;
		/// <summary>
		/// 
		/// </summary>
		public int tmOverhang;
		/// <summary>
		/// 
		/// </summary>
		public int tmDigitizedAspectX;
		/// <summary>
		/// 
		/// </summary>
		public int tmDigitizedAspectY;
		/// <summary>
		/// 
		/// </summary>
		[MarshalAs(UnmanagedType.ByValTStr, SizeConst = 1)]
		public string tmFirstChar;
		/// <summary>
		/// 
		/// </summary>
		[MarshalAs(UnmanagedType.ByValTStr, SizeConst = 1)]
		public string tmLastChar;
		/// <summary>
		/// 
		/// </summary>
		[MarshalAs(UnmanagedType.ByValTStr, SizeConst = 1)]
		public string tmDefaultChar;
		/// <summary>
		/// 
		/// </summary>
		[MarshalAs(UnmanagedType.ByValTStr, SizeConst = 1)]
		public string tmBreakChar;
		/// <summary>
		/// 
		/// </summary>
		public byte tmItalic;
		/// <summary>
		/// 
		/// </summary>
		public byte tmUnderlined;
		/// <summary>
		/// 
		/// </summary>
		public byte tmStruckOut;
		/// <summary>
		/// 
		/// </summary>
		public byte tmPitchAndFamily;
		/// <summary>
		/// 
		/// </summary>
		public byte tmCharSet;
		/// <summary>
		/// 
		/// </summary>
		public uint ntmFlags;
		/// <summary>
		/// 
		/// </summary>
		public uint ntmSizeEM;
		/// <summary>
		/// 
		/// </summary>
		public uint ntmCellHeight;
		/// <summary>
		/// 
		/// </summary>
		public uint ntmAvgWidth; 
	} 

	/// <summary>
	/// Structure containing font signature data.
	/// </summary>
	[StructLayout(LayoutKind.Sequential, CharSet=CharSet.Auto)]
	public struct FONTSIGNATURE 
	{
		/// <summary>
		/// 
		/// </summary>
		[MarshalAs(UnmanagedType.ByValArray, SizeConst=4, ArraySubType = UnmanagedType.U4)]
		public uint[] fsUsb;
		/// <summary>
		/// 
		/// </summary>
		[MarshalAs(UnmanagedType.ByValArray, SizeConst=2, ArraySubType = UnmanagedType.U4)]
		public uint[] fsCsb;
	} 

	/// <summary>
	/// Structure containing physical font data.
	/// </summary>
	[StructLayout(LayoutKind.Sequential, CharSet=CharSet.Auto)]
	public struct NEWTEXTMETRICEX
	{
		/// <summary>
		/// 
		/// </summary>
		public NEWTEXTMETRIC ntmTm;
		/// <summary>
		/// 
		/// </summary>
		public FONTSIGNATURE ntmFontSig;
	}

	/// <summary>
	/// Structure containing logical font data for enumeration.
	/// </summary>
	[StructLayout(LayoutKind.Sequential, CharSet=CharSet.Auto)]
	public struct ENUMLOGFONTEX
	{
		/// <summary>
		/// 
		/// </summary>
		public LOGFONT elfLogFont;
		/// <summary>
		/// 
		/// </summary>
		[MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)]
		public string elfFullName;
		/// <summary>
		/// 
		/// </summary>
		[MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)]
		public string elfStyle;
		/// <summary>
		/// 
		/// </summary>
		[MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)]
		public string elfScript;
	}

	/// <summary>
	/// Structure that contains the logical properties of a font.
	/// </summary>
	[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
	public struct LOGFONT
	{
		/// <summary>
		/// 
		/// </summary>
		public int lfHeight;
		/// <summary>
		/// 
		/// </summary>
		public int lfWidth;
		/// <summary>
		/// 
		/// </summary>
		public int lfEscapement;
		/// <summary>
		/// 
		/// </summary>
		public int lfOrientation;
		/// <summary>
		/// 
		/// </summary>
		public FontWeight lfWeight;
		/// <summary>
		/// 
		/// </summary>
		[MarshalAs(UnmanagedType.U1)]
		public bool lfItalic;
		/// <summary>
		/// 
		/// </summary>
		[MarshalAs(UnmanagedType.U1)]
		public bool lfUnderline;
		/// <summary>
		/// 
		/// </summary>
		[MarshalAs(UnmanagedType.U1)]
		public bool lfStrikeOut;
		/// <summary>
		/// 
		/// </summary>
		public FontCharacterSet lfCharSet;
		/// <summary>
		/// 
		/// </summary>
		public FontPrecision lfOutPrecision;
		/// <summary>
		/// 
		/// </summary>
		public FontClippingPrecision lfClipPrecision;
		/// <summary>
		/// 
		/// </summary>
		public FontQuality lfQuality;
		/// <summary>
		/// 
		/// </summary>
		public FontPitchAndFamily lfPitchAndFamily;
		/// <summary>
		/// 
		/// </summary>
		[MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)]
		public string lfFaceName;

		/// <summary>
		/// Returns a <see cref="T:System.String"></see> that represents the current <see cref="T:System.Object"></see>.
		/// </summary>
		/// <returns>
		/// A <see cref="T:System.String"></see> that represents the current <see cref="T:System.Object"></see>.
		/// </returns>
		public override string ToString()
		{
			StringBuilder sb = new StringBuilder();
			sb.Append("LOGFONT\n");
			sb.AppendFormat("   lfHeight: {0}\n", lfHeight);
			sb.AppendFormat("   lfWidth: {0}\n", lfWidth);
			sb.AppendFormat("   lfEscapement: {0}\n", lfEscapement);
			sb.AppendFormat("   lfOrientation: {0}\n", lfOrientation);
			sb.AppendFormat("   lfWeight: {0}\n", lfWeight);
			sb.AppendFormat("   lfItalic: {0}\n", lfItalic);
			sb.AppendFormat("   lfUnderline: {0}\n", lfUnderline);
			sb.AppendFormat("   lfStrikeOut: {0}\n", lfStrikeOut);
			sb.AppendFormat("   lfCharSet: {0}\n", lfCharSet);
			sb.AppendFormat("   lfOutPrecision: {0}\n", lfOutPrecision);
			sb.AppendFormat("   lfClipPrecision: {0}\n", lfClipPrecision);
			sb.AppendFormat("   lfQuality: {0}\n", lfQuality);
			sb.AppendFormat("   lfPitchAndFamily: {0}\n", lfPitchAndFamily);
			sb.AppendFormat("   lfFaceName: {0}\n", lfFaceName);

			return sb.ToString();
		}
	}


	/// <summary>
	/// Value type containing shell file information.
	/// </summary>
	public struct SHFILEINFO
	{
		/// <summary>
		/// Icon handle.
		/// </summary>
		public IntPtr IconHandle;
		/// <summary>
		/// Index of the icon image within the system image list. 
		/// </summary>
		public IntPtr IconIndex;
		/// <summary>
		/// Attributes.
		/// </summary>
		public uint Attributes;
		/// <summary>
		/// Display name.
		/// </summary>
		[MarshalAs(UnmanagedType.ByValTStr, SizeConst= 260)]
		public string DisplayName;
		/// <summary>
		/// File type.
		/// </summary>
		[MarshalAs(UnmanagedType.ByValTStr, SizeConst = 80)]
		public string Type;
	}

	/// <summary>
	/// Value type containing joystick position information.
	/// </summary>
	[StructLayout(LayoutKind.Sequential)]
	public struct JOYINFO
	{
		/// <summary>X axis.</summary>
		public int X;
		/// <summary>Y axis.</summary>
		public int Y;
		/// <summary>Z axis.</summary>
		public int Z;
		/// <summary>State of buttons.</summary>
		public JoystickButtons Buttons;
	}

	/// <summary>
	/// Value type containing joystick position information.
	/// </summary>
	[StructLayout(LayoutKind.Sequential)]
	public struct JOYINFOEX
	{
		/// <summary>Size of structure, in bytes.</summary>
		public int Size;
		/// <summary>Flags to indicate what information is valid for the device.</summary>
		public JoystickInfoFlags Flags;
		/// <summary>X axis.</summary>
		public int X;
		/// <summary>Y axis.</summary>
		public int Y;
		/// <summary>Z axis.</summary>
		public int Z;
		/// <summary>Rudder position.</summary>
		public int Rudder;
		/// <summary>5th axis position.</summary>
		public int Axis5;
		/// <summary>6th axis position.</summary>
		public int Axis6;
		/// <summary>State of buttons.</summary>
		public JoystickButtons Buttons;
		/// <summary>Currently pressed button.</summary>
		public int ButtonNumber;
		/// <summary>Angle of the POV hat, in degrees (0 - 35900, divide by 100 to get 0 - 359 degrees.</summary>
		public int POV;
		/// <summary>Reserved.</summary>
		int Reserved1;
		/// <summary>Reserved.</summary>
		int Reserved2;
	}

	/// <summary>
	/// Value type containing joystick capabilities.
	/// </summary>
	[StructLayout(LayoutKind.Sequential, CharSet=CharSet.Ansi)]
	public struct JOYCAPS
	{
		/// <summary>Manufacturer ID.</summary>
		public ushort ManufacturerID;
		/// <summary>Product ID.</summary>
		public ushort ProductID;
		/// <summary>Joystick name.</summary>
		[MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)]
		public string Name;
		/// <summary>Minimum X coordinate.</summary>
		public uint MinimumX;
		/// <summary>Maximum X coordinate.</summary>
		public uint MaximumX;
		/// <summary>Minimum Y coordinate.</summary>
		public uint MinimumY;
		/// <summary>Maximum Y coordinate.</summary>
		public uint MaximumY;
		/// <summary>Minimum Z coordinate.</summary>
		public uint MinimumZ;
		/// <summary>Maximum Z coordinate.</summary>
		public uint MaximumZ;
		/// <summary>Number of buttons on the joystick.</summary>
		public uint ButtonCount;
		/// <summary>Smallest polling frequency (used by joySetCapture).</summary>
		public uint MinimumPollingFrequency;
		/// <summary>Largest polling frequency (used by joySetCapture).</summary>
		public uint MaximumPollingFrequency;
		/// <summary>Minimum rudder value.</summary>
		public uint MinimumRudder;
		/// <summary>Maximum rudder value.</summary>
		public uint MaximumRudder;
		/// <summary>Minimum 5th axis value.</summary>
		public uint Axis5Minimum;
		/// <summary>Maximum 5th axis value.</summary>
		public uint Axis5Maximum;
		/// <summary>Minimum 6th axis value.</summary>
		public uint Axis6Minimum;
		/// <summary>Maximum 6th axis value.</summary>
		public uint Axis6Maximum;
		/// <summary>Joystick capabilities.</summary>
		public JoystickCapabilities Capabilities;
		/// <summary>Maxmimum number of axes for the joystick.</summary>
		public uint MaximumAxes;
		/// <summary>Number of axes on the joystick.</summary>
		public uint AxisCount;
		/// <summary>Maximum buttons for the device.</summary>
		public uint MaximumButtons;
		/// <summary>Registry key for the joystick.</summary>
		[MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)]
		public string RegistryKey;
		/// <summary>Driver name for the joystick.</summary>
		[MarshalAs(UnmanagedType.ByValTStr, SizeConst = 260)]
		public string DriverName;
	}

	/// <summary>
	/// Value type for raw input device list.
	/// </summary>
	[StructLayout(LayoutKind.Sequential)]
	public struct RAWINPUTDEVICELIST
	{
		/// <summary>Device handle.</summary>
		public IntPtr Device;
		/// <summary>Device type.</summary>
		public RawInputType DeviceType;
	}

	/// <summary>
	/// Value type for raw input device information.
	/// </summary>
	[StructLayout(LayoutKind.Explicit)]
	public struct RAWINPUTDEVICEINFO
	{
		/// <summary>Size in bytes of this structure.</summary>
		[FieldOffset(0)]
		public int Size;
		/// <summary>Type of device.</summary>
		[FieldOffset(4)]
		public RawInputType DeviceType;
		/// <summary>Data for a mouse device.</summary>
		[FieldOffset(8)]
		public RAWINPUTMOUSEINFO Mouse;
		/// <summary>Data for a keyboard device.</summary>
		[FieldOffset(8)]
		public RAWINPUTKEYBOARDINFO Keyboard;
		/// <summary>Data for a HID.</summary>
		[FieldOffset(8)]
		public RAWINPUTHIDINFO HID;
	}

	/// <summary>
	/// Value type for mouse device information.
	/// </summary>
	[StructLayout(LayoutKind.Sequential)]
	public struct RAWINPUTMOUSEINFO
	{
		/// <summary>ID of the device.</summary>
		public int ID;
		/// <summary>Number of buttons on the mouse.</summary>
		public int NumberOfButtons;
		/// <summary>Number of data points per second.</summary>
		public int SamplingRate;
	}

	/// <summary>
	/// Value type for keyboard device information.
	/// </summary>
	[StructLayout(LayoutKind.Sequential)]
	public struct RAWINPUTKEYBOARDINFO
	{
		/// <summary>Type of keyboard.</summary>
		public int Type;
		/// <summary>Sub type identifier of the keyboard.</summary>
		public int SubType;
		/// <summary>Scan code mode.</summary>
		public int Mode;
		/// <summary>Number of function keys.</summary>
		public int FunctionKeyCount;
		/// <summary>Number of indicators.</summary>
		public int IndicatorCount;
		/// <summary>Total number of keys.</summary>
		public int KeyCount;
	}

	/// <summary>
	/// Value type for HID device information.
	/// </summary>
	[StructLayout(LayoutKind.Sequential)]
	public struct RAWINPUTHIDINFO
	{
		/// <summary>ID of the device vendor.</summary>
		public int VendorID;
		/// <summary>ID of the product.</summary>
		public int ProductID;
		/// <summary>Version of the device.</summary>
		public int Version;
		/// <summary>Usage page.</summary>
		public HIDUsagePage UsagePage;
		/// <summary>Usage type.</summary>
		public ushort Usage;
	}

	/// <summary>
	/// Value type for raw input devices.
	/// </summary>
	[StructLayout(LayoutKind.Sequential)]
	public struct RAWINPUTDEVICE
	{
		/// <summary>Top level collection Usage page for the raw input device.</summary>
		public HIDUsagePage UsagePage;
		/// <summary>Top level collection Usage for the raw input device. </summary>
		public ushort Usage;
		/// <summary>Mode flag that specifies how to interpret the information provided by UsagePage and Usage.</summary>
		public RawInputDeviceFlags Flags;
		/// <summary>Handle to the target device. If NULL, it follows the keyboard focus.</summary>
		public IntPtr WindowHandle;
	}

	/// <summary>
	/// Value type for a raw input header.
	/// </summary>
	[StructLayout(LayoutKind.Sequential)]
	public struct RAWINPUTHEADER
	{
		/// <summary>Type of device the input is coming from.</summary>
		public RawInputType Type;
		/// <summary>Size of the packet of data.</summary>
		public int Size;
		/// <summary>Handle to the device sending the data.</summary>
		public IntPtr Device;
		/// <summary>wParam from the window message.</summary>
		public IntPtr wParam;
	}

	/// <summary>
	/// Value type for raw input from a mouse.
	/// </summary>
	[StructLayout(LayoutKind.Explicit)]
	public struct RAWINPUTMOUSE
	{
		/// <summary>Flags for the event.</summary>
		[FieldOffset(0)]
		public RawMouseFlags Flags;
		/// <summary>Flags for the event.</summary>
		[FieldOffset(4)]
		public RawMouseButtons ButtonFlags;
		/// <summary>If the mouse wheel is moved, this will contain the delta amount.</summary>
		[FieldOffset(6)]
		public ushort ButtonData;
		/// <summary>Raw button data.</summary>
		[FieldOffset(8)]
		public uint RawButtons;
		/// <summary>Relative direction of motion, depending on flags.</summary>
		[FieldOffset(12)]
		public int LastX;
		/// <summary>Relative direction of motion, depending on flags.</summary>
		[FieldOffset(16)]
		public int LastY;
		/// <summary>Extra information.</summary>
		[FieldOffset(20)]
		public uint ExtraInformation;
	}

	/// <summary>
	/// Value type for raw input from a keyboard.
	/// </summary>	
	[StructLayout(LayoutKind.Sequential)]
	public struct RAWINPUTKEYBOARD
	{
		/// <summary>Scan code for key depression.</summary>
		public short MakeCode;
		/// <summary>Scan code information.</summary>
		public RawKeyboardFlags Flags;
		/// <summary>Reserved.</summary>
		public short Reserved;
		/// <summary>Virtual key code.</summary>
		public VirtualKeys VirtualKey;
		/// <summary>Corresponding window message.</summary>
		public WindowMessages Message;
		/// <summary>Extra information.</summary>
		public int ExtraInformation;
	}

	/// <summary>
	/// Value type for raw input from a HID.
	/// </summary>	
	[StructLayout(LayoutKind.Sequential)]
	public struct RAWINPUTHID
	{
		/// <summary>Size of the HID data in bytes.</summary>
		public int Size;
		/// <summary>Number of HID in Data.</summary>
		public int Count;
		/// <summary>Data for the HID.</summary>
		public IntPtr Data;
	}

	/// <summary>
	/// Value type for raw input.
	/// </summary>
	[StructLayout(LayoutKind.Explicit)]
	public struct RAWINPUT
	{
		/// <summary>Header for the data.</summary>
		[FieldOffset(0)]
		public RAWINPUTHEADER Header;
		/// <summary>Mouse raw input data.</summary>
		[FieldOffset(16)]
		public RAWINPUTMOUSE Mouse;
		/// <summary>Keyboard raw input data.</summary>
		[FieldOffset(16)]
		public RAWINPUTKEYBOARD Keyboard;
		/// <summary>HID raw input data.</summary>
		[FieldOffset(16)]
		public RAWINPUTHID HID;
	}

	/// <summary>
	/// Value type for raw input.
	/// </summary>
	/// <remarks>This is for use with x64 versions of windows.  Using the <c ref="RAWINPUT">32 bit RAWINPUT</c> will fail on the x64 version of windows.</remarks>
	[StructLayout(LayoutKind.Explicit)]
	public struct RAWINPUTx64
	{
		/// <summary>Header for the data.</summary>
		[FieldOffset(0)]
		public RAWINPUTHEADER Header;
		/// <summary>Mouse raw input data.</summary>
		[FieldOffset(24)]
		public RAWINPUTMOUSE Mouse;
		/// <summary>Keyboard raw input data.</summary>
		[FieldOffset(24)]
		public RAWINPUTKEYBOARD Keyboard;
		/// <summary>HID raw input data.</summary>
		[FieldOffset(24)]
		public RAWINPUTHID HID;
	}
	/// <summary>
	/// Value type containing character width information.
	/// </summary>
	[StructLayout(LayoutKind.Sequential)]
	public struct ABCFloat
	{
		/// <summary>Specifies the A spacing of the character. The A spacing is the distance to add to the current position before drawing the character glyph.</summary>
		public float A;
		/// <summary>Specifies the B spacing of the character. The B spacing is the width of the drawn portion of the character glyph.</summary>		
		public float B;
		/// <summary>Specifies the C spacing of the character. The C spacing is the distance to add to the current position to provide white space to the right of the character glyph.</summary>		
		public float C;

		/// <summary>
		/// Constructor.
		/// </summary>
		/// <param name="a">Specifies the A spacing of the character. The A spacing is the distance to add to the current position before drawing the character glyph.</param>
		/// <param name="b">Specifies the B spacing of the character. The B spacing is the width of the drawn portion of the character glyph.</param>
		/// <param name="c">Specifies the C spacing of the character. The C spacing is the distance to add to the current position to provide white space to the right of the character glyph.</param>
		public ABCFloat(float a, float b, float c)
		{
			A = a;
			B = b;
			C = c;
		}
	}

	/// <summary>
	/// Value type containing character width information.
	/// </summary>
	[StructLayout(LayoutKind.Sequential)]
	public struct ABC
	{
		/// <summary>Specifies the A spacing of the character. The A spacing is the distance to add to the current position before drawing the character glyph.</summary>
		public int A;
		/// <summary>Specifies the B spacing of the character. The B spacing is the width of the drawn portion of the character glyph.</summary>		
		public uint B;
		/// <summary>Specifies the C spacing of the character. The C spacing is the distance to add to the current position to provide white space to the right of the character glyph.</summary>		
		public int C;

		/// <summary>
		/// Constructor.
		/// </summary>
		/// <param name="a">Specifies the A spacing of the character. The A spacing is the distance to add to the current position before drawing the character glyph.</param>
		/// <param name="b">Specifies the B spacing of the character. The B spacing is the width of the drawn portion of the character glyph.</param>
		/// <param name="c">Specifies the C spacing of the character. The C spacing is the distance to add to the current position to provide white space to the right of the character glyph.</param>
		public ABC(int a, uint b, int c)
		{
			A = a;
			B = b;
			C = c;
		}
	}
	
	/// <summary>
    /// Value type for window class information.
    /// </summary>
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
    public struct WNDCLASSEX
    {
        /// <summary></summary>
        [MarshalAs(UnmanagedType.U4)]        
        public int cbSize;
        /// <summary></summary>
        [MarshalAs(UnmanagedType.U4)]        
        public int style;
        /// <summary></summary>
        public WndProcCallback lpfnWndProc;
        /// <summary></summary>
        public int cbClsExtra;
        /// <summary></summary>
        public int cbWndExtra;
        /// <summary></summary>
        public IntPtr hInstance;
        /// <summary></summary>
        public IntPtr hIcon;
        /// <summary></summary>
        public IntPtr hCursor;
        /// <summary></summary>
        public IntPtr hbrBackground;
        /// <summary></summary>
        public string lpszMenuName;
        /// <summary></summary>
        public string lpszClassName;
        /// <summary></summary>
        public IntPtr hIconSm;
    }

    /// <summary>
    /// Value type for device mode information.
    /// </summary>
    public struct DEVMODE
    {
        /// <summary></summary>
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)]
        public string dmDeviceName;
        /// <summary></summary>
        public short dmSpecVersion;
        /// <summary></summary>
        public short dmDriverVersion;
        /// <summary></summary>        
        public short dmSize;
        /// <summary></summary>
        public short dmDriverExtra;
        /// <summary></summary>
        public int dmFields;

        /// <summary></summary>
        public short dmOrientation;
        /// <summary></summary>
        public short dmPaperSize;
        /// <summary></summary>
        public short dmPaperLength;
        /// <summary></summary>
        public short dmPaperWidth;

        /// <summary></summary>
        public short dmScale;
        /// <summary></summary>
        public short dmCopies;
        /// <summary></summary>
        public short dmDefaultSource;
        /// <summary></summary>
        public short dmPrintQuality;
        /// <summary></summary>
        public short dmColor;
        /// <summary></summary>
        public short dmDuplex;
        /// <summary></summary>
        public short dmYResolution;
        /// <summary></summary>
        public short dmTTOption;
        /// <summary></summary>
        public short dmCollate;
        /// <summary></summary>
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)]
        public string dmFormName;
        /// <summary></summary>
        public short dmLogPixels;
        /// <summary></summary>
        public short dmBitsPerPel;
        /// <summary></summary>
        public int dmPelsWidth;
        /// <summary></summary>
        public int dmPelsHeight;
        /// <summary></summary>
        public int dmDisplayFlags;
        /// <summary></summary>
        public int dmDisplayFrequency;
        /// <summary></summary>
        public int dmICMMethod;
        /// <summary></summary>
        public int dmICMIntent;
        /// <summary></summary>
        public int dmMediaType;
        /// <summary></summary>
        public int dmDitherType;
        /// <summary></summary>
        public int dmReserved1;
        /// <summary></summary>
        public int dmReserved2;
        /// <summary></summary>
        public int dmPanningWidth;
        /// <summary></summary>
        public int dmPanningHeight;
    };
    
    /// <summary>
	/// Value type for window information.
	/// </summary>
	public struct WINDOWINFO
	{
		/// <summary></summary>
		public int cbSize;
		/// <summary></summary>
		public RECT rcWindow;
		/// <summary></summary>
		public RECT rcClient;
		/// <summary></summary>
		public int dwStyle;
		/// <summary></summary>
		public int dwExStyle;
		/// <summary></summary>
		public int dwWindowStatus;
		/// <summary></summary>
		public uint cxWindowBorders;
		/// <summary></summary>
		public uint cyWindowBorders;
		/// <summary></summary>
		public short atomWindowtype;
		/// <summary></summary>
		public short wCreatorVersion;
	}

	/// <summary>
	/// Value type for window placement information.
	/// </summary>
	public struct WINDOWPLACEMENT
	{
		/// <summary></summary>
		public int length;
		/// <summary></summary>
		public int flags;
		/// <summary></summary>
		public int showCmd;
		/// <summary></summary>
		public POINT ptMinPosition;
		/// <summary></summary>
		public POINT ptMaxPosition;
		/// <summary></summary>
		public RECT rcNormalPosition;
	}

	/// <summary>
	/// Value type for a rectangle.
	/// </summary>
	[Serializable, StructLayout(LayoutKind.Sequential)]
	public struct RECT
	{
		#region Variables.
		/// <summary>
		/// Left position of the rectangle.
		/// </summary>
		public int Left;
		/// <summary>
		/// Top position of the rectangle.
		/// </summary>
		public int Top;
		/// <summary>
		/// Right position of the rectangle.
		/// </summary>
		public int Right;
		/// <summary>
		/// Bottom position of the rectangle.
		/// </summary>
		public int Bottom;
		#endregion

		#region Operators.
		/// <summary>
		/// Operator to convert a RECT to Drawing.Rectangle.
		/// </summary>
		/// <param name="rect">Rectangle to convert.</param>
		/// <returns>A Drawing.Rectangle</returns>
		public static implicit operator Rectangle(RECT rect)
		{
			return Rectangle.FromLTRB(rect.Left, rect.Top, rect.Right, rect.Bottom);
		}

		/// <summary>
		/// Operator to convert Drawing.Rectangle to a RECT.
		/// </summary>
		/// <param name="rect">Rectangle to convert.</param>
		/// <returns>RECT rectangle.</returns>
		public static implicit operator RECT(Rectangle rect)
		{
			return new RECT(rect.Left, rect.Top, rect.Right, rect.Bottom);
		}
		#endregion

		#region Constructor.
		/// <summary>
		/// Constructor.
		/// </summary>
		/// <param name="left">Horizontal position.</param>
		/// <param name="top">Vertical position.</param>
		/// <param name="right">Right most side.</param>
		/// <param name="bottom">Bottom most side.</param>
		public RECT(int left, int top, int right, int bottom)
		{
			Left = left;
			Top = top;
			Right = right;
			Bottom = bottom;
		}
		#endregion
	}

	/// <summary>
	/// Value type for a point.
	/// </summary>
	[StructLayout(LayoutKind.Sequential)]
	public struct POINT
	{
		/// <summary></summary>
		public int x;
		/// <summary></summary>
		public int y;
	}

    /// <summary>
    /// Value type representing the mouse data hook.
    /// </summary>
    /// <remarks>See the MSDN documentation for more detail.</remarks>
    [StructLayout(LayoutKind.Sequential)]
    public struct MSLLHOOKSTRUCT
    {
        /// <summary>Mouse position.</summary>
        public Point Point;         
        /// <summary>Mouse information.</summary>
        public int MouseData;
        /// <summary>Flags.</summary>
        public int Flags;
        /// <summary>Time of event.</summary>
        public int Time;
        /// <summary>Extra event info.</summary>
        public int ExtraInfo;
    }

	/// <summary>
	/// Value type representing coordinates in a console buffer.
	/// </summary>
	/// <remarks>See the MSDN documentation for more detail.</remarks>
	[StructLayout(LayoutKind.Explicit)]
	public struct COORD
	{
		#region Variables.
		/// <summary>Horizontal position.</summary>
		[FieldOffset(0)]
		public short X;
		/// <summary>Vertical position.</summary>
		[FieldOffset(2)]
		public short Y;
		#endregion
	};

	/// <summary>
	/// Value type representing a Window message.
	/// </summary>
	/// <remarks>
	/// See the MSDN documentation for more detail.
	/// <para>
	/// Used to pass various messages back and forth between the OS and the app.
	/// </para>
	/// </remarks>
	[StructLayout(LayoutKind.Sequential)]
	public struct MSG
	{
		/// <summary>Window handle.</summary>
		public IntPtr hwnd;
		/// <summary>Message to process.</summary>
		public WindowMessages Message;
		/// <summary>Window message parameter 1.</summary>
		public uint wParam;
		/// <summary>Window message parameter 2.</summary>
		public uint lParam;
		/// <summary>Time message was sent?</summary>
		public uint time;
		/// <summary>Mouse pointer position.</summary>
		public Point pt;
	}

	/// <summary>
	/// Value type to represent a rectangle with limited range.
	/// </summary>
	/// <remarks>See the MSDN documentation for more detail.</remarks>
	[StructLayout(LayoutKind.Sequential)]
	public struct SMALL_RECT
	{
		#region Variables.
		/// <summary>Left position.</summary>
		public short Left;
		/// <summary>Top position.</summary>
		public short Top;
		/// <summary>Right position.</summary>
		public short Right;
		/// <summary>Bottom position.</summary>
		public short Bottom;
		#endregion

		#region Constructor.
		/// <summary>
		/// Constructor.
		/// </summary>
		/// <param name="left">Left position.</param>			
		/// <param name="top">Top position.</param>
		/// <param name="right">Right position.</param>
		/// <param name="bottom">Bottom position.</param>
		public SMALL_RECT(short left, short top, short right, short bottom)
		{
			Left = left;
			Right = right;
			Top = top;
			Bottom = bottom;
		}
		#endregion
	}

	/// <summary>
	/// Value type used for character types from the console.
	/// </summary>
	/// <remarks>See the MSDN documentation for more detail.</remarks>
	[StructLayout(LayoutKind.Explicit)]
	public struct CONSOLE_CHAR
	{
		#region Variables.
		/// <summary>Unicode character.</summary>
		[FieldOffset(0)]
		public ushort UnicodeChar;
		/// <summary>ANSI character.</summary>
		[FieldOffset(0)]
		public byte AnsiChar;
		#endregion
	}

	/// <summary>
	/// Value type used for character information within a console window.
	/// </summary>
	/// <remarks>See the MSDN documentation for more detail.</remarks>
	[StructLayout(LayoutKind.Sequential)]
	public struct CHAR_INFO
	{
		#region Variables.
		/// <summary>Character.</summary>
		public CONSOLE_CHAR Char;
		/// <summary>Attributes for the character.</summary>
		public ushort Attributes;
		#endregion

		#region Constructor.
		/// <summary>
		/// Constructor.
		/// </summary>
		/// <param name="character">Character.</param>
		/// <param name="attribs">Attribute.</param>
		public CHAR_INFO(char character, ushort attribs)
		{
			Char = new CONSOLE_CHAR();
			Char.UnicodeChar = character;
			Char.AnsiChar = Convert.ToByte(character);
			Attributes = attribs;
		}
		#endregion
	}

	/// <summary>
	/// Value type used in obtaining or setting console buffer information.
	/// </summary>
	/// <remarks>See the MSDN documentation for more detail.</remarks>
	[StructLayout(LayoutKind.Sequential)]
	public struct CONSOLE_SCREEN_BUFFER_INFO
	{
		#region Variables.
		/// <summary>Size of the buffer in columns x rows.</summary>
		public COORD dwSize;
		/// <summary>Position of the cursor in columns x rows.</summary>
		public COORD dwCursorPosition;
		/// <summary>Character attributes.</summary>
		public short wAttributes;
		/// <summary>Display window.</summary>
		public SMALL_RECT srWindow;
		/// <summary>Maximum window size.</summary>
		public COORD dwMaximumWindowSize;
		#endregion

		#region Constructor.
		/// <summary>
		/// Constructor.
		/// </summary>
		/// <param name="size">Size of the buffer in columns x rows.</param>
		/// <param name="cursorposition">Position of the cursor in columns x rows.</param>
		/// <param name="attributes">Character attributes.</param>
		/// <param name="window">Display window.</param>
		/// <param name="maxwindowsize">Maximum window size.</param>
		public CONSOLE_SCREEN_BUFFER_INFO(COORD size, COORD cursorposition, short attributes, SMALL_RECT window, COORD maxwindowsize)
		{
			dwSize = size;
			dwCursorPosition = cursorposition;
			wAttributes = attributes;
			srWindow = window;
			dwMaximumWindowSize = maxwindowsize;
		}
		#endregion
	}

	/// <summary>
	/// Value type containing information about the console cursor.
	/// </summary>
	/// <remarks>See the MSDN documentation for more detail.</remarks>
	[StructLayout(LayoutKind.Sequential)]
	public struct CONSOLE_CURSOR_INFO
	{
		#region Variables.
		/// <summary>Height of the cursor.</summary>
		public uint dwSize;
		/// <summary>TRUE for visible, FALSE for invisible.</summary>
		public bool bVisible;
		#endregion

		#region Constructor.
		/// <summary>
		/// Constructor.
		/// </summary>
		/// <param name="size">Height of the cursor.</param>
		/// <param name="visible">TRUE for visible, FALSE for invisible.</param>
		public CONSOLE_CURSOR_INFO(uint size, bool visible)
		{
			dwSize = size;
			bVisible = visible;
		}
		#endregion
	}

	/// <summary>
	/// Value type containing keyboard event data for the console.
	/// </summary>
	/// <remarks>See the MSDN documentation for more detail.</remarks>
	[StructLayout(LayoutKind.Explicit)]
	public struct KEY_EVENT_RECORD
	{
		/// <summary>Flag to indicate that a key is down.</summary>
		[FieldOffset(0)]
		public bool bKeyDown;
		/// <summary>Number of times the key has been repeated.</summary>
		[FieldOffset(4)]
		public ushort wRepeatCount;
		/// <summary>Virtual key code.</summary>
		[FieldOffset(6)]
		public ushort wVirtualKeyCode;
		/// <summary>Virtual scan code.</summary>
		[FieldOffset(8)]
		public ushort wVirtualScanCode;
		/// <summary>Character.</summary>
		[FieldOffset(10)]
		public CONSOLE_CHAR Char;
		/// <summary>Control key state.</summary>
		[FieldOffset(12)]
		public ConsoleControlFlags dwControlKeyState;
	}

	/// <summary>
	/// Value type containing mouse event data for the console.
	/// </summary>
	/// <remarks>See the MSDN documentation for more detail.</remarks>
	[StructLayout(LayoutKind.Explicit)]
	public struct MOUSE_EVENT_RECORD
	{
		/// <summary>Mouse position.</summary>
		[FieldOffset(0)]
		public COORD dwMousePosition;
		/// <summary>Mouse button state.</summary>
		[FieldOffset(4)]
		public ConsoleMouseButtonFlags dwButtonState;
		/// <summary>Control key state.</summary>
		[FieldOffset(8)]
		public ConsoleControlFlags dwControlKeyState;
		/// <summary>Event flags.</summary>
		[FieldOffset(12)]
		public ConsoleMouseEventFlags dwFlags;
	}

	/// <summary>
	/// Value type containing event information about buffer resizing.
	/// </summary>
	/// <remarks>See the MSDN documentation for more detail.</remarks>
	[StructLayout(LayoutKind.Explicit)]
	public struct WINDOW_BUFFER_SIZE_RECORD
	{
		/// <summary>Size of buffer.</summary>
		[FieldOffset(0)]
		public COORD dwSize;
	}

	/// <summary>
	/// Value type containing event info about menu clicks.
	/// </summary>
	/// <remarks>See the MSDN documentation for more detail.</remarks>
	[StructLayout(LayoutKind.Explicit)]
	public struct MENU_EVENT_RECORD
	{
		/// <summary>Menu item selected.</summary>
		[FieldOffset(0)]
		public uint dwCommandId;
	}

	/// <summary>
	/// Value type containing event info about focus changes.
	/// </summary>
	/// <remarks>See the MSDN documentation for more detail.</remarks>
	[StructLayout(LayoutKind.Explicit)]
	public struct FOCUS_EVENT_RECORD
	{
		/// <summary>Flag to indicate whether focus has been given or not.</summary>
		[FieldOffset(0)]
		public bool bSetFocus;
	}

	/// <summary>
	/// Value type representing a union for events.
	/// </summary>
	/// <remarks>See the MSDN documentation for more detail.</remarks>
	[StructLayout(LayoutKind.Explicit)]
	public struct INPUT_RECORD_EVENT_UNION
	{
		/// <summary>Window buffer size event.</summary>
		[FieldOffset(0)]
		public WINDOW_BUFFER_SIZE_RECORD WindowBufferSizeEvent;
		/// <summary>Menu click event.</summary>
		[FieldOffset(0)]
		public MENU_EVENT_RECORD MenuEvent;
		/// <summary>Focus change event.</summary>
		[FieldOffset(0)]
		public FOCUS_EVENT_RECORD FocusEvent;
		/// <summary>Keyboard event.</summary>
		[FieldOffset(0)]
		public KEY_EVENT_RECORD KeyEvent;
		/// <summary>Mouse event.</summary>
		[FieldOffset(0)]
		public MOUSE_EVENT_RECORD MouseEvent;
	}

	/// <summary>
	/// Value type containing information for input events in the console.
	/// </summary>
	/// <remarks>See the MSDN documentation for more detail.</remarks>
	[StructLayout(LayoutKind.Explicit)]
	public struct INPUT_RECORD
	{
		/// <summary>Event type.</summary>
		[FieldOffset(0)]
		public ConsoleEventTypes EventType;
		/// <summary>Event data.</summary>
		[FieldOffset(4)]
		public INPUT_RECORD_EVENT_UNION Event;
	}
	#endregion
}
